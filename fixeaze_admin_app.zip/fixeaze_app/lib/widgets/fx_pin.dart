import 'package:flutter/material.dart';

class FxPin {
  final double lat, lng;
  final String label;
  final Color color;
  final IconData icon;
  final String? id;
  const FxPin(this.lat, this.lng, this.label,
      {this.color = Colors.teal, this.icon = Icons.build_circle, this.id});
}

