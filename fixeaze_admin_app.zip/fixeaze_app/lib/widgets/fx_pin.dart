import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

class FxPin {
  final double lat, lng;
  final String label;
  final Color color;
  final IconData icon;
  final String? id;
  const FxPin(this.lat, this.lng, this.label,
      {this.color = Colors.teal, this.icon = Icons.build_circle, this.id});
}

double kmBetween(double lat1, double lng1, double lat2, double lng2) =>
    const Distance().as(LengthUnit.Kilometer, LatLng(lat1, lng1), LatLng(lat2, lng2));
double kmExact(double lat1, double lng1, double lat2, double lng2) =>
    const Distance().as(LengthUnit.Meter, LatLng(lat1, lng1), LatLng(lat2, lng2)) / 1000.0;
