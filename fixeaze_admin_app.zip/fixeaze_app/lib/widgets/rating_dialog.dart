import 'dart:math' as math;

import 'package:flutter/material.dart';

class RatingResult {
  final int rating;
  final String comment;
  const RatingResult(this.rating, this.comment);
}

const _faces = ['', '😡', '😕', '🙂', '😍', '🤩'];
const _lines = [
  '',
  'Ouch! Tell us what went wrong',
  'Not great. We will do better',
  'Okay! Decent job',
  'Great! Almost perfect',
  'Superstar! Absolutely brilliant',
];

/// A playful rating popup: the face changes with the stars and bounces.
Future<RatingResult?> showRatingPopup(BuildContext context,
    {required String title, required String who, List<String> tags = const []}) {
  return showGeneralDialog<RatingResult>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'rate',
    barrierColor: Colors.black54,
    transitionDuration: const Duration(milliseconds: 350),
    transitionBuilder: (ctx, a, _, child) => ScaleTransition(
      scale: CurvedAnimation(parent: a, curve: Curves.elasticOut),
      child: FadeTransition(opacity: a, child: child),
    ),
    pageBuilder: (ctx, _, __) => _RatingBody(title: title, who: who, tags: tags),
  );
}

class _RatingBody extends StatefulWidget {
  final String title, who;
  final List<String> tags;
  const _RatingBody({required this.title, required this.who, required this.tags});
  @override
  State<_RatingBody> createState() => _RatingBodyState();
}

class _RatingBodyState extends State<_RatingBody> with SingleTickerProviderStateMixin {
  int _r = 0;
  final _c = TextEditingController();
  final Set<String> _picked = {};
  late final AnimationController _bounce =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 450));

  @override
  void dispose() {
    _bounce.dispose();
    _c.dispose();
    super.dispose();
  }

  void _set(int v) {
    setState(() => _r = v);
    _bounce.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: 340,
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 24)],
          ),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              AnimatedBuilder(
                animation: _bounce,
                builder: (_, __) {
                  final t = _bounce.value;
                  final dy = -18 * math.sin(t * math.pi);
                  final rot = 0.25 * math.sin(t * math.pi * 3) * (1 - t);
                  return Transform.translate(
                    offset: Offset(0, dy),
                    child: Transform.rotate(
                      angle: rot,
                      child: Text(_r == 0 ? '⭐' : _faces[_r], style: const TextStyle(fontSize: 64)),
                    ),
                  );
                },
              ),
              const SizedBox(height: 6),
              Text(widget.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              Text(widget.who, style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 10),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                for (var i = 1; i <= 5; i++)
                  GestureDetector(
                    onTap: () => _set(i),
                    child: AnimatedScale(
                      scale: i <= _r ? 1.2 : 1.0,
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeOutBack,
                      child: Icon(i <= _r ? Icons.star_rounded : Icons.star_outline_rounded,
                          size: 44, color: i <= _r ? Colors.amber : Colors.black26),
                    ),
                  ),
              ]),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: Padding(
                  key: ValueKey(_r),
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text(_r == 0 ? 'Tap a star' : _lines[_r],
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w600, color: Colors.teal.shade700)),
                ),
              ),
              if (widget.tags.isNotEmpty)
                Wrap(spacing: 6, runSpacing: 0, alignment: WrapAlignment.center, children: [
                  for (final t in widget.tags)
                    FilterChip(
                      label: Text(t, style: const TextStyle(fontSize: 12)),
                      selected: _picked.contains(t),
                      onSelected: (v) => setState(() => v ? _picked.add(t) : _picked.remove(t)),
                    ),
                ]),
              const SizedBox(height: 6),
              TextField(
                controller: _c,
                maxLines: 2,
                decoration: InputDecoration(
                  hintText: 'Say something (optional)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: TextButton(onPressed: () => Navigator.pop(context), child: const Text('Later'))),
                Expanded(
                  child: FilledButton(
                    onPressed: _r == 0
                        ? null
                        : () {
                            final txt = [..._picked, if (_c.text.trim().isNotEmpty) _c.text.trim()].join(' - ');
                            Navigator.pop(context, RatingResult(_r, txt));
                          },
                    child: const Text('Send'),
                  ),
                ),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
