import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class FxPin {
  final double lat, lng;
  final String label;
  final Color color;
  final IconData icon;
  final String? id;
  const FxPin(this.lat, this.lng, this.label,
      {this.color = Colors.teal, this.icon = Icons.build_circle, this.id});
}

/// Reusable OpenStreetMap view that fits all pins.
class FxMap extends StatelessWidget {
  final List<FxPin> pins;
  final double height;
  final String? selectedId;
  final void Function(FxPin)? onTap;
  const FxMap({super.key, required this.pins, this.height = 240, this.selectedId, this.onTap});

  @override
  Widget build(BuildContext context) {
    if (pins.isEmpty) return const SizedBox.shrink();
    final pts = pins.map((p) => LatLng(p.lat, p.lng)).toList();
    final options = pts.length == 1
        ? MapOptions(initialCenter: pts.first, initialZoom: 14)
        : MapOptions(
            initialCameraFit: CameraFit.bounds(
                bounds: LatLngBounds.fromPoints(pts), padding: const EdgeInsets.all(40), maxZoom: 16),
          );
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        height: height,
        child: FlutterMap(
          key: ValueKey('${pts.length}-${selectedId ?? ''}'),
          options: options,
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.fixeaze.app',
            ),
            if (pts.length == 2 && pins.any((p) => p.id == 'line'))
              PolylineLayer(polylines: [Polyline(points: pts, strokeWidth: 3, color: Colors.teal)]),
            MarkerLayer(
              markers: [
                for (final p in pins)
                  Marker(
                    point: LatLng(p.lat, p.lng),
                    width: 90,
                    height: 56,
                    child: GestureDetector(
                      onTap: onTap == null ? null : () => onTap!(p),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                          decoration: BoxDecoration(
                              color: Colors.white, borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: p.color.withOpacity(0.6))),
                          child: Text(p.label,
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600)),
                        ),
                        Icon(p.icon, color: p.id != null && p.id == selectedId ? Colors.orange : p.color, size: 28),
                      ]),
                    ),
                  ),
              ],
            ),
            const RichAttributionWidget(
                attributions: [TextSourceAttribution('© OpenStreetMap contributors')]),
          ],
        ),
      ),
    );
  }
}

double kmBetween(double lat1, double lng1, double lat2, double lng2) =>
    const Distance().as(LengthUnit.Kilometer, LatLng(lat1, lng1), LatLng(lat2, lng2));
double kmExact(double lat1, double lng1, double lat2, double lng2) =>
    const Distance().as(LengthUnit.Meter, LatLng(lat1, lng1), LatLng(lat2, lng2)) / 1000.0;
