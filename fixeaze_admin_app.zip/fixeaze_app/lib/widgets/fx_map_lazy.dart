import 'package:flutter/material.dart';

import 'fx_map.dart' deferred as impl;
import 'fx_pin.dart';

export 'fx_pin.dart';

/// The map library is only downloaded when a map is first shown, so the app opens faster.
class FxMap extends StatefulWidget {
  final List<FxPin> pins;
  final double height;
  final String? selectedId;
  final void Function(FxPin)? onTap;
  const FxMap({super.key, required this.pins, this.height = 240, this.selectedId, this.onTap});

  @override
  State<FxMap> createState() => _FxMapState();
}

class _FxMapState extends State<FxMap> {
  static Future<void>? _loading;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _loading ??= impl.loadLibrary();
    _loading!.then((_) {
      if (mounted) setState(() => _ready = true);
    }).catchError((_) {
      _loading = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.pins.isEmpty) return const SizedBox.shrink();
    if (!_ready) {
      return Container(
        height: widget.height,
        decoration: BoxDecoration(color: const Color(0xFFE6F4F1), borderRadius: BorderRadius.circular(12)),
        alignment: Alignment.center,
        child: const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    return impl.FxMapImpl(
        pins: widget.pins, height: widget.height, selectedId: widget.selectedId, onTap: widget.onTap);
  }
}
