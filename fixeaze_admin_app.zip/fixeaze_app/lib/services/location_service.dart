import 'package:geolocator/geolocator.dart';

class GeoResult {
  final double? lat;
  final double? lng;
  final double? accuracy;
  final String? error;
  const GeoResult({this.lat, this.lng, this.accuracy, this.error});

  bool get ok => lat != null && lng != null;
}

/// Gets the phone's / browser's current position (the browser asks for permission).
class LocationService {
  static Future<GeoResult> current() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return const GeoResult(error: 'Location permission was not given');
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      ).timeout(const Duration(seconds: 15));
      return GeoResult(lat: pos.latitude, lng: pos.longitude, accuracy: pos.accuracy);
    } catch (e) {
      return GeoResult(error: 'Could not read your location: $e');
    }
  }
}
