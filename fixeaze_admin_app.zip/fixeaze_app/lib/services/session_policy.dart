import 'dart:async';

import 'package:shared_preferences/shared_preferences.dart';

/// Keeps people logged in for a while, then asks them to log in again.
/// Customers: 3 hours without using the app. Technicians and institutions: 6 hours.
class SessionPolicy {
  static const _kActive = 'fx_last_active';
  static const _kFresh = 'fx_fresh_login';
  static const _kLastId = 'fx_last_login_id';
  static Timer? _timer;

  static Duration limitFor(String? role, bool institution) =>
      Duration(hours: (role == 'customer' && !institution) ? 3 : 6);

  static Future<void> touch() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt(_kActive, DateTime.now().millisecondsSinceEpoch);
    } catch (_) {}
  }

  /// Call before a login that leaves the page (Google): remembers it was a new login.
  static Future<void> markFresh() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool(_kFresh, true);
      await p.setInt(_kActive, DateTime.now().millisecondsSinceEpoch);
    } catch (_) {}
  }

  static Future<bool> consumeFresh() async {
    try {
      final p = await SharedPreferences.getInstance();
      final v = p.getBool(_kFresh) ?? false;
      if (v) await p.remove(_kFresh);
      return v;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> expired(Duration limit) async {
    try {
      final p = await SharedPreferences.getInstance();
      final t = p.getInt(_kActive);
      if (t == null) {
        await touch(); // sessions from before this update: start counting now
        return false;
      }
      return DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(t)) > limit;
    } catch (_) {
      return false;
    }
  }

  static void start() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => touch());
  }

  static void stop() {
    _timer?.cancel();
    _timer = null;
  }

  static Future<void> rememberId(String id) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_kLastId, id);
    } catch (_) {}
  }

  static Future<String> lastId() async {
    try {
      final p = await SharedPreferences.getInstance();
      return p.getString(_kLastId) ?? '';
    } catch (_) {
      return '';
    }
  }
}

/// Checks whether an email or mobile number already has an account.
class AccountCheck {
  /// Returns null when free, otherwise a message to show the person.
  static Future<String?> problem(dynamic client, String email, String phone) async {
    try {
      final r = await client.rpc('account_exists', params: {'p_email': email.trim(), 'p_phone': phone.trim()});
      if (r == 'email') return 'This email is already registered. Please log in instead.';
      if (r == 'phone') return 'This mobile number is already registered. Please log in instead.';
    } catch (_) {
      // not installed yet: the database still blocks duplicates
    }
    return null;
  }
}
