/// Website build: no phone notifications here (the website has its own push).
class NativePush {
  static Future<void> start() async {}
  static Future<void> forgetThisPhone() async {}
}
