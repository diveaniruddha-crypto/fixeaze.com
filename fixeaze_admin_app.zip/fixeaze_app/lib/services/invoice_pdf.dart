import 'dart:typed_data';
import 'dart:ui' show Offset, Rect;

import 'package:flutter/services.dart' show rootBundle;
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

import 'invoice_model.dart';

/// Builds a PDF with the Fixeaze logo at the top.
Future<Uint8List> buildInvoicePdf(InvoiceData d) async {
  final doc = PdfDocument();
  doc.pageSettings.margins.all = 36;
  final page = doc.pages.add();
  final w = page.getClientSize().width;
  final teal = PdfColor(0, 150, 136);
  final grey = PdfColor(110, 110, 110);
  final h1 = PdfStandardFont(PdfFontFamily.helvetica, 22, style: PdfFontStyle.bold);
  final h2 = PdfStandardFont(PdfFontFamily.helvetica, 12, style: PdfFontStyle.bold);
  final body = PdfStandardFont(PdfFontFamily.helvetica, 10);
  final bold = PdfStandardFont(PdfFontFamily.helvetica, 10, style: PdfFontStyle.bold);

  // logo + company
  try {
    final logo = PdfBitmap((await rootBundle.load('assets/logo.png')).buffer.asUint8List());
    page.graphics.drawImage(logo, const Rect.fromLTWH(0, 0, 56, 56));
  } catch (_) {}
  page.graphics.drawString('Fixeaze', h1, brush: PdfSolidBrush(teal), bounds: const Rect.fromLTWH(66, 4, 220, 28));
  page.graphics.drawString('Home services at your doorstep', body,
      brush: PdfSolidBrush(grey), bounds: const Rect.fromLTWH(66, 32, 240, 14));
  page.graphics.drawString(d.title, h2,
      format: PdfStringFormat(alignment: PdfTextAlignment.right), bounds: Rect.fromLTWH(w - 240, 4, 240, 16));
  page.graphics.drawString('No: ${d.number}', bold,
      format: PdfStringFormat(alignment: PdfTextAlignment.right), bounds: Rect.fromLTWH(w - 240, 22, 240, 14));
  page.graphics.drawString('Date: ${DateFormat('d MMM yyyy').format(d.date)}', body,
      format: PdfStringFormat(alignment: PdfTextAlignment.right), bounds: Rect.fromLTWH(w - 240, 38, 240, 14));
  page.graphics.drawLine(PdfPen(teal, width: 1.5), const Offset(0, 66), Offset(w, 66));

  double y = 80;
  void block(List<List<String>> rows) {
    for (final r in rows) {
      page.graphics.drawString('${r[0]}:', bold, bounds: Rect.fromLTWH(0, y, 110, 14));
      page.graphics.drawString(r[1], body, bounds: Rect.fromLTWH(112, y, w - 112, 28));
      y += r[1].length > 70 ? 26 : 15;
    }
  }

  block(d.parties);
  y += 6;
  block(d.details);
  y += 10;

  final grid = PdfGrid();
  grid.columns.add(count: d.tableHead.length);
  grid.headers.add(1);
  final hr = grid.headers[0];
  for (var i = 0; i < d.tableHead.length; i++) {
    hr.cells[i].value = d.tableHead[i];
    hr.cells[i].style = PdfGridCellStyle(
        backgroundBrush: PdfSolidBrush(teal), textBrush: PdfBrushes.white, font: bold);
  }
  for (final r in d.tableRows) {
    final row = grid.rows.add();
    for (var i = 0; i < r.length; i++) {
      row.cells[i].value = r[i];
      row.cells[i].style = PdfGridCellStyle(font: body);
      if (i == r.length - 1) {
        row.cells[i].stringFormat = PdfStringFormat(alignment: PdfTextAlignment.right);
      }
    }
  }
  grid.columns[0].width = w * 0.5;
  grid.style.cellPadding = PdfPaddings(left: 4, right: 4, top: 4, bottom: 4);
  final res = grid.draw(page: page, bounds: Rect.fromLTWH(0, y, w, 0))!;
  y = res.bounds.bottom + 14;
  final pg = res.page;

  for (final t in d.totals) {
    final f = t.bold ? bold : body;
    pg.graphics.drawString(t.label, f, bounds: Rect.fromLTWH(w - 260, y, 150, 14));
    pg.graphics.drawString(inr(t.amount), f,
        format: PdfStringFormat(alignment: PdfTextAlignment.right), bounds: Rect.fromLTWH(w - 110, y, 110, 14));
    y += 16;
    if (t.bold) {
      pg.graphics.drawLine(PdfPen(teal, width: 1), Offset(w - 260, y - 2), Offset(w, y - 2));
    }
  }
  y += 24;
  pg.graphics.drawString(d.footer, body,
      brush: PdfSolidBrush(grey), bounds: Rect.fromLTWH(0, y, w, 30));
  pg.graphics.drawString('This is a computer generated document and needs no signature.', body,
      brush: PdfSolidBrush(grey), bounds: Rect.fromLTWH(0, y + 16, w, 14));

  final bytes = Uint8List.fromList(await doc.save());
  doc.dispose();
  return bytes;
}
