import 'dart:io' show Platform;

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../config.dart';

/// Phone notifications (Firebase Cloud Messaging, free) for the Android and iPhone apps.
/// The website keeps using its own push. Settings come from the database, so a missing
/// or wrong setting never stops the app: it simply stays without notifications.
class NativePush {
  static bool _started = false;
  static String? _token;

  static Future<void> start() async {
    if (kIsWeb || _started) return;
    _started = true;
    try {
      final cfg = await supabase.rpc('fcm_client_config');
      if (cfg == null) return;
      final m = Map<String, dynamic>.from(cfg as Map);
      await Firebase.initializeApp(
        options: FirebaseOptions(
          apiKey: '${m['apiKey']}',
          appId: '${m['appId']}',
          messagingSenderId: '${m['senderId']}',
          projectId: '${m['projectId']}',
        ),
      );
      final fm = FirebaseMessaging.instance;
      await fm.requestPermission(alert: true, badge: true, sound: true);
      _token = await fm.getToken();
      fm.onTokenRefresh.listen((t) {
        _token = t;
        _save();
      });
      supabase.auth.onAuthStateChange.listen((event) {
        if (event.session != null) _save();
      });
      await _save();
    } catch (_) {
      _started = false;
    }
  }

  static Future<void> _save() async {
    final t = _token;
    if (t == null || supabase.auth.currentUser == null) return;
    try {
      await supabase.rpc('register_device_token',
          params: {'p_token': t, 'p_platform': Platform.isIOS ? 'ios' : 'android'});
    } catch (_) {}
  }

  /// Call before logging out so this phone stops getting the previous user's alerts.
  static Future<void> forgetThisPhone() async {
    final t = _token;
    if (t == null) return;
    try {
      await supabase.rpc('unregister_device_token', params: {'p_token': t});
    } catch (_) {}
  }
}
