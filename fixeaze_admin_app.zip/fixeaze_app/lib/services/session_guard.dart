import 'dart:async';

import 'package:flutter/foundation.dart';

import '../config.dart';

/// One device at a time for customers and technicians (admins can use many devices).
/// The newest login becomes the active session; older devices are signed out within ~15 seconds.
class SessionGuard {
  /// Set to true right before an explicit login / sign-up, so this device claims the account.
  static bool freshLogin = false;

  static Timer? _timer;
  static bool _running = false;

  static Future<void> begin(VoidCallback onKicked) async {
    if (_running) return;
    _running = true;
    if (freshLogin) {
      freshLogin = false;
      try {
        await supabase.rpc('claim_session');
      } catch (_) {
        // feature not installed yet: carry on without it
      }
    }
    Future<void> check() async {
      try {
        final ok = await supabase.rpc('session_ok');
        if (ok == false && _running) {
          stop();
          onKicked();
        }
      } catch (_) {
        // offline or not installed: never log anyone out because of an error
      }
    }

    await check();
    _timer?.cancel();
    if (_running) _timer = Timer.periodic(const Duration(seconds: 15), (_) => check());
  }

  static void stop() {
    _running = false;
    _timer?.cancel();
    _timer = null;
  }
}
