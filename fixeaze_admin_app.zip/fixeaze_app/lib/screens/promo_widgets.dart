import 'dart:async';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../services/promo_service.dart';

/// Sliding banner for the home page. Shows nothing when there is no live banner.
class PromoBanner extends StatefulWidget {
  final String audience; // 'customer' or 'technician'
  const PromoBanner({super.key, required this.audience});

  @override
  State<PromoBanner> createState() => _PromoBannerState();
}

class _PromoBannerState extends State<PromoBanner> {
  List<Map<String, dynamic>> _items = [];
  final PageController _pc = PageController();
  Timer? _timer;
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await PromoService.fetch('banner', widget.audience);
    if (!mounted) return;
    setState(() => _items = items);
    _timer?.cancel();
    if (items.length > 1) {
      _timer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (!mounted || !_pc.hasClients) return;
        final next = (_i + 1) % _items.length;
        _pc.animateToPage(next,
            duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: SizedBox(
              height: 130,
              width: double.infinity,
              child: PageView.builder(
                controller: _pc,
                itemCount: _items.length,
                onPageChanged: (i) => setState(() => _i = i),
                itemBuilder: (context, i) {
                  final p = _items[i];
                  return GestureDetector(
                    onTap: () => PromoService.open(context, p),
                    child: Image.network(
                      '${p['media_url']}',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (c, e, s) => Container(
                        color: Colors.black12,
                        alignment: Alignment.center,
                        child: Text('${p['title']}'),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          if (_items.length > 1)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 0; i < _items.length; i++)
                    Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i == _i ? Colors.teal : Colors.black26,
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Wrap a home screen with this: right after the app opens it shows the live
/// full-screen advertisements one by one (each only once per visit).
class AdGate extends StatefulWidget {
  final String audience;
  final Widget child;
  const AdGate({super.key, required this.audience, required this.child});

  static final Set<String> _seen = {};

  @override
  State<AdGate> createState() => _AdGateState();
}

class _AdGateState extends State<AdGate> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  Future<void> _run() async {
    final ads = await PromoService.fetch('ad', widget.audience);
    for (final ad in ads) {
      final id = '${ad['id']}';
      if (AdGate._seen.contains(id)) continue;
      AdGate._seen.add(id);
      if (!mounted) return;
      final tapped = await Navigator.of(context).push<bool>(
        PageRouteBuilder<bool>(
          opaque: true,
          pageBuilder: (_, __, ___) => FullScreenAd(promo: ad),
          transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c),
        ),
      );
      if (tapped == true && mounted) await PromoService.open(context, ad);
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

/// One full-screen advertisement (image or video) with a Skip button.
class FullScreenAd extends StatefulWidget {
  final Map<String, dynamic> promo;
  const FullScreenAd({super.key, required this.promo});

  @override
  State<FullScreenAd> createState() => _FullScreenAdState();
}

class _FullScreenAdState extends State<FullScreenAd> {
  VideoPlayerController? _vc;
  bool _muted = true;
  bool _videoFailed = false;

  bool get _isVideo => '${widget.promo['media_type']}' == 'video';

  @override
  void initState() {
    super.initState();
    if (_isVideo) _startVideo();
  }

  Future<void> _startVideo() async {
    try {
      final c = VideoPlayerController.networkUrl(Uri.parse('${widget.promo['media_url']}'));
      _vc = c;
      await c.initialize();
      await c.setVolume(0); // browsers only auto-play muted videos
      await c.setLooping(true);
      await c.play();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _videoFailed = true);
    }
  }

  @override
  void dispose() {
    _vc?.dispose();
    super.dispose();
  }

  Widget _media() {
    if (_isVideo) {
      final c = _vc;
      if (_videoFailed) {
        return const Center(
            child: Text('Video could not be played', style: TextStyle(color: Colors.white)));
      }
      if (c == null || !c.value.isInitialized) {
        return const Center(child: CircularProgressIndicator(color: Colors.white));
      }
      return Center(
        child: AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
      );
    }
    return Image.network(
      '${widget.promo['media_url']}',
      fit: BoxFit.contain,
      width: double.infinity,
      height: double.infinity,
      loadingBuilder: (c, child, p) => p == null
          ? child
          : const Center(child: CircularProgressIndicator(color: Colors.white)),
      errorBuilder: (c, e, s) => const Center(
          child: Text('Could not load the advertisement', style: TextStyle(color: Colors.white))),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasLink = '${widget.promo['link_type']}' != 'none';
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: hasLink ? () => Navigator.of(context).pop(true) : null,
              child: _media(),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  if (_isVideo && _vc != null && _vc!.value.isInitialized)
                    IconButton(
                      style: IconButton.styleFrom(backgroundColor: Colors.black54),
                      onPressed: () {
                        setState(() => _muted = !_muted);
                        _vc!.setVolume(_muted ? 0 : 1);
                      },
                      icon: Icon(_muted ? Icons.volume_off : Icons.volume_up, color: Colors.white),
                    ),
                  const Spacer(),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.black54, foregroundColor: Colors.white),
                    onPressed: () => Navigator.of(context).pop(false),
                    icon: const Icon(Icons.close, size: 18),
                    label: const Text('Skip'),
                  ),
                ],
              ),
            ),
          ),
          if (hasLink)
            Positioned(
              left: 0,
              right: 0,
              bottom: 24,
              child: SafeArea(
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                        color: Colors.black54, borderRadius: BorderRadius.circular(20)),
                    child: const Text('Tap to open',
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
