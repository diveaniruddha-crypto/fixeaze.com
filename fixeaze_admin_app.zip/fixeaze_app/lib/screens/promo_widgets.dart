import 'dart:async';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../services/promo_service.dart';

/// Sliding banner for the home page. Shows nothing when there is no live banner.
class PromoBanner extends StatefulWidget {
  final String audience; // 'customer' or 'technician'
  const PromoBanner({super.key, required this.audience});

  @override
  State<PromoBanner> createState() => _PromoBannerState();
}

class _PromoBannerState extends State<PromoBanner> {
  List<Map<String, dynamic>> _items = [];
  final PageController _pc = PageController();
  Timer? _timer;
  Timer? _refresh;
  StreamSubscription<AuthState>? _auth;
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _load();
    // Pick up banners again right after login / logout and every few minutes.
    _auth = supabase.auth.onAuthStateChange.listen((_) => _load());
    _refresh = Timer.periodic(const Duration(minutes: 3), (_) => _load());
  }

  Future<void> _load() async {
    final items = await PromoService.fetch('banner', widget.audience);
    if (!mounted) return;
    setState(() {
      _items = items;
      if (_i >= items.length) _i = 0;
    });
    _schedule();
  }

  /// Each banner stays for its own number of seconds, then the slider moves on.
  void _schedule() {
    _timer?.cancel();
    if (_items.length < 2) return;
    final s = (num.tryParse('${_items[_i]['seconds'] ?? 5}') ?? 5).toInt().clamp(2, 120);
    _timer = Timer(Duration(seconds: s), () {
      if (!mounted || !_pc.hasClients) return;
      _pc.animateToPage((_i + 1) % _items.length,
          duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _refresh?.cancel();
    _auth?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              height: 96,
              width: double.infinity,
              child: PageView.builder(
                controller: _pc,
                itemCount: _items.length,
                onPageChanged: (i) {
                  setState(() => _i = i);
                  _schedule();
                },
                itemBuilder: (context, i) {
                  final p = _items[i];
                  return GestureDetector(
                    onTap: () => PromoService.open(context, p),
                    child: Image.network(
                      '${p['media_url']}',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (c, e, s) => Container(
                        color: Colors.black12,
                        alignment: Alignment.center,
                        child: Text('${p['title']}'),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          if (_items.length > 1)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 0; i < _items.length; i++)
                    Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i == _i ? Colors.teal : Colors.black26,
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Wrap a home screen with this: right after the app opens it shows the live
/// full-screen advertisements one by one (each only once per visit).
class AdGate extends StatefulWidget {
  final String audience;
  final Widget child;
  const AdGate({super.key, required this.audience, required this.child});

  static final Set<String> _seen = {};

  @override
  State<AdGate> createState() => _AdGateState();
}

class _AdGateState extends State<AdGate> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  Future<void> _run() async {
    final ads = await PromoService.fetch('ad', widget.audience);
    for (final ad in ads) {
      final id = '${ad['id']}';
      if (AdGate._seen.contains(id)) continue;
      AdGate._seen.add(id);
      if (!mounted) return;
      final tapped = await Navigator.of(context).push<bool>(
        PageRouteBuilder<bool>(
          opaque: false,
          barrierColor: Colors.black87,
          pageBuilder: (_, __, ___) => FullScreenAd(promo: ad),
          transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c),
        ),
      );
      if (tapped == true && mounted) await PromoService.open(context, ad);
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

/// One full-screen advertisement (image or video) with a Skip button.
class FullScreenAd extends StatefulWidget {
  final Map<String, dynamic> promo;
  const FullScreenAd({super.key, required this.promo});

  @override
  State<FullScreenAd> createState() => _FullScreenAdState();
}

class _FullScreenAdState extends State<FullScreenAd> {
  VideoPlayerController? _vc;
  bool _muted = true;
  bool _videoFailed = false;
  Timer? _tick;
  int _left = 0;

  bool get _isVideo => '${widget.promo['media_type']}' == 'video';

  @override
  void initState() {
    super.initState();
    if (_isVideo) _startVideo();
    _left = (num.tryParse('${widget.promo['seconds'] ?? 0}') ?? 0).toInt();
    if (_left > 0) {
      _tick = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _left--);
        if (_left <= 0) {
          _tick?.cancel();
          Navigator.of(context).pop(false);
        }
      });
    }
  }

  Future<void> _startVideo() async {
    try {
      final c = VideoPlayerController.networkUrl(Uri.parse('${widget.promo['media_url']}'));
      _vc = c;
      await c.initialize();
      await c.setVolume(0); // browsers only auto-play muted videos
      await c.setLooping(true);
      await c.play();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _videoFailed = true);
    }
  }

  @override
  void dispose() {
    _tick?.cancel();
    _vc?.dispose();
    super.dispose();
  }

  Widget _media() {
    if (_isVideo) {
      final c = _vc;
      if (_videoFailed) {
        return const Center(
            child: Text('Video could not be played', style: TextStyle(color: Colors.white)));
      }
      if (c == null || !c.value.isInitialized) {
        return const Center(child: CircularProgressIndicator(color: Colors.white));
      }
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          clipBehavior: Clip.hardEdge,
          child: SizedBox(
            width: c.value.size.width,
            height: c.value.size.height,
            child: VideoPlayer(c),
          ),
        ),
      );
    }
    return Image.network(
      '${widget.promo['media_url']}',
      fit: BoxFit.cover,
      alignment: Alignment.center,
      width: double.infinity,
      height: double.infinity,
      loadingBuilder: (c, child, p) => p == null
          ? child
          : const Center(child: CircularProgressIndicator(color: Colors.white)),
      errorBuilder: (c, e, s) => const Center(
          child: Text('Could not load the advertisement', style: TextStyle(color: Colors.white))),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasLink = '${widget.promo['link_type']}' != 'none';
    final size = MediaQuery.of(context).size;
    // A big rounded card (phone-poster shape) on a dimmed background.
    final h = (size.height - 130).clamp(240.0, 5000.0);
    final w0 = (size.width - 44).clamp(200.0, 420.0);
    final cardH = h < w0 / 0.56 ? h : w0 / 0.56;
    final cardW = cardH * 0.56;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // tap outside the card to close
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => Navigator.of(context).pop(false),
              child: const SizedBox.expand(),
            ),
          ),
          Center(
            child: SizedBox(
              width: cardW,
              height: cardH,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        color: Colors.black,
                        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 24)],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: hasLink ? () => Navigator.of(context).pop(true) : null,
                          child: _media(),
                        ),
                      ),
                    ),
                  ),
                  if (hasLink)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 20,
                      child: Center(
                        child: GestureDetector(
                          onTap: () => Navigator.of(context).pop(true),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                            decoration: BoxDecoration(
                                color: const Color(0xFFE6D24F),
                                borderRadius: BorderRadius.circular(30),
                                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 8)]),
                            child: const Text('VIEW OFFER',
                                style: TextStyle(
                                    color: Colors.black87, fontSize: 15, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    ),
                  if (_isVideo && _vc != null && _vc!.value.isInitialized)
                    Positioned(
                      left: 8,
                      top: 8,
                      child: IconButton(
                        style: IconButton.styleFrom(backgroundColor: Colors.black54),
                        onPressed: () {
                          setState(() => _muted = !_muted);
                          _vc!.setVolume(_muted ? 0 : 1);
                        },
                        icon: Icon(_muted ? Icons.volume_off : Icons.volume_up, color: Colors.white),
                      ),
                    ),
                  if (_left > 0)
                    Positioned(
                      left: 12,
                      bottom: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(14)),
                        child: Text('Closes in ${_left}s', style: const TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ),
                  Positioned(
                    right: -6,
                    top: -6,
                    child: Material(
                      color: Colors.white,
                      shape: const CircleBorder(),
                      elevation: 4,
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () => Navigator.of(context).pop(false),
                        child: const Padding(
                          padding: EdgeInsets.all(7),
                          child: Icon(Icons.close, size: 20, color: Colors.black87),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
