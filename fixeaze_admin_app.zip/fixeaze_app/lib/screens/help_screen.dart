import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/common.dart';

String _err(Object e) => e is PostgrestException ? e.message : e.toString();

String shortId(dynamic id) {
  final s = '$id';
  return s.length >= 8 ? s.substring(0, 8) : s;
}

/// Help & support for customers and technicians: raise a ticket, follow replies.
class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key});
  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final r = await supabase
        .from('support_tickets')
        .select()
        .eq('created_by', supabase.auth.currentUser!.id)
        .order('updated_at', ascending: false);
    return List<Map<String, dynamic>>.from(r);
  }

  void _refresh() => setState(() => _future = _load());

  Future<void> _new() async {
    final done = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => const _NewTicketScreen()));
    if (done == true) _refresh();
  }

  Color _color(String s) => s == 'closed' ? Colors.grey : (s == 'answered' ? Colors.green : Colors.orange);
  String _label(String s) => s == 'closed' ? 'Closed' : (s == 'answered' ? 'Replied' : 'Open');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Help & support')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _new,
        icon: const Icon(Icons.add),
        label: const Text('New ticket'),
      ),
      body: Constrained(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) return ErrorState(error: _err(snap.error!), onRetry: _refresh);
            final rows = snap.data!;
            if (rows.isEmpty) {
              return const EmptyState(
                  icon: Icons.support_agent,
                  text: 'Need help?\nTap New ticket and tell us what went wrong. We reply here.');
            }
            return RefreshIndicator(
              onRefresh: () async {
                _refresh();
                await _future;
              },
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final t = rows[i];
                  final st = '${t['status']}';
                  return Card(
                    child: ListTile(
                      title: Text('#${t['ticket_no']}  ${t['subject']}'),
                      subtitle: Text(t['booking_id'] == null
                          ? 'General question'
                          : 'Booking ${shortId(t['booking_id'])}'),
                      trailing: Chip(
                        label: Text(_label(st), style: TextStyle(color: _color(st), fontWeight: FontWeight.w600)),
                        backgroundColor: _color(st).withAlpha(30),
                        side: BorderSide.none,
                      ),
                      onTap: () async {
                        await Navigator.push(context,
                            MaterialPageRoute(builder: (_) => _TicketThread(ticket: t)));
                        _refresh();
                      },
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

class _NewTicketScreen extends StatefulWidget {
  const _NewTicketScreen();
  @override
  State<_NewTicketScreen> createState() => _NewTicketScreenState();
}

class _NewTicketScreenState extends State<_NewTicketScreen> {
  final _subject = TextEditingController();
  final _body = TextEditingController();
  List<Map<String, dynamic>> _bookings = [];
  String? _booking;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  @override
  void dispose() {
    _subject.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<void> _loadBookings() async {
    try {
      final uid = supabase.auth.currentUser!.id;
      final r = await supabase
          .from('bookings')
          .select('id, scheduled_at, status, services(name)')
          .or('customer_id.eq.$uid,technician_id.eq.$uid')
          .order('created_at', ascending: false)
          .limit(40);
      if (mounted) setState(() => _bookings = List<Map<String, dynamic>>.from(r));
    } catch (_) {}
  }

  Future<void> _send() async {
    if (_subject.text.trim().isEmpty || _body.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Write a subject and describe the problem')));
      return;
    }
    setState(() => _busy = true);
    try {
      await supabase.rpc('support_create',
          params: {'p_booking': _booking, 'p_subject': _subject.text.trim(), 'p_body': _body.text.trim()});
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_err(e))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New ticket')),
      body: Constrained(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DropdownButtonFormField<String?>(
              value: _booking,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Which booking? (optional)'),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Not about a booking')),
                for (final b in _bookings)
                  DropdownMenuItem<String?>(
                    value: '${b['id']}',
                    child: Text(
                        '#${shortId(b['id'])} · ${(b['services'] as Map?)?['name'] ?? 'Service'} · ${fmtDate(b['scheduled_at'])}',
                        overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => setState(() => _booking = v),
            ),
            const SizedBox(height: 12),
            TextField(controller: _subject, decoration: const InputDecoration(labelText: 'Subject')),
            const SizedBox(height: 12),
            TextField(
              controller: _body,
              maxLines: 6,
              decoration: const InputDecoration(labelText: 'Describe your problem', alignLabelWithHint: true),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _busy ? null : _send,
              child: _busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Send to Fixeaze support'),
            ),
          ],
        ),
      ),
    );
  }
}

class _TicketThread extends StatefulWidget {
  final Map<String, dynamic> ticket;
  const _TicketThread({required this.ticket});
  @override
  State<_TicketThread> createState() => _TicketThreadState();
}

class _TicketThreadState extends State<_TicketThread> {
  List<Map<String, dynamic>> _msgs = [];
  String _status = '';
  Timer? _t;
  final _text = TextEditingController();
  final _scroll = ScrollController();
  bool _busy = false;
  int _last = 0;

  @override
  void initState() {
    super.initState();
    _status = '${widget.ticket['status']}';
    _load();
    _t = Timer.periodic(const Duration(seconds: 5), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final id = widget.ticket['id'];
      final m = await supabase.from('support_messages').select().eq('ticket_id', id).order('created_at');
      final t = await supabase.from('support_tickets').select('status').eq('id', id).single();
      if (!mounted) return;
      setState(() {
        _msgs = List<Map<String, dynamic>>.from(m);
        _status = '${t['status']}';
      });
      if (_msgs.length != _last) {
        _last = _msgs.length;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
        });
      }
    } catch (_) {}
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty) return;
    setState(() => _busy = true);
    try {
      await supabase.from('support_messages').insert({
        'ticket_id': widget.ticket['id'],
        'sender_id': supabase.auth.currentUser!.id,
        'sender_role': 'user',
        'body': body,
      });
      _text.clear();
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_err(e))));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.ticket;
    final closed = _status == 'closed';
    return Scaffold(
      appBar: AppBar(title: Text('#${t['ticket_no']}  ${t['subject']}', overflow: TextOverflow.ellipsis)),
      body: Constrained(
        child: Column(children: [
          if (t['booking_id'] != null)
            Container(
              width: double.infinity,
              color: Colors.teal.shade50,
              padding: const EdgeInsets.all(8),
              child: Text('About booking ${shortId(t['booking_id'])}', style: const TextStyle(fontSize: 12)),
            ),
          Expanded(
            child: ListView(
              controller: _scroll,
              padding: const EdgeInsets.all(12),
              children: [
                for (final m in _msgs)
                  ChatBubble(
                    text: '${m['body']}',
                    who: m['sender_role'] == 'admin' ? 'Fixeaze support' : 'You',
                    time: DateTime.tryParse('${m['created_at']}'),
                    mine: m['sender_role'] != 'admin',
                  ),
              ],
            ),
          ),
          if (closed)
            const Padding(
                padding: EdgeInsets.all(12), child: Text('This ticket is closed. Raise a new ticket if you still need help.'))
          else
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                child: Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _text,
                      minLines: 1,
                      maxLines: 4,
                      decoration: const InputDecoration(hintText: 'Write a message', border: OutlineInputBorder()),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send)),
                ]),
              ),
            ),
        ]),
      ),
    );
  }
}
