import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../chat_screen.dart';
import '../job_watcher.dart';

class _BookingsData {
  final List<Map<String, dynamic>> bookings;
  final Map<String, Map<String, dynamic>> technicians; // by technician id
  final Set<String> reviewed; // booking ids that already have a review
  _BookingsData(this.bookings, this.technicians, this.reviewed);
}

class CustomerBookingsTab extends StatefulWidget {
  const CustomerBookingsTab({super.key});

  @override
  State<CustomerBookingsTab> createState() => _CustomerBookingsTabState();
}

class _CustomerBookingsTabState extends State<CustomerBookingsTab> {
  late Future<_BookingsData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_BookingsData> _load() async {
    final uid = supabase.auth.currentUser!.id;

    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price)')
        .eq('customer_id', uid)
        .order('created_at', ascending: false);
    final bookings = List<Map<String, dynamic>>.from(rows);

    final techIds = bookings
        .map((b) => b['technician_id'])
        .whereType<String>()
        .toSet()
        .toList();
    final techs = <String, Map<String, dynamic>>{};
    if (techIds.isNotEmpty) {
      final trows = await supabase
          .from('technician_profiles')
          .select('id, name, photo_url, rating')
          .inFilter('id', techIds);
      for (final r in trows) {
        techs[r['id'] as String] = Map<String, dynamic>.from(r);
      }
    }

    final revRows = await supabase.from('reviews').select('booking_id').eq('customer_id', uid);
    final reviewed = revRows.map((r) => r['booking_id'] as String).toSet();

    return _BookingsData(bookings, techs, reviewed);
  }

  Future<void> _cancel(Map<String, dynamic> b) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cancel this booking?'),
        content: const Text('The technician will no longer be able to take this job.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep it')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cancel booking')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase.from('bookings').update({'status': 'cancelled'}).eq('id', b['id']);
      if (mounted) snack(context, 'Booking cancelled');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  Future<void> _review(Map<String, dynamic> b) async {
    int rating = 5;
    final comment = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Rate your service'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  5,
                  (i) => IconButton(
                    onPressed: () => setLocal(() => rating = i + 1),
                    icon: Icon(i < rating ? Icons.star : Icons.star_border,
                        color: Colors.amber, size: 32),
                  ),
                ),
              ),
              TextField(
                controller: comment,
                maxLines: 3,
                decoration: const InputDecoration(hintText: 'Write a short review (optional)'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Submit')),
          ],
        ),
      ),
    );
    final text = comment.text.trim();
    comment.dispose();
    if (ok != true) return;

    try {
      await supabase.from('reviews').insert({
        'booking_id': b['id'],
        'customer_id': supabase.auth.currentUser!.id,
        'technician_id': b['technician_id'],
        'rating': rating,
        'comment': text.isEmpty ? null : text,
      });
      if (mounted) snack(context, 'Thanks for your review!');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_BookingsData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final data = snap.data!;
        if (data.bookings.isEmpty) {
          return const EmptyState(
            icon: Icons.receipt_long,
            text: 'No bookings yet.\nPick a service to book your first technician.',
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: data.bookings.length,
            itemBuilder: (context, i) {
              final b = data.bookings[i];
              final status = (b['status'] ?? '').toString();
              final service = b['services'] as Map<String, dynamic>?;
              final tech = data.technicians[b['technician_id']];
              final photos = List<String>.from(b['photos'] ?? const []);
              final donePhotos = List<String>.from(b['completion_photos'] ?? const []);
              final techName = (tech?['name'] ?? 'Assigned').toString();
              final techRating = num.tryParse('${tech?['rating'] ?? 0}') ?? 0;
              final techLabel = techRating > 0
                  ? 'Technician: $techName  ★ $techRating'
                  : 'Technician: $techName';

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              (service?['name'] ?? 'Service').toString(),
                              style: const TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.bold),
                            ),
                          ),
                          StatusChip(status),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(bookingTypeLabel(b),
                          style: TextStyle(
                              color: Colors.teal.shade700,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(b['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((b['address'] ?? '').toString())),
                      ]),
                      if (tech != null || b['technician_id'] != null) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.engineering, size: 16, color: Colors.black45),
                          const SizedBox(width: 6),
                          Expanded(child: Text(techLabel)),
                        ]),
                      ],
                      if (b['price'] != null) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.payments, size: 16, color: Colors.black45),
                          const SizedBox(width: 6),
                          Text('Final price: ${money(b['price'])}'),
                        ]),
                      ] else if (service?['base_price'] != null) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.payments, size: 16, color: Colors.black45),
                          const SizedBox(width: 6),
                          Text('Starting from ${money(service!['base_price'])}'),
                        ]),
                      ],
                      if ((b['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${b['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      if (donePhotos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        const Text('Work photos',
                            style: TextStyle(fontSize: 12, color: Colors.black54)),
                        const SizedBox(height: 4),
                        PhotoStrip(urls: donePhotos),
                      ],
                      if (b['technician_id'] != null &&
                          (status == 'accepted' ||
                              status == 'in_progress' ||
                              status == 'completed')) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: OutlinedButton.icon(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  bookingId: b['id'] as String,
                                  title: 'Chat with $techName',
                                  canSend: status != 'completed',
                                ),
                              ),
                            ),
                            icon: const Icon(Icons.chat_bubble_outline, size: 18),
                            label: const Text('Chat with technician'),
                          ),
                        ),
                      ],
                      if ((status == 'accepted' || status == 'in_progress') &&
                          (b['job_stage'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            onPressed: () async {
                              await showCustomerJob(context, b['id'] as String);
                              if (mounted) _refresh();
                            },
                            icon: const Icon(Icons.notifications_active),
                            label: const Text('Job status / OTP'),
                          ),
                        ),
                      ],
                      if (status == 'pending' ||
                          (status == 'accepted' && (b['job_stage'] ?? '').toString().isEmpty)) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => _cancel(b),
                            icon: const Icon(Icons.close, size: 18),
                            label: const Text('Cancel booking'),
                            style: TextButton.styleFrom(foregroundColor: Colors.red.shade700),
                          ),
                        ),
                      ],
                      if (status == 'completed' &&
                          b['technician_id'] != null &&
                          !data.reviewed.contains(b['id'])) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: FilledButton.icon(
                            onPressed: () => _review(b),
                            icon: const Icon(Icons.star),
                            label: const Text('Rate technician'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
