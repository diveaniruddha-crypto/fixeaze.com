import 'package:flutter/material.dart';

import '../widgets/common.dart';
import 'institution/institution_signup_screen.dart';
import 'technician/technician_signup.dart';

/// First step of "Join as a technician": individual or institutional.
class TechnicianTypeScreen extends StatelessWidget {
  const TechnicianTypeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget card(IconData icon, String title, String text, VoidCallback onTap) => Card(
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(children: [
                CircleAvatar(radius: 26, child: Icon(icon, size: 28)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(text),
                  ]),
                ),
                const Icon(Icons.chevron_right),
              ]),
            ),
          ),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('Join as a technician')),
      body: SafeArea(
        child: Constrained(
          maxWidth: 520,
          child: ListView(padding: const EdgeInsets.all(20), children: [
            const Text('How do you want to work with Fixeaze?',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            card(Icons.person, 'Individual',
                'You work on jobs yourself. Payments come to your own bank account / UPI.', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const TechnicianSignupScreen()));
            }),
            const SizedBox(height: 12),
            card(Icons.business, 'Institution',
                'You run a company or team. Add your employees; all payments go to the institution. '
                    'The owner can see every employee\'s jobs, hours and earnings.', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const InstitutionSignupScreen()));
            }),
          ]),
        ),
      ),
    );
  }
}
