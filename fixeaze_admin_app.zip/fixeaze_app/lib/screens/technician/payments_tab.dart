import 'package:flutter/material.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../invoice_screen.dart';

class _PayData {
  final List<Map<String, dynamic>> payments;
  final List<Map<String, dynamic>> notes;
  final Set<String> unreadIds;
  final num dueOwed; // cash-job commission still to be deducted
  String? institution; // set when the technician works for an institution
  _PayData(this.payments, this.notes, this.unreadIds, this.dueOwed);
}

/// Shows what Fixeaze owes / has paid the technician for each booking,
/// plus payment updates sent by Fixeaze.
class PaymentsTab extends StatefulWidget {
  const PaymentsTab({super.key});

  @override
  State<PaymentsTab> createState() => _PaymentsTabState();
}

class _PaymentsTabState extends State<PaymentsTab> {
  late Future<_PayData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_PayData> _load() async {
    final uid = supabase.auth.currentUser!.id;
    final pay = await supabase
        .from('technician_payments')
        .select('*, bookings(scheduled_at, services(name))')
        .eq('technician_id', uid)
        .order('created_at', ascending: false);
    final notes = await supabase
        .from('technician_notifications')
        .select()
        .eq('technician_id', uid)
        .order('created_at', ascending: false)
        .limit(30);

    final noteList = List<Map<String, dynamic>>.from(notes);
    final unread = noteList
        .where((n) => n['read'] != true)
        .map((n) => n['id'].toString())
        .toSet();
    if (unread.isNotEmpty) {
      // Mark as read in the background; they stay highlighted on this screen.
      supabase
          .from('technician_notifications')
          .update({'read': true})
          .eq('technician_id', uid)
          .eq('read', false)
          .then((_) {}, onError: (_) {});
    }
    num due = 0;
    try {
      final dues = await supabase
          .from('cash_dues')
          .select('amount, settled')
          .eq('technician_id', uid)
          .eq('status', 'open');
      for (final d in dues) {
        due += (num.tryParse('${d['amount']}') ?? 0) - (num.tryParse('${d['settled']}') ?? 0);
      }
    } catch (_) {
      // table appears after sql part 11
    }
    final data = _PayData(List<Map<String, dynamic>>.from(pay), noteList, unread, due);
    data.institution = await institutionNameFor(uid);
    return data;
  }

  Map<String, dynamic>? _asMap(dynamic v) {
    if (v is Map) return Map<String, dynamic>.from(v);
    if (v is List && v.isNotEmpty && v.first is Map) {
      return Map<String, dynamic>.from(v.first as Map);
    }
    return null;
  }

  static const _colors = {
    'pending': Colors.orange,
    'processing': Colors.blue,
    'paid': Colors.green,
    'failed': Colors.red,
  };
  static const _labels = {
    'pending': 'Pending',
    'processing': 'Processing',
    'paid': 'Paid',
    'failed': 'Failed',
  };

  num _sum(List<Map<String, dynamic>> list, bool Function(String) test) {
    num total = 0;
    for (final p in list) {
      if (test((p['status'] ?? '').toString())) {
        total += num.tryParse(p['amount'].toString()) ?? 0;
      }
    }
    return total;
  }

  /// Total of unpaid jobs that already have a payout date, and the earliest of those dates.
  (num, String)? _upcoming(List<Map<String, dynamic>> list) {
    num total = 0;
    String? first;
    for (final p in list) {
      final st = '${p['status']}';
      if ((st == 'pending' || st == 'processing') && p['pay_on'] != null) {
        total += num.tryParse('${p['amount']}') ?? 0;
        final d = '${p['pay_on']}';
        if (first == null || d.compareTo(first) < 0) first = d;
      }
    }
    return (first == null || total <= 0) ? null : (total, first);
  }

  Widget _summary(String label, num amount, Color color, IconData icon) {
    return Expanded(
      child: Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color),
              const SizedBox(height: 6),
              Text(money(amount),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text(label, style: const TextStyle(color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_PayData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return ErrorState(error: snap.error!, onRetry: _refresh);
        final data = snap.data!;
        final received = _sum(data.payments, (s) => s == 'paid');
        final waiting = _sum(data.payments, (s) => s == 'pending' || s == 'processing');

        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (data.institution != null) ...[
                Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  color: Colors.indigo.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.business, color: Colors.indigo),
                    title: Text('Working with ${data.institution}'),
                    subtitle: const Text('Your earnings are paid to your institution, not to you directly.'),
                  ),
                ),
              ],
              Row(
                children: [
                  _summary('Received', received, Colors.green, Icons.check_circle),
                  const SizedBox(width: 12),
                  _summary('On the way', waiting, Colors.orange, Icons.hourglass_bottom),
                ],
              ),
              if (_upcoming(data.payments) != null) ...[
                const SizedBox(height: 12),
                Card(
                  margin: EdgeInsets.zero,
                  color: Colors.green.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.event_available, color: Colors.green),
                    title: Text(
                        '${money(_upcoming(data.payments)!.$1)} will be paid on ${fmtDate(_upcoming(data.payments)!.$2)}'),
                    subtitle: const Text('To the bank account / UPI you gave us. You will get a message when it is paid.'),
                  ),
                ),
              ],
              if (data.dueOwed > 0) ...[
                const SizedBox(height: 12),
                Card(
                  margin: EdgeInsets.zero,
                  color: Colors.orange.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.info_outline, color: Colors.orange),
                    title: Text('${money(data.dueOwed)} commission to be deducted'),
                    subtitle: const Text(
                        'From jobs where the customer paid you cash. It is taken from your next Fixeaze payment.'),
                  ),
                ),
              ],
              if (data.notes.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text('Updates from Fixeaze',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...data.notes.take(8).map((n) {
                  final fresh = data.unreadIds.contains(n['id'].toString());
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    color: fresh ? Colors.teal.shade50 : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                          color: fresh ? Colors.teal.shade200 : Colors.black12),
                    ),
                    child: ListTile(
                      leading: Icon(
                        n['kind'] == 'payment' ? Icons.currency_rupee : Icons.campaign,
                        color: Colors.teal,
                      ),
                      title: Text((n['title'] ?? '').toString(),
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(
                          '${(n['body'] ?? '').toString()}\n${fmtDate(n['created_at'])}'),
                      isThreeLine: true,
                    ),
                  );
                }),
              ],
              const SizedBox(height: 20),
              const Text('Payments for your bookings',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (data.payments.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 32),
                  child: EmptyState(
                    icon: Icons.account_balance_wallet_outlined,
                    text: 'No payments yet.\nOnce you complete a job, it shows up here.',
                  ),
                )
              else
                ...data.payments.map((p) {
                  final status = (p['status'] ?? 'pending').toString();
                  final color = _colors[status] ?? Colors.grey;
                  final booking = _asMap(p['bookings']);
                  final service = _asMap(booking?['services']);
                  final paidAt = p['paid_at'];
                  final ref = (p['reference'] ?? '').toString();
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  (service?['name'] ?? 'Booking').toString(),
                                  style: const TextStyle(
                                      fontSize: 16, fontWeight: FontWeight.w600),
                                ),
                              ),
                              Text(money(p['amount']),
                                  style: const TextStyle(
                                      fontSize: 18, fontWeight: FontWeight.bold)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          if (booking?['scheduled_at'] != null)
                            Text('Job: ${fmtDate(booking!['scheduled_at'])}',
                                style: const TextStyle(color: Colors.black54)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: color.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(_labels[status] ?? status,
                                    style: TextStyle(
                                        color: color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12)),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  paidAt != null
                                      ? 'Paid on ${fmtDate(paidAt)}'
                                      : (p['pay_on'] != null && (status == 'pending' || status == 'processing')
                                          ? 'Payout on ${fmtDate(p['pay_on'])}'
                                          : (status == 'pending' ? 'Waiting for Fixeaze' : '')),
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.black54),
                                ),
                              ),
                            ],
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton.icon(
                              onPressed: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => InvoiceScreen.technician(paymentId: '${p['id']}'))),
                              icon: const Icon(Icons.receipt_long),
                              label: const Text('Payment invoice'),
                            ),
                          ),
                          if ((p['note'] ?? '').toString().isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text((p['note']).toString(),
                                style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          ],
                          if (ref.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text('Reference: $ref',
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.black54)),
                          ],
                        ],
                      ),
                    ),
                  );
                }),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}

/// Name of the institution this technician belongs to (null for individuals).
Future<String?> institutionNameFor(String uid) async {
  try {
    final tp = await supabase.from('technician_profiles').select('institution_id').eq('id', uid).maybeSingle();
    final iid = tp?['institution_id'];
    if (iid == null) return null;
    final inst = await supabase.from('institutions').select('name').eq('id', iid).maybeSingle();
    return inst == null ? null : '${inst['name']}';
  } catch (_) {
    return null;
  }
}
