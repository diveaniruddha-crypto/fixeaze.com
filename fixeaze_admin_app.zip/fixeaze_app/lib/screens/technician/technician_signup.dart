import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../app_state.dart';
import '../../config.dart';
import '../../services/app_otp.dart';
import '../../services/pincode_service.dart';
import '../../services/validators.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

/// Technician application: 1) fill details  2) review application  3) enter OTP.
/// The OTP is shown in a popup inside the app (no email / SMS). The account is created after it is typed.
class TechnicianSignupScreen extends StatefulWidget {
  const TechnicianSignupScreen({super.key});

  @override
  State<TechnicianSignupScreen> createState() => _TechnicianSignupScreenState();
}

class _TechnicianSignupScreenState extends State<TechnicianSignupScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _aadhaarName = TextEditingController();
  final _aadhaarNo = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _pincode = TextEditingController();
  final _experience = TextEditingController();
  final _rate = TextEditingController();
  final _otp = TextEditingController();
  final _bankHolder = TextEditingController();
  final _bankName = TextEditingController();
  final _accNo = TextEditingController();
  final _accNo2 = TextEditingController();
  final _ifsc = TextEditingController();
  final _upi = TextEditingController();

  int _step = 0; // 0 details, 1 review, 2 otp
  bool _busy = false;
  bool _hidePassword = true;
  String _progress = '';
  String? _formError;

  List<Map<String, dynamic>> _services = [];
  bool _loadingServices = true;
  Object? _servicesError;
  final Set<String> _selected = {};

  TimeOfDay _start = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 18, minute: 0);
  bool _confirmShift = false;
  bool _consent = false;
  bool _terms = false;

  Uint8List? _aadhaarBytes;
  String _aadhaarFile = 'aadhaar.jpg';
  Uint8List? _selfieBytes;
  PinInfo? _pin;

  int _cooldown = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final c in [
      _name, _aadhaarName, _aadhaarNo, _phone, _email, _password,
      _pincode, _experience, _rate, _otp,
      _bankHolder, _bankName, _accNo, _accNo2, _ifsc, _upi,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadServices() async {
    setState(() {
      _loadingServices = true;
      _servicesError = null;
    });
    try {
      final rows = await supabase
          .from('services')
          .select('id, name')
          .eq('active', true)
          .order('name');
      _services = List<Map<String, dynamic>>.from(rows);
    } catch (e) {
      _servicesError = e;
    }
    if (mounted) setState(() => _loadingServices = false);
  }

  int _minutes(TimeOfDay t) => t.hour * 60 + t.minute;
  String _sql(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:00';

  void _fail(String message) {
    setState(() => _formError = message);
    snack(context, message, error: true);
  }

  Future<void> _pickAadhaar() async {
    try {
      final file = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1600,
        imageQuality: 80,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      setState(() {
        _aadhaarBytes = bytes;
        _aadhaarFile = file.name;
      });
    } catch (e) {
      if (mounted) snack(context, 'Could not open the photo: $e', error: true);
    }
  }

  /// Opens the front camera (on phones). On a computer the browser may ask
  /// for the webcam or show a file chooser.
  Future<void> _pickSelfie() async {
    try {
      final file = await ImagePicker().pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        maxWidth: 1000,
        imageQuality: 80,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      setState(() => _selfieBytes = bytes);
    } catch (e) {
      if (mounted) snack(context, 'Could not open the camera: $e', error: true);
    }
  }

  static const _termsText = '''1. Eligibility: You are 18 or older and the details, Aadhaar, selfie and bank details you give are true and your own.

2. Verification: Fixeaze may verify your identity and background. You can accept jobs only after approval, and approval can be withdrawn at any time.

3. Independent work: You work as an independent service provider, not as an employee of Fixeaze.

4. Jobs: Accept only jobs you can do. Arrive on time, work safely, and treat customers with respect. Do not ask customers for payment outside the app.

5. Pricing and payouts: You will charge your stated hourly rate or the inspection fee set in the app. Payouts go to the bank account you provided.

6. Conduct: Fake details, harassment, theft, damage caused by negligence, or misuse of customer information can lead to removal and legal action.

7. Privacy: Fixeaze uses your documents only for verification and payouts, and keeps them private.

8. Changes: Fixeaze may update these terms. Continuing to use the app means you accept the updated terms.''';

  void _showTerms() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Terms and Conditions'),
        content: const SingleChildScrollView(child: Text(_termsText)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }

  Future<void> _pickTime(bool isStart) async {
    final t = await showTimePicker(
      context: context,
      initialTime: isStart ? _start : _end,
    );
    if (t == null) return;
    setState(() => isStart ? _start = t : _end = t);
  }

  // ---------- Step 0 -> 1 ----------
  Future<void> _goReview() async {
    setState(() => _formError = null);
    if (!_form.currentState!.validate()) return;
    if (_selected.isEmpty) return _fail('Select at least one service you provide');
    if (_aadhaarBytes == null) return _fail('Upload a clear photo of your Aadhaar card');
    if (_selfieBytes == null) return _fail('Take a clear selfie of your face');
    if (_accNo.text.trim() != _accNo2.text.trim()) {
      return _fail('Account numbers do not match');
    }
    if (Validators.normName(_name.text) != Validators.normName(_aadhaarName.text)) {
      return _fail('The name on your Aadhaar must match your account name exactly');
    }
    if (_minutes(_end) <= _minutes(_start)) {
      return _fail('Shift end time must be after the start time');
    }
    if (!_confirmShift) return _fail('Please confirm your shift timing');
    if (!_consent) return _fail('Please accept the Aadhaar verification consent');
    if (!_terms) return _fail('Please accept the Terms and Conditions');

    setState(() => _busy = true);
    final pin = await PincodeService.lookup(_pincode.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (pin == null) {
      return _fail('We could not find this pincode. Check it and try again.');
    }
    _pin = pin;
    setState(() => _step = 1);
  }

  // ---------- Step 1 -> 2 ----------
  String _code = '';

  Future<void> _sendOtp() async {
    _code = AppOtp.generate();
    _otp.clear();
    setState(() => _step = 2);
    await AppOtp.show(context, _code);
  }

  void _startCooldown() {
    _timer?.cancel();
    setState(() => _cooldown = 45);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _cooldown--);
      if (_cooldown <= 0) t.cancel();
    });
  }

  // ---------- Step 2: verify + create everything ----------
  Future<void> _verifyAndCreate() async {
    final code = _otp.text.trim();
    if (code.length < 6) {
      snack(context, 'Enter the 6-digit OTP from the popup', error: true);
      return;
    }
    setState(() {
      _busy = true;
      _progress = 'Verifying code...';
    });
    try {
      if (code != _code) throw 'Wrong OTP. Please check the code in the popup.';
      final res = await supabase.auth.signUp(
        email: _email.text.trim(),
        password: _password.text,
        data: {
          'role': 'technician',
          'name': _name.text.trim(),
          'phone': _phone.text.trim(),
          'pincode': _pin!.pincode,
          'lat': _pin!.lat,
          'lng': _pin!.lng,
        },
      );
      if (res.user != null && (res.user!.identities ?? []).isEmpty) {
        throw 'This email is already registered. Please log in instead.';
      }
      if (res.session == null) {
        throw 'Sign-up needs "Confirm email" switched OFF in Supabase (Authentication > Sign In / Providers > Email).';
      }
      final user = res.user ?? supabase.auth.currentUser;
      if (user == null) throw 'Could not sign you in. Please try again.';
      await _saveEverything(user.id);

      if (!mounted) return;
      snack(context, 'Account created! Our team will review your application.');
      Navigator.of(context).popUntil((r) => r.isFirst);
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } on PostgrestException catch (e) {
      if (mounted) {
        snack(context, 'Saved partly: ${e.message}. Tap the button again to retry.',
            error: true);
      }
    } on StorageException catch (e) {
      if (mounted) {
        snack(context, 'Photo upload failed: ${e.message}. Tap the button again to retry.',
            error: true);
      }
    } catch (e) {
      if (mounted) snack(context, '$e', error: true);
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  Future<void> _saveEverything(String uid) async {
    // Make sure this email is not already a customer account.
    final prof = await supabase.from('profiles').select('role').eq('id', uid).single();
    if (prof['role'] != 'technician') {
      await signOutAll();
      throw 'This email already has a customer account. Please use a different email.';
    }

    if (mounted) setState(() => _progress = 'Uploading Aadhaar photo privately...');
    final isPng = _aadhaarFile.toLowerCase().endsWith('.png');
    final path =
        '$uid/aadhaar_${DateTime.now().millisecondsSinceEpoch}.${isPng ? 'png' : 'jpg'}';
    await supabase.storage.from('kyc').uploadBinary(
          path,
          _aadhaarBytes!,
          fileOptions: FileOptions(contentType: isPng ? 'image/png' : 'image/jpeg'),
        );

    if (mounted) setState(() => _progress = 'Uploading your selfie privately...');
    final selfiePath = '$uid/selfie_${DateTime.now().millisecondsSinceEpoch}.jpg';
    await supabase.storage.from('kyc').uploadBinary(
          selfiePath,
          _selfieBytes!,
          fileOptions: const FileOptions(contentType: 'image/jpeg'),
        );

    if (mounted) setState(() => _progress = 'Saving your application...');
    await supabase.from('profiles').update({
      'name': _name.text.trim(),
      'phone': _phone.text.trim(),
      'pincode': _pin!.pincode,
      'lat': _pin!.lat,
      'lng': _pin!.lng,
    }).eq('id', uid);

    await supabase.from('technician_profiles').upsert({
      'id': uid,
      'name': _name.text.trim(),
      'hourly_rate': double.parse(_rate.text.trim()),
      'experience_years': int.parse(_experience.text.trim()),
      'shift_start': _sql(_start),
      'shift_end': _sql(_end),
    });

    await supabase.from('technician_services').delete().eq('technician_id', uid);
    await supabase.from('technician_services').insert(
          _selected.map((s) => {'technician_id': uid, 'service_id': s}).toList(),
        );

    final digits = _aadhaarNo.text.replaceAll(RegExp(r'\s'), '');
    await supabase.from('technician_kyc').upsert({
      'id': uid,
      'aadhaar_last4': digits.substring(8),
      'aadhaar_name': _aadhaarName.text.trim(),
      'aadhaar_image_path': path,
      'selfie_image_path': selfiePath,
      'bank_holder_name': _bankHolder.text.trim(),
      'bank_name': _bankName.text.trim(),
      'bank_account_no': _accNo.text.trim(),
      'bank_ifsc': _ifsc.text.trim().toUpperCase(),
      'upi_id': _upi.text.trim().isEmpty ? null : _upi.text.trim(),
      'shift_confirmed': _confirmShift,
      'consent': _consent,
    });
  }

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    final titles = ['Technician application', 'Review your application', 'Enter your OTP'];
    return Scaffold(
      appBar: AppBar(title: Text(titles[_step])),
      body: Constrained(
        maxWidth: 600,
        child: _step == 0
            ? _detailsStep()
            : _step == 1
                ? _reviewStep()
                : _otpStep(),
      ),
    );
  }

  Widget _section(String text) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(text,
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: kTeal)),
      );

  Widget _detailsStep() {
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Fill in your details. After you review them, you will get an OTP in a popup '
            'in this app to create your account.',
            style: TextStyle(color: Colors.black54),
          ),
          _section('About you'),
          TextFormField(
            controller: _name,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
                labelText: 'Full name (account name)', prefixIcon: Icon(Icons.badge)),
            validator: (v) =>
                (v == null || v.trim().length < 3) ? 'Enter your full name' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
                labelText: 'Phone number', prefixIcon: Icon(Icons.phone)),
            validator: (v) => (v == null || v.trim().length < 10)
                ? 'Enter a valid phone number'
                : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
                labelText: 'Email (we send the OTP here)',
                prefixIcon: Icon(Icons.email)),
            validator: (v) =>
                (v == null || !Validators.email(v)) ? 'Enter a valid email' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _password,
            obscureText: _hidePassword,
            decoration: InputDecoration(
              labelText: 'Create a password',
              prefixIcon: const Icon(Icons.lock),
              suffixIcon: IconButton(
                icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _hidePassword = !_hidePassword),
              ),
            ),
            validator: (v) =>
                (v == null || v.length < 6) ? 'At least 6 characters' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _pincode,
            keyboardType: TextInputType.number,
            maxLength: 6,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Pincode where you work',
              helperText: 'You will get jobs within 10 km of this pincode',
              prefixIcon: Icon(Icons.pin_drop),
              counterText: '',
            ),
            validator: (v) => (v == null || !PincodeService.isValid(v))
                ? 'Enter a valid 6-digit pincode'
                : null,
          ),
          _section('Aadhaar verification'),
          TextFormField(
            controller: _aadhaarName,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
                labelText: 'Name exactly as on Aadhaar',
                prefixIcon: Icon(Icons.perm_identity)),
            validator: (v) =>
                (v == null || v.trim().length < 3) ? 'Enter the name on your Aadhaar' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _aadhaarNo,
            keyboardType: TextInputType.number,
            maxLength: 12,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Aadhaar number (12 digits)',
              prefixIcon: Icon(Icons.credit_card),
              counterText: '',
            ),
            validator: (v) => (v == null || !Validators.aadhaar(v))
                ? 'Enter a valid 12-digit Aadhaar number'
                : null,
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Aadhaar card photo',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                if (_aadhaarBytes != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.memory(_aadhaarBytes!, height: 160, fit: BoxFit.cover),
                  ),
                if (_aadhaarBytes != null) const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _pickAadhaar,
                  icon: const Icon(Icons.upload_file),
                  label: Text(_aadhaarBytes == null ? 'Upload photo' : 'Change photo'),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Stored privately. Only the Fixeaze verification team can view it.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
          _section('Selfie'),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Your selfie', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                if (_selfieBytes != null)
                  Center(
                    child: ClipOval(
                      child: Image.memory(_selfieBytes!,
                          height: 120, width: 120, fit: BoxFit.cover),
                    ),
                  ),
                if (_selfieBytes != null) const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _pickSelfie,
                  icon: const Icon(Icons.photo_camera_front),
                  label: Text(_selfieBytes == null ? 'Take selfie' : 'Retake selfie'),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Face clearly visible, good light, no sunglasses. We compare it with '
                  'your Aadhaar photo. Stored privately.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
          _section('Bank account details (for your payouts)'),
          TextFormField(
            controller: _bankHolder,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
                labelText: 'Account holder name', prefixIcon: Icon(Icons.person_outline)),
            validator: (v) =>
                (v == null || v.trim().length < 3) ? 'Enter the account holder name' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _bankName,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
                labelText: 'Bank name', prefixIcon: Icon(Icons.account_balance)),
            validator: (v) =>
                (v == null || v.trim().length < 2) ? 'Enter your bank name' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _accNo,
            keyboardType: TextInputType.number,
            maxLength: 18,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Account number',
              prefixIcon: Icon(Icons.pin),
              counterText: '',
            ),
            validator: (v) => (v == null || !Validators.bankAccount(v))
                ? 'Enter a valid account number (9 to 18 digits)'
                : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _accNo2,
            keyboardType: TextInputType.number,
            maxLength: 18,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Re-enter account number',
              prefixIcon: Icon(Icons.pin),
              counterText: '',
            ),
            validator: (v) =>
                (v ?? '').trim() != _accNo.text.trim() ? 'Account numbers do not match' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _ifsc,
            textCapitalization: TextCapitalization.characters,
            maxLength: 11,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9]')),
            ],
            decoration: const InputDecoration(
              labelText: 'IFSC code',
              helperText: 'Example: SBIN0001234',
              prefixIcon: Icon(Icons.numbers),
              counterText: '',
            ),
            validator: (v) =>
                (v == null || !Validators.ifsc(v)) ? 'Enter a valid 11-character IFSC' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _upi,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'UPI ID (optional)',
              prefixIcon: Icon(Icons.qr_code),
            ),
            validator: (v) => (v == null || v.trim().isEmpty || Validators.upi(v))
                ? null
                : 'Enter a valid UPI ID like name@bank',
          ),
          const SizedBox(height: 4),
          const Text(
            'Stored privately. Only the Fixeaze team can see it.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
          _section('Your work'),
          const Text('Services you provide (select one or more)',
              style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          if (_loadingServices)
            const Center(child: CircularProgressIndicator())
          else if (_servicesError != null)
            ErrorState(error: _servicesError!, onRetry: _loadServices)
          else
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: _services.map((s) {
                final id = s['id'] as String;
                return FilterChip(
                  label: Text((s['name'] ?? '').toString()),
                  selected: _selected.contains(id),
                  onSelected: (on) =>
                      setState(() => on ? _selected.add(id) : _selected.remove(id)),
                );
              }).toList(),
            ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: _experience,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                      labelText: 'Experience (years)', prefixIcon: Icon(Icons.timeline)),
                  validator: (v) {
                    final n = int.tryParse((v ?? '').trim());
                    return (n == null || n < 0 || n > 60) ? 'Enter 0 to 60' : null;
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _rate,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                      labelText: 'Hourly rate (₹)', prefixIcon: Icon(Icons.currency_rupee)),
                  validator: (v) {
                    final n = int.tryParse((v ?? '').trim());
                    return (n == null || n < 50 || n > 5000) ? '50 to 5000' : null;
                  },
                ),
              ),
            ],
          ),
          _section('Shift timing'),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _pickTime(true),
                  icon: const Icon(Icons.wb_sunny_outlined, size: 18),
                  label: Text('Start ${_start.format(context)}'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _pickTime(false),
                  icon: const Icon(Icons.nights_stay_outlined, size: 18),
                  label: Text('End ${_end.format(context)}'),
                ),
              ),
            ],
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            value: _confirmShift,
            onChanged: (v) => setState(() => _confirmShift = v ?? false),
            title: const Text('I confirm I will be available during this shift'),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            value: _consent,
            onChanged: (v) => setState(() => _consent = v ?? false),
            title: const Text(
                'I agree that Fixeaze may use my Aadhaar details only to verify my identity'),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            value: _terms,
            onChanged: (v) => setState(() => _terms = v ?? false),
            title: const Text('I have read and agree to the Terms and Conditions'),
            subtitle: Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                style: TextButton.styleFrom(
                    padding: EdgeInsets.zero, minimumSize: const Size(0, 28)),
                onPressed: _showTerms,
                child: const Text('Read Terms and Conditions'),
              ),
            ),
          ),
          if (_formError != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(_formError!, style: const TextStyle(color: Colors.red)),
            ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: (_busy || !_terms) ? null : _goReview,
            child: _busy
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('Review application'),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 130,
              child: Text(label, style: const TextStyle(color: Colors.black54)),
            ),
            Expanded(
              child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      );

  Widget _reviewStep() {
    final names = _services
        .where((s) => _selected.contains(s['id']))
        .map((s) => (s['name'] ?? '').toString())
        .join(', ');
    final digits = _aadhaarNo.text.replaceAll(RegExp(r'\s'), '');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _row('Name', _name.text.trim()),
                _row('Phone', _phone.text.trim()),
                _row('Email', _email.text.trim()),
                _row('Pincode', '${_pin!.pincode}  ${_pin!.label}'),
                const Divider(),
                _row('Aadhaar name', _aadhaarName.text.trim()),
                _row('Aadhaar number', 'XXXX XXXX ${digits.substring(8)}'),
                if (_aadhaarBytes != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.memory(_aadhaarBytes!, height: 120, fit: BoxFit.cover),
                    ),
                  ),
                if (_selfieBytes != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      children: [
                        const SizedBox(
                            width: 130,
                            child: Text('Selfie', style: TextStyle(color: Colors.black54))),
                        ClipOval(
                          child: Image.memory(_selfieBytes!,
                              height: 64, width: 64, fit: BoxFit.cover),
                        ),
                      ],
                    ),
                  ),
                const Divider(),
                _row('Account holder', _bankHolder.text.trim()),
                _row('Bank', _bankName.text.trim()),
                _row('Account number',
                    'XXXXXX${_accNo.text.trim().substring(_accNo.text.trim().length - 4)}'),
                _row('IFSC', _ifsc.text.trim().toUpperCase()),
                if (_upi.text.trim().isNotEmpty) _row('UPI ID', _upi.text.trim()),
                const Divider(),
                _row('Services', names),
                _row('Experience', '${_experience.text.trim()} years'),
                _row('Hourly rate', '₹${_rate.text.trim()} per hour'),
                _row('Shift', '${_start.format(context)} to ${_end.format(context)}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Next you will see an OTP in a popup here. Type it to create your account. '
          'Our team then checks your Aadhaar against your name before you can accept jobs.',
          style: TextStyle(color: Colors.black54),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _busy ? null : _sendOtp,
          icon: const Icon(Icons.sms),
          label: _busy
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('Get my OTP'),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: _busy ? null : () => setState(() => _step = 0),
          child: const Text('Edit details'),
        ),
      ],
    );
  }

  Widget _otpStep() {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Icon(Icons.pin, size: 56, color: kTeal),
        const SizedBox(height: 12),
        const Text('Enter the OTP shown in the popup',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
        const SizedBox(height: 20),
        TextField(
          controller: _otp,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          maxLength: 8,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          style: const TextStyle(fontSize: 28, letterSpacing: 8),
          decoration: const InputDecoration(hintText: '------', counterText: ''),
          onSubmitted: (_) => _busy ? null : _verifyAndCreate(),
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _busy ? null : _verifyAndCreate,
          child: _busy
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                    const SizedBox(width: 10),
                    Flexible(child: Text(_progress.isEmpty ? 'Please wait...' : _progress)),
                  ],
                )
              : const Text('Verify and create account'),
        ),
        const SizedBox(height: 8),
        TextButton(
          onPressed: _busy ? null : () => AppOtp.show(context, _code),
          child: const Text('Show the OTP again'),
        ),
        TextButton(
          onPressed: _busy ? null : () => setState(() => _step = 1),
          child: const Text('Back'),
        ),
      ],
    );
  }
}
