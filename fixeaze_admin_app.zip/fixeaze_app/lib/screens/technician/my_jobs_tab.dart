import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../chat_screen.dart';
import 'job_flow_screen.dart';

class _JobsData {
  final List<Map<String, dynamic>> jobs;
  final Map<String, Map<String, dynamic>> customers; // by customer id
  _JobsData(this.jobs, this.customers);
}

class MyJobsTab extends StatefulWidget {
  const MyJobsTab({super.key});

  @override
  State<MyJobsTab> createState() => _MyJobsTabState();
}

class _MyJobsTabState extends State<MyJobsTab> {
  late Future<_JobsData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_JobsData> _load() async {
    final uid = supabase.auth.currentUser!.id;
    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price)')
        .eq('technician_id', uid)
        .order('scheduled_at', ascending: false);
    final jobs = List<Map<String, dynamic>>.from(rows);

    final ids = jobs.map((j) => j['customer_id']).whereType<String>().toSet().toList();
    final customers = <String, Map<String, dynamic>>{};
    if (ids.isNotEmpty) {
      final crows =
          await supabase.from('profiles').select('id, name, phone').inFilter('id', ids);
      for (final r in crows) {
        customers[r['id'] as String] = Map<String, dynamic>.from(r);
      }
    }
    return _JobsData(jobs, customers);
  }

  Future<void> _open(Uri uri) async {
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
      snack(context, 'Could not open that link', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_JobsData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final data = snap.data!;
        if (data.jobs.isEmpty) {
          return const EmptyState(
            icon: Icons.assignment,
            text: 'You have no jobs yet.\nAccept one from the Open jobs tab.',
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: data.jobs.length,
            itemBuilder: (context, i) {
              final job = data.jobs[i];
              final status = (job['status'] ?? '').toString();
              final service = job['services'] as Map<String, dynamic>?;
              final customer = data.customers[job['customer_id']];
              final phone = (customer?['phone'] ?? '').toString();
              final address = (job['address'] ?? '').toString();
              final photos = List<String>.from(job['photos'] ?? const []);

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text((service?['name'] ?? 'Service').toString(),
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold)),
                          ),
                          StatusChip(status),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(bookingTypeLabel(job),
                          style: TextStyle(
                              color: Colors.teal.shade700,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(job['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.person, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((customer?['name'] ?? 'Customer').toString())),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(address)),
                      ]),
                      if ((job['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${job['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      if (status == 'accepted' || status == 'in_progress') ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            if (phone.isNotEmpty)
                              OutlinedButton.icon(
                                onPressed: () => _open(Uri.parse('tel:$phone')),
                                icon: const Icon(Icons.call, size: 18),
                                label: const Text('Call'),
                              ),
                            OutlinedButton.icon(
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    bookingId: job['id'] as String,
                                    title:
                                        'Chat with ${(customer?['name'] ?? 'customer').toString()}',
                                  ),
                                ),
                              ),
                              icon: const Icon(Icons.chat_bubble_outline, size: 18),
                              label: const Text('Chat'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _open(Uri.parse(
                                  'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(address)}')),
                              icon: const Icon(Icons.map, size: 18),
                              label: const Text('Map'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            onPressed: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TechJobScreen(bookingId: job['id'] as String),
                                ),
                              );
                              if (mounted) _refresh();
                            },
                            icon: const Icon(Icons.play_arrow),
                            label: Text(status == 'accepted' && (job['job_stage'] ?? '').toString().isEmpty
                                ? 'Start job steps'
                                : 'Open job'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
