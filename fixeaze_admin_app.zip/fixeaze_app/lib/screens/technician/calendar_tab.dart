import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../widgets/common.dart';

/// Month calendar: shows booked days, free days, leave days and custom shifts.
/// The technician can apply for leave, change a day's shift, or change the regular shift.
class CalendarTab extends StatefulWidget {
  const CalendarTab({super.key});

  @override
  State<CalendarTab> createState() => _CalendarTabState();
}

class _CalendarTabState extends State<CalendarTab> {
  static const _booked = Color(0xFF1E88E5);
  static const _free = Color(0xFF43A047);
  static const _leave = Color(0xFFE53935);
  static const _custom = Color(0xFF8E24AA);

  late DateTime _month;
  late DateTime _selected;
  bool _loading = true;
  bool _busy = false;
  Object? _error;

  final Map<String, List<Map<String, dynamic>>> _bookings = {};
  final Map<String, Map<String, dynamic>> _schedule = {};
  TimeOfDay _defStart = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _defEnd = const TimeOfDay(hour: 18, minute: 0);

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _month = DateTime(now.year, now.month, 1);
    _selected = DateTime(now.year, now.month, now.day);
    _load();
  }

  // ---------- helpers ----------
  String _key(DateTime d) => DateFormat('yyyy-MM-dd').format(d);
  DateTime get _today {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  TimeOfDay _parse(dynamic v, TimeOfDay fallback) {
    final p = (v ?? '').toString().split(':');
    if (p.length < 2) return fallback;
    return TimeOfDay(
      hour: int.tryParse(p[0]) ?? fallback.hour,
      minute: int.tryParse(p[1]) ?? fallback.minute,
    );
  }

  String _sql(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:00';
  int _mins(TimeOfDay t) => t.hour * 60 + t.minute;

  bool _isActive(Map<String, dynamic> b) =>
      b['status'] == 'accepted' || b['status'] == 'in_progress';

  List<Map<String, dynamic>> _bookingsOn(DateTime d) => _bookings[_key(d)] ?? const [];
  List<Map<String, dynamic>> _activeOn(DateTime d) =>
      _bookingsOn(d).where(_isActive).toList();

  // ---------- loading ----------
  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = supabase.auth.currentUser!.id;
      final from = DateTime(_month.year, _month.month, 1);
      final to = DateTime(_month.year, _month.month + 1, 1);

      final b = await supabase
          .from('bookings')
          .select('id, status, scheduled_at, address, booking_type, hours, services(name)')
          .eq('technician_id', uid)
          .inFilter('status', ['accepted', 'in_progress', 'completed'])
          .gte('scheduled_at', from.toUtc().toIso8601String())
          .lt('scheduled_at', to.toUtc().toIso8601String())
          .order('scheduled_at');

      final s = await supabase
          .from('technician_schedule')
          .select()
          .eq('technician_id', uid)
          .gte('day', _key(from))
          .lt('day', _key(to));

      final tp = await supabase
          .from('technician_profiles')
          .select('shift_start, shift_end')
          .eq('id', uid)
          .maybeSingle();

      _bookings.clear();
      for (final r in b) {
        final m = Map<String, dynamic>.from(r);
        final d = DateTime.parse(m['scheduled_at'].toString()).toLocal();
        _bookings.putIfAbsent(_key(d), () => []).add(m);
      }
      _schedule.clear();
      for (final r in s) {
        final m = Map<String, dynamic>.from(r);
        _schedule[m['day'].toString()] = m;
      }
      if (tp != null) {
        _defStart = _parse(tp['shift_start'], _defStart);
        _defEnd = _parse(tp['shift_end'], _defEnd);
      }
    } catch (e) {
      _error = e;
    }
    if (mounted) setState(() => _loading = false);
  }

  void _changeMonth(int delta) {
    setState(() {
      _month = DateTime(_month.year, _month.month + delta, 1);
      _selected = (_month.year == _today.year && _month.month == _today.month)
          ? _today
          : _month;
    });
    _load();
  }

  Future<void> _run(Future<void> Function() action, String okMessage) async {
    setState(() => _busy = true);
    try {
      await action();
      if (mounted) snack(context, okMessage);
      await _load();
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, '$e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ---------- actions ----------
  Future<String?> _askReason() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apply for leave'),
        content: TextField(
          controller: c,
          maxLength: 120,
          decoration: const InputDecoration(labelText: 'Reason (optional)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Back')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apply')),
        ],
      ),
    );
    final text = c.text.trim();
    return ok == true ? text : null;
  }

  Future<void> _applyLeaveForDay(DateTime day) async {
    if (_activeOn(day).isNotEmpty) {
      snack(context, 'You have a booking on this day, so you cannot take leave.',
          error: true);
      return;
    }
    final reason = await _askReason();
    if (reason == null) return;
    await _run(() async {
      await supabase.from('technician_schedule').upsert({
        'technician_id': supabase.auth.currentUser!.id,
        'day': _key(day),
        'kind': 'leave',
        'shift_start': null,
        'shift_end': null,
        'reason': reason.isEmpty ? null : reason,
      }, onConflict: 'technician_id,day');
    }, 'Leave applied for ${DateFormat('d MMM').format(day)}');
  }

  Future<void> _applyLeaveRange() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: _today,
      lastDate: _today.add(const Duration(days: 365)),
      helpText: 'Select leave days',
    );
    if (range == null) return;
    final reason = await _askReason();
    if (reason == null) return;

    final uid = supabase.auth.currentUser!.id;
    await _run(() async {
      final start = DateTime(range.start.year, range.start.month, range.start.day);
      final endExcl =
          DateTime(range.end.year, range.end.month, range.end.day + 1);
      final b = await supabase
          .from('bookings')
          .select('scheduled_at')
          .eq('technician_id', uid)
          .inFilter('status', ['accepted', 'in_progress'])
          .gte('scheduled_at', start.toUtc().toIso8601String())
          .lt('scheduled_at', endExcl.toUtc().toIso8601String());
      final busy = <String>{
        for (final r in b)
          _key(DateTime.parse(r['scheduled_at'].toString()).toLocal()),
      };

      final rows = <Map<String, dynamic>>[];
      for (var d = start; d.isBefore(endExcl); d = DateTime(d.year, d.month, d.day + 1)) {
        if (busy.contains(_key(d))) continue;
        rows.add({
          'technician_id': uid,
          'day': _key(d),
          'kind': 'leave',
          'shift_start': null,
          'shift_end': null,
          'reason': reason.isEmpty ? null : reason,
        });
      }
      if (rows.isEmpty) throw 'You have bookings on all of those days.';
      await supabase.from('technician_schedule').upsert(rows, onConflict: 'technician_id,day');
      if (busy.isNotEmpty && mounted) {
        snack(context, '${busy.length} day(s) skipped because you have bookings.');
      }
    }, 'Leave applied');
  }

  Future<void> _clearDay(DateTime day, String message) async {
    await _run(() async {
      await supabase
          .from('technician_schedule')
          .delete()
          .eq('technician_id', supabase.auth.currentUser!.id)
          .eq('day', _key(day));
    }, message);
  }

  Future<TimeOfDay?> _pickTime(String help, TimeOfDay initial) =>
      showTimePicker(context: context, initialTime: initial, helpText: help);

  Future<void> _customShift(DateTime day) async {
    final cur = _schedule[_key(day)];
    final s0 = cur != null && cur['kind'] == 'shift'
        ? _parse(cur['shift_start'], _defStart)
        : _defStart;
    final e0 = cur != null && cur['kind'] == 'shift'
        ? _parse(cur['shift_end'], _defEnd)
        : _defEnd;
    final s = await _pickTime('Shift start', s0);
    if (s == null || !mounted) return;
    final e = await _pickTime('Shift end', e0);
    if (e == null) return;
    if (_mins(e) <= _mins(s)) {
      if (mounted) snack(context, 'Shift end must be after the start', error: true);
      return;
    }
    await _run(() async {
      await supabase.from('technician_schedule').upsert({
        'technician_id': supabase.auth.currentUser!.id,
        'day': _key(day),
        'kind': 'shift',
        'shift_start': _sql(s),
        'shift_end': _sql(e),
        'reason': null,
      }, onConflict: 'technician_id,day');
    }, 'Shift saved for ${DateFormat('d MMM').format(day)}');
  }

  Future<void> _changeRegularShift() async {
    final s = await _pickTime('Regular shift start', _defStart);
    if (s == null || !mounted) return;
    final e = await _pickTime('Regular shift end', _defEnd);
    if (e == null) return;
    if (_mins(e) <= _mins(s)) {
      if (mounted) snack(context, 'Shift end must be after the start', error: true);
      return;
    }
    await _run(() async {
      await supabase.from('technician_profiles').update({
        'shift_start': _sql(s),
        'shift_end': _sql(e),
      }).eq('id', supabase.auth.currentUser!.id);
    }, 'Regular shift updated');
  }

  // ---------- UI ----------
  Widget _legendDot(Color c, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(color: c, shape: BoxShape.circle),
          ),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 12)),
        ],
      );

  Widget _dayCell(DateTime day) {
    final k = _key(day);
    final isPast = day.isBefore(_today);
    final isToday = day == _today;
    final isSel = day == _selected;
    final active = _activeOn(day).length;
    final all = _bookingsOn(day).length;
    final sch = _schedule[k];
    final onLeave = sch != null && sch['kind'] == 'leave';
    final custom = sch != null && sch['kind'] == 'shift';

    Color? bg;
    if (onLeave) bg = _leave.withOpacity(0.15);

    Widget marker;
    if (onLeave) {
      marker = const Icon(Icons.beach_access, size: 12, color: _leave);
    } else if (all > 0) {
      marker = Container(
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
        decoration: BoxDecoration(
          color: active > 0 ? _booked : Colors.grey,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text('$all',
            style: const TextStyle(color: Colors.white, fontSize: 10)),
      );
    } else if (!isPast) {
      marker = Container(
        width: 8,
        height: 8,
        decoration: const BoxDecoration(color: _free, shape: BoxShape.circle),
      );
    } else {
      marker = const SizedBox(height: 8);
    }

    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => setState(() => _selected = day),
      child: Container(
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: bg ?? (isPast ? Colors.black.withOpacity(0.03) : Colors.white),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSel
                ? Theme.of(context).colorScheme.primary
                : (isToday ? Colors.black45 : Colors.black12),
            width: isSel ? 2 : 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('${day.day}',
                style: TextStyle(
                  fontWeight: isToday ? FontWeight.bold : FontWeight.w500,
                  color: isPast ? Colors.black45 : Colors.black87,
                )),
            const SizedBox(height: 3),
            marker,
            if (custom)
              const Padding(
                padding: EdgeInsets.only(top: 2),
                child: Icon(Icons.schedule, size: 10, color: _custom),
              ),
          ],
        ),
      ),
    );
  }

  Widget _grid() {
    final first = _month;
    final daysIn = DateTime(_month.year, _month.month + 1, 0).day;
    final offset = first.weekday % 7; // Sunday first
    final cells = <Widget>[];
    for (var i = 0; i < offset; i++) {
      cells.add(const SizedBox());
    }
    for (var d = 1; d <= daysIn; d++) {
      cells.add(_dayCell(DateTime(_month.year, _month.month, d)));
    }
    return GridView.count(
      crossAxisCount: 7,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 0.82,
      children: cells,
    );
  }

  Widget _selectedCard() {
    final day = _selected;
    final k = _key(day);
    final sch = _schedule[k];
    final onLeave = sch != null && sch['kind'] == 'leave';
    final custom = sch != null && sch['kind'] == 'shift';
    final isPast = day.isBefore(_today);
    final list = _bookingsOn(day);
    final active = _activeOn(day).length;

    String shiftText;
    if (onLeave) {
      final why = (sch!['reason'] ?? '').toString();
      shiftText = why.isEmpty ? 'On leave' : 'On leave ($why)';
    } else if (custom) {
      shiftText =
          'Custom shift: ${_parse(sch!['shift_start'], _defStart).format(context)} to ${_parse(sch['shift_end'], _defEnd).format(context)}';
    } else {
      shiftText =
          'Regular shift: ${_defStart.format(context)} to ${_defEnd.format(context)}';
    }

    return Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(DateFormat('EEEE, d MMMM y').format(day),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Row(children: [
              Icon(onLeave ? Icons.beach_access : Icons.schedule,
                  size: 16, color: onLeave ? _leave : Colors.black45),
              const SizedBox(width: 6),
              Expanded(child: Text(shiftText)),
            ]),
            const SizedBox(height: 10),
            if (list.isEmpty)
              Text(
                isPast ? 'No bookings on this day.' : 'No bookings yet. You are free.',
                style: const TextStyle(color: Colors.black54),
              )
            else
              ...list.map((b) {
                final t = DateFormat('h:mm a')
                    .format(DateTime.parse(b['scheduled_at'].toString()).toLocal());
                final svc = b['services'] is Map ? b['services']['name'] : null;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      const Icon(Icons.work_outline, size: 16, color: _booked),
                      const SizedBox(width: 6),
                      Expanded(child: Text('$t  ${svc ?? 'Service'}')),
                      StatusChip((b['status'] ?? '').toString()),
                    ],
                  ),
                );
              }),
            if (!isPast) ...[
              const Divider(height: 24),
              if (onLeave)
                OutlinedButton.icon(
                  onPressed: _busy ? null : () => _clearDay(day, 'Leave cancelled'),
                  icon: const Icon(Icons.undo),
                  label: const Text('Cancel leave for this day'),
                )
              else ...[
                if (active > 0)
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Text('You have a booking on this day, so leave is not possible.',
                        style: TextStyle(color: Colors.black54, fontSize: 13)),
                  ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: _leave, minimumSize: const Size(0, 44)),
                      onPressed: (_busy || active > 0) ? null : () => _applyLeaveForDay(day),
                      icon: const Icon(Icons.beach_access, size: 18),
                      label: const Text('Apply leave'),
                    ),
                    OutlinedButton.icon(
                      onPressed: _busy ? null : () => _customShift(day),
                      icon: const Icon(Icons.schedule, size: 18),
                      label: const Text('Change shift'),
                    ),
                    if (custom)
                      TextButton(
                        onPressed: _busy ? null : () => _clearDay(day, 'Back to regular shift'),
                        child: const Text('Use regular shift'),
                      ),
                  ],
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _bookings.isEmpty && _schedule.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) return ErrorState(error: _error!, onRetry: _load);

    const dows = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Row(
            children: [
              IconButton(
                  onPressed: () => _changeMonth(-1), icon: const Icon(Icons.chevron_left)),
              Expanded(
                child: Text(
                  DateFormat('MMMM y').format(_month),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              IconButton(
                  onPressed: () => _changeMonth(1), icon: const Icon(Icons.chevron_right)),
            ],
          ),
          Row(
            children: dows
                .map((d) => Expanded(
                      child: Center(
                        child: Text(d,
                            style: const TextStyle(
                                fontWeight: FontWeight.w600, color: Colors.black54)),
                      ),
                    ))
                .toList(),
          ),
          const SizedBox(height: 4),
          _grid(),
          const SizedBox(height: 6),
          Wrap(
            spacing: 14,
            runSpacing: 4,
            alignment: WrapAlignment.center,
            children: [
              _legendDot(_booked, 'Booked'),
              _legendDot(_free, 'Free'),
              _legendDot(_leave, 'Leave'),
              _legendDot(_custom, 'Custom shift'),
            ],
          ),
          const SizedBox(height: 12),
          _selectedCard(),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: _busy ? null : _applyLeaveRange,
                icon: const Icon(Icons.date_range),
                label: const Text('Leave for several days'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _changeRegularShift,
                icon: const Icon(Icons.access_time),
                label: Text(
                    'Regular shift: ${_defStart.format(context)} - ${_defEnd.format(context)}'),
              ),
            ],
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
