import 'dart:async';

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../config.dart';
import '../../services/cloudinary_service.dart';
import '../../services/job_service.dart';
import '../../widgets/common.dart';

/// The technician's step-by-step screen for one job:
/// arrive + selfie -> start OTP -> before photos -> parts -> after photos ->
/// customer confirms parts -> QR / cash -> end OTP -> done.
class TechJobScreen extends StatefulWidget {
  final String bookingId;
  const TechJobScreen({super.key, required this.bookingId});

  /// Which job screen is open right now (so the watcher does not open it twice).
  static String? openId;

  @override
  State<TechJobScreen> createState() => _TechJobScreenState();
}

class _TechJobScreenState extends State<TechJobScreen> {
  Map<String, dynamic>? _b;
  List<Map<String, dynamic>> _parts = [];
  Map<String, dynamic>? _customer;
  Map<String, dynamic>? _pay;
  String? _endOtp;
  String? _error;
  bool _busy = false;
  bool _loading = false;
  Timer? _timer;

  final _otp = TextEditingController();
  final _pName = TextEditingController();
  final _pQty = TextEditingController(text: '1');
  final _pPrice = TextEditingController();

  @override
  void initState() {
    super.initState();
    TechJobScreen.openId = widget.bookingId;
    _load();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _load());
  }

  @override
  void dispose() {
    if (TechJobScreen.openId == widget.bookingId) TechJobScreen.openId = null;
    _timer?.cancel();
    _otp.dispose();
    _pName.dispose();
    _pQty.dispose();
    _pPrice.dispose();
    super.dispose();
  }

  String get _id => widget.bookingId;
  String get _stage => (_b?['job_stage'] ?? 'assigned').toString();

  Future<void> _load() async {
    if (_loading || !mounted) return;
    _loading = true;
    try {
      final b = await JobApi.booking(_id);
      final parts = await JobApi.parts(_id);
      Map<String, dynamic>? cust = _customer;
      if (cust == null && b['customer_id'] != null) {
        final c = await supabase
            .from('profiles')
            .select('name, phone')
            .eq('id', b['customer_id'])
            .maybeSingle();
        if (c != null) cust = Map<String, dynamic>.from(c);
      }
      final stage = (b['job_stage'] ?? 'assigned').toString();
      Map<String, dynamic>? pay = _pay;
      if (stage == 'payment_due' || stage == 'payment_check') {
        pay = await JobApi.payInfo(_id);
      }
      String? endOtp;
      if (stage == 'end_otp') endOtp = await JobApi.otp(_id, 'end');
      if (!mounted) return;
      setState(() {
        _b = b;
        _parts = parts;
        _customer = cust;
        _pay = pay;
        _endOtp = endOtp;
        _error = null;
      });
    } catch (e) {
      if (mounted && _b == null) setState(() => _error = JobApi.errText(e));
    } finally {
      _loading = false;
    }
  }

  Future<void> _run(Future<void> Function() action, {String? ok}) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await action();
      if (ok != null && mounted) snack(context, ok);
    } catch (e) {
      if (mounted) snack(context, JobApi.errText(e), error: true);
    }
    if (mounted) setState(() => _busy = false);
    await _load();
  }

  Future<String?> _capture({bool front = false}) async {
    try {
      return await CloudinaryService.captureAndUpload(front: front);
    } catch (e) {
      if (mounted) snack(context, 'Could not upload photo: $e', error: true);
      return null;
    }
  }

  // ---------- actions ----------
  Future<void> _arrive() => _run(() async {
        final url = await _capture(front: true);
        if (url == null) return;
        await JobApi.arrive(_id, url);
      }, ok: 'Selfie saved. The customer now sees an OTP in their app.');

  Future<void> _verify() async {
    final code = _otp.text.trim();
    if (code.length != 6) {
      snack(context, 'Enter the 6-digit OTP from the customer', error: true);
      return;
    }
    await _run(() async {
      final good = await JobApi.verifyStart(_id, code);
      if (!good) throw 'Wrong OTP. Ask the customer to check their app.';
      _otp.clear();
    }, ok: 'OTP correct. You can start the work.');
  }

  Future<void> _addPhoto(String kind) => _run(() async {
        final url = await _capture();
        if (url == null) return;
        await JobApi.addPhoto(_id, kind, url);
      });

  Future<void> _addPart() async {
    final name = _pName.text.trim();
    final qty = int.tryParse(_pQty.text.trim()) ?? 0;
    final price = num.tryParse(_pPrice.text.trim());
    if (name.isEmpty || qty < 1 || price == null || price < 0) {
      snack(context, 'Enter part name, quantity and price per piece', error: true);
      return;
    }
    await _run(() async {
      await JobApi.addPart(_id, name, qty, price);
      _pName.clear();
      _pQty.text = '1';
      _pPrice.clear();
    });
  }

  Future<void> _submitParts() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Send to customer?'),
        content: const Text(
            'The customer will get a popup to confirm the parts and total. '
            'You cannot change them after this unless the customer says no.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Back')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Send')),
        ],
      ),
    );
    if (ok != true) return;
    await _run(() => JobApi.submitParts(_id), ok: 'Sent. Waiting for the customer.');
  }

  // ---------- UI helpers ----------
  List<String> _urls(dynamic v) => v is List ? v.map((e) => e.toString()).toList() : <String>[];

  num get _labour => numOf(_b?['price']);
  num get _partsSum => _parts.fold<num>(0, (s, p) => s + numOf(p['qty']) * numOf(p['price']));

  static num numOf(dynamic v) => v is num ? v : (num.tryParse('${v ?? ''}') ?? 0);

  Widget _card(String title, Widget child, {Color? color}) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        color: color,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              child,
            ],
          ),
        ),
      );

  Widget _bigNote(IconData icon, String text, {Color color = Colors.teal}) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 15))),
        ],
      );

  Widget _steps() {
    const names = ['Arrive', 'OTP', 'Work', 'Parts', 'Pay', 'Done'];
    final idx = {
      'assigned': 0,
      'arrived': 1,
      'working': 2,
      'parts_review': 3,
      'payment_due': 4,
      'payment_check': 4,
      'end_otp': 4,
      'done': 5,
    }[_stage] ?? 0;
    return Row(
      children: List.generate(names.length, (i) {
        final on = i <= idx;
        return Expanded(
          child: Column(
            children: [
              CircleAvatar(
                radius: 12,
                backgroundColor: on ? Colors.teal : Colors.black12,
                child: i < idx
                    ? const Icon(Icons.check, size: 14, color: Colors.white)
                    : Text('${i + 1}',
                        style: TextStyle(
                            fontSize: 11, color: on ? Colors.white : Colors.black54)),
              ),
              const SizedBox(height: 3),
              Text(names[i], style: const TextStyle(fontSize: 10)),
            ],
          ),
        );
      }),
    );
  }

  Widget _photoBlock(String kind, List<String> urls) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        PhotoStrip(
          urls: urls,
          onRemove: (i) => _run(() => JobApi.removePhoto(_id, kind, urls[i])),
        ),
        if (urls.isNotEmpty) const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: (_busy || urls.length >= 6) ? null : () => _addPhoto(kind),
          icon: const Icon(Icons.add_a_photo),
          label: Text(urls.isEmpty ? 'Take $kind photo' : 'Add another'),
        ),
      ],
    );
  }

  Widget _partsBlock({required bool editable}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_parts.isEmpty) const Text('No parts added.', style: TextStyle(color: Colors.black54)),
        for (final p in _parts)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('${p['name']}'),
            subtitle: Text('${p['qty']} x ${money(p['price'])}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(money(numOf(p['qty']) * numOf(p['price'])),
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                if (editable)
                  IconButton(
                    onPressed: _busy ? null : () => _run(() => JobApi.removePart('${p['id']}')),
                    icon: const Icon(Icons.delete_outline, size: 20),
                  ),
              ],
            ),
          ),
        if (editable) ...[
          const Divider(),
          TextField(
            controller: _pName,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Part name', isDense: true),
          ),
          const SizedBox(height: 8),
          Row(children: [
            SizedBox(
              width: 80,
              child: TextField(
                controller: _pQty,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Qty', isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _pPrice,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration:
                    const InputDecoration(labelText: 'Price per piece (Rs)', isDense: true),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _busy ? null : _addPart,
            icon: const Icon(Icons.add),
            label: const Text('Add part'),
          ),
        ],
      ],
    );
  }

  Widget _totals() {
    final gross = _labour + _partsSum;
    Widget row(String a, String b, {bool bold = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(children: [
            Expanded(child: Text(a)),
            Text(b, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
          ]),
        );
    return Column(children: [
      row('Service charge', money(_labour)),
      row('Parts', money(_partsSum)),
      const Divider(),
      row('Customer pays', money(gross), bold: true),
    ]);
  }

  Widget _qrBlock() {
    final info = _pay;
    final upi = (info?['upi_id'] ?? '').toString();
    if (info == null) return const Center(child: CircularProgressIndicator());
    if (upi.isEmpty) {
      return _bigNote(Icons.info_outline,
          'Fixeaze payment details are not set yet. Ask the customer to pay by cash.',
          color: Colors.orange);
    }
    return Column(children: [
      Container(
        padding: const EdgeInsets.all(12),
        color: Colors.white,
        child: QrImageView(data: JobApi.upiLink(info), size: 230),
      ),
      const SizedBox(height: 8),
      Text('Pay to ${info['payee_name']}', style: const TextStyle(color: Colors.black54)),
    ]);
  }

  // ---------- stage views ----------
  List<Widget> _stageViews() {
    final b = _b!;
    final before = _urls(b['before_photos']);
    final after = _urls(b['after_photos']);
    final gross = _labour + _partsSum;

    switch (_stage) {
      case 'assigned':
        return [
          _card(
            'Step 1: Reach the customer',
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _bigNote(Icons.face,
                  'When you reach the customer\'s home, take a selfie. The customer will then get a 6-digit OTP in their app.'),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _busy ? null : _arrive,
                  icon: const Icon(Icons.camera_front),
                  label: const Text('I reached - take selfie'),
                ),
              ),
            ]),
          ),
        ];
      case 'arrived':
        return [
          _card(
            'Step 2: Enter the customer\'s OTP',
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if ((b['arrival_selfie'] ?? '').toString().isNotEmpty)
                PhotoStrip(urls: [b['arrival_selfie'].toString()]),
              const SizedBox(height: 8),
              _bigNote(Icons.sms_outlined,
                  'Ask the customer to open Fixeaze and read out the OTP shown there.'),
              const SizedBox(height: 12),
              TextField(
                controller: _otp,
                keyboardType: TextInputType.number,
                maxLength: 6,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 26, letterSpacing: 8),
                decoration: const InputDecoration(counterText: '', hintText: '------'),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                    onPressed: _busy ? null : _verify, child: const Text('Verify and start work')),
              ),
              TextButton(
                onPressed: _busy ? null : () => _run(() => JobApi.resendStartOtp(_id), ok: 'New OTP sent to the customer'),
                child: const Text('Make a new OTP'),
              ),
            ]),
          ),
        ];
      case 'working':
        return [
          if (b['parts_rejected_at'] != null)
            _card(
              'Customer did not confirm',
              _bigNote(Icons.warning_amber,
                  'The customer said no to the parts list. Talk to them, fix the list, then send it again.',
                  color: Colors.orange),
              color: Colors.orange.shade50,
            ),
          _card('Before work photos', _photoBlock('before', before)),
          _card('Parts used', _partsBlock(editable: true)),
          _card('After work photos', _photoBlock('after', after)),
          _card('Bill so far', _totals()),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _busy ? null : _submitParts,
              icon: const Icon(Icons.send),
              label: const Text('Work finished - send to customer'),
            ),
          ),
          const SizedBox(height: 4),
          const Text('Needs at least one before photo and one after photo.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
        ];
      case 'parts_review':
        return [
          _card(
            'Waiting for the customer',
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _bigNote(Icons.hourglass_top,
                  'The customer has a popup to confirm the parts and total. This screen updates by itself.'),
              const SizedBox(height: 10),
              _partsBlock(editable: false),
              const Divider(),
              _totals(),
            ]),
          ),
        ];
      case 'payment_due':
        return [
          _card(
            'Collect ${money(gross)}',
            Column(children: [
              _bigNote(Icons.check_circle,
                  'The customer confirmed the parts. Show this QR, or take cash. The customer picks how to pay.'),
              const SizedBox(height: 12),
              _qrBlock(),
            ]),
          ),
        ];
      case 'payment_check':
        final cash = (b['payment_method'] ?? '') == 'cash';
        return [
          _card(
            cash ? 'Did you receive cash?' : 'Did the QR payment arrive?',
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(money(gross),
                  style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(cash
                  ? 'The customer says they are paying by cash.'
                  : 'The customer says they are paying by QR. Check your Fixeaze payment before you tap Yes.'),
              if (!cash) ...[const SizedBox(height: 12), Center(child: _qrBlock())],
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _busy ? null : () => _run(() => JobApi.confirmPayment(_id, false)),
                    child: const Text('No'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    onPressed: _busy
                        ? null
                        : () => _run(() => JobApi.confirmPayment(_id, true)),
                    child: Text(cash ? 'Yes, cash received' : 'Yes, received'),
                  ),
                ),
              ]),
            ]),
            color: Colors.amber.shade50,
          ),
        ];
      case 'end_otp':
        return [
          _card(
            'Tell the customer this OTP',
            Column(children: [
              const Text('The customer types it in their app to end the booking.'),
              const SizedBox(height: 12),
              Text(_endOtp ?? '......',
                  style: const TextStyle(
                      fontSize: 40, fontWeight: FontWeight.bold, letterSpacing: 10)),
              const SizedBox(height: 8),
              const Text('Waiting for the customer...', style: TextStyle(color: Colors.black54)),
            ]),
            color: Colors.teal.shade50,
          ),
        ];
      case 'done':
        final comm = numOf(b['commission_amount']);
        final mine = numOf(b['tech_amount']);
        final paidCash = (b['payment_method'] ?? '') == 'cash';
        return [
          _card(
            'Job completed',
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _bigNote(Icons.verified, 'Great work! The booking is closed.'),
              const SizedBox(height: 10),
              Text('Job total: ${money(b['gross_total'])}'),
              Text('Fixeaze commission (${b['commission_pct']}%): ${money(comm)}'),
              Text('Your share: ${money(mine)}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(paidCash
                  ? 'You collected the cash. The commission is taken from your next Fixeaze payment.'
                  : 'Fixeaze received the payment and will pay your share. See the Payments tab.',
                  style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 10),
              FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
            ]),
          ),
        ];
      default:
        return [const Text('Unknown step')];
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = _b;
    return Scaffold(
      appBar: AppBar(title: const Text('Job')),
      body: _error != null && b == null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
          : b == null
              ? const Center(child: CircularProgressIndicator())
              : Constrained(
                  maxWidth: 600,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Text(
                        ((b['services'] as Map?)?['name'] ?? 'Service').toString(),
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 2),
                      Text('${_customer?['name'] ?? 'Customer'}  -  ${b['address'] ?? ''}',
                          style: const TextStyle(color: Colors.black54)),
                      const SizedBox(height: 14),
                      _steps(),
                      const SizedBox(height: 14),
                      ..._stageViews(),
                    ],
                  ),
                ),
    );
  }
}
