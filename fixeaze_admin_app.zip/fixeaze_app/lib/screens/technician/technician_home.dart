import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../services/location_service.dart';
import '../../widgets/common.dart';
import '../job_watcher.dart';
import '../../services/promo_service.dart';
import '../promo_widgets.dart';
import '../profile_tab.dart';
import 'calendar_tab.dart';
import 'chats_tab.dart';
import 'my_jobs_tab.dart';
import 'open_jobs_tab.dart';
import 'payments_tab.dart';

class TechnicianHome extends StatefulWidget {
  final Map<String, dynamic> profile;
  const TechnicianHome({super.key, required this.profile});

  @override
  State<TechnicianHome> createState() => _TechnicianHomeState();
}

class _TechnicianHomeState extends State<TechnicianHome> {
  int _tab = 0;
  bool _paused = false;
  bool _pauseBusy = false;
  bool _sosBusy = false;
  bool _showProfile = false;

  @override
  void initState() {
    super.initState();
    _loadPaused();
    PromoService.tabRequest.addListener(_onPromoTab);
  }

  @override
  void dispose() {
    PromoService.tabRequest.removeListener(_onPromoTab);
    super.dispose();
  }

  void _onPromoTab() {
    const tabs = {'jobs': 0, 'myjobs': 1, 'chats': 2, 'calendar': 3, 'payments': 4};
    final i = tabs[PromoService.tabRequest.value];
    if (i != null && mounted) {
      setState(() {
        _tab = i;
        _showProfile = false;
      });
    }
  }

  Future<void> _loadPaused() async {
    try {
      final row = await supabase
          .from('technician_profiles')
          .select('paused')
          .eq('id', supabase.auth.currentUser!.id)
          .maybeSingle();
      if (mounted && row != null) setState(() => _paused = row['paused'] == true);
    } catch (_) {
      // Column missing until the SQL is run; the switch just stays "active".
    }
  }

  Future<void> _setPaused(bool pause) async {
    if (pause) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Pause your listing?'),
          content: const Text(
              'Customers will not be matched with you and you will not see new jobs '
              'until you turn it back on. Jobs you already accepted are not affected.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep active')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true), child: const Text('Pause')),
          ],
        ),
      );
      if (ok != true) return;
    }
    setState(() => _pauseBusy = true);
    try {
      await supabase.from('technician_profiles').update({
        'paused': pause,
        'paused_at': pause ? DateTime.now().toUtc().toIso8601String() : null,
      }).eq('id', supabase.auth.currentUser!.id);
      if (mounted) {
        setState(() => _paused = pause);
        snack(context, pause ? 'Listing paused' : 'You are active again');
      }
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not change this: $e', error: true);
    } finally {
      if (mounted) setState(() => _pauseBusy = false);
    }
  }

  Future<void> _sos() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.emergency, color: Colors.red, size: 40),
        title: const Text('Send emergency SOS?'),
        content: const Text(
            'Your current location will be sent to the Fixeaze admin right now. '
            'Use this only in a real emergency.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Send SOS'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _sosBusy = true);
    final loc = await LocationService.current();
    try {
      final uid = supabase.auth.currentUser!.id;

      // Attach the job in progress, if any, so the admin knows where you are working.
      String? bookingId;
      try {
        final r = await supabase
            .from('bookings')
            .select('id')
            .eq('technician_id', uid)
            .eq('status', 'in_progress')
            .limit(1);
        if (r.isNotEmpty) bookingId = r.first['id'] as String?;
      } catch (_) {}

      await supabase.from('sos_alerts').insert({
        'technician_id': uid,
        'booking_id': bookingId,
        'lat': loc.lat,
        'lng': loc.lng,
        'accuracy_m': loc.accuracy,
        'note': loc.ok ? null : loc.error,
      });

      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: const Icon(Icons.check_circle, color: Colors.green, size: 40),
          title: const Text('SOS sent'),
          content: Text(loc.ok
              ? 'Fixeaze admin has your location. Stay safe. If you are in danger, call 112 now.'
              : 'Fixeaze admin has your alert, but your location could not be read '
                  '(${loc.error}). Call 112 if you are in danger.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () => launchUrl(Uri.parse('tel:112')),
              icon: const Icon(Icons.call),
              label: const Text('Call 112'),
            ),
          ],
        ),
      );
    } on PostgrestException catch (e) {
      if (mounted) {
        snack(context, 'SOS not sent: ${e.message}. Call 112 if you need help.', error: true);
      }
    } catch (e) {
      if (mounted) snack(context, 'SOS not sent: $e. Call 112 if you need help.', error: true);
    } finally {
      if (mounted) setState(() => _sosBusy = false);
    }
  }

  Widget _statusStrip() {
    final color = _paused ? Colors.orange : Colors.teal;
    return Container(
      color: color.withOpacity(0.10),
      padding: const EdgeInsets.fromLTRB(16, 6, 12, 6),
      child: Row(
        children: [
          Icon(_paused ? Icons.pause_circle : Icons.check_circle, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              _paused ? 'Paused - no new jobs' : 'Active - getting jobs',
              style: TextStyle(fontWeight: FontWeight.w600, color: color.shade800),
            ),
          ),
          Switch(
            value: !_paused,
            onChanged: _pauseBusy ? null : (on) => _setPaused(!on),
          ),
          const SizedBox(width: 4),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red,
              minimumSize: const Size(0, 38),
              padding: const EdgeInsets.symmetric(horizontal: 12),
            ),
            onPressed: _sosBusy ? null : _sos,
            icon: _sosBusy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.emergency, size: 20),
            label: const Text('SOS'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      OpenJobsTab(onAccepted: () => setState(() {
        _tab = 1;
        _showProfile = false;
      })),
      const MyJobsTab(),
      const ChatsTab(),
      const CalendarTab(),
      const PaymentsTab(),
    ];

    final scaffold = Scaffold(
      appBar: AppBar(
        title: const AppBarTitle(subtitle: 'Technician'),
        actions: [
          IconButton(
            tooltip: 'My profile',
            onPressed: () => setState(() => _showProfile = !_showProfile),
            icon: Icon(_showProfile ? Icons.close : Icons.account_circle),
          ),
        ],
      ),
      body: Column(
        children: [
          _statusStrip(),
          if (_tab == 0 && !_showProfile) PromoBanner(audience: 'technician'),
          Expanded(
            child: Constrained(
              child: _showProfile
                  ? const ProfileTab(isTechnician: true)
                  : pages[_tab],
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() {
          _tab = i;
          _showProfile = false;
        }),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.work_outline), label: 'Jobs'),
          NavigationDestination(icon: Icon(Icons.assignment_turned_in), label: 'My jobs'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.calendar_month), label: 'Calendar'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet), label: 'Payments'),
        ],
      ),
    );
    return JobWatcher(
      isTechnician: true,
      child: AdGate(audience: 'technician', child: scaffold),
    );
  }
}
