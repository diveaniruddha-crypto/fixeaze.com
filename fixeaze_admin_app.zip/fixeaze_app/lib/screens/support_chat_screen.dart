import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../theme.dart';
import '../widgets/chat_media.dart';
import '../widgets/common.dart';

/// Direct chat with "Fixeaze Support" for technicians and institution owners.
/// Every Fixeaze admin can read and answer these messages.
class SupportChatScreen extends StatefulWidget {
  const SupportChatScreen({super.key});
  @override
  State<SupportChatScreen> createState() => _SupportChatScreenState();
}

class _SupportChatScreenState extends State<SupportChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _msgs = [];
  String? _error;
  bool _busy = false;
  bool _loaded = false;
  int _lastCount = -1;
  Timer? _t;
  List<Map<String, dynamic>> _adminReads = [];

  String get _me => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await supabase
          .from('tech_chat')
          .select()
          .eq('technician_id', _me)
          .order('created_at', ascending: true)
          .limit(500);
      if (!mounted) return;
      try {
        final now = DateTime.now().toUtc().toIso8601String();
        await supabase.from('chat_reads').upsert({'user_id': _me, 'thread': 't:$_me', 'read_at': now, 'delivered_at': now});
        final rr = await supabase.from('chat_reads').select().eq('thread', 't:$_me').neq('user_id', _me);
        _adminReads = List<Map<String, dynamic>>.from(rr);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _msgs = List<Map<String, dynamic>>.from(r);
        _error = null;
        _loaded = true;
      });
      if (_msgs.length != _lastCount) {
        _lastCount = _msgs.length;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e is PostgrestException ? e.message : '$e';
          _loaded = true;
        });
      }
    }
  }

  String _status(Map<String, dynamic> m) {
    final at = DateTime.tryParse('${m['created_at']}');
    if (at == null) return 'sent';
    var seen = false, del = false;
    for (final r in _adminReads) {
      final rt = DateTime.tryParse('${r['read_at']}');
      final dt = DateTime.tryParse('${r['delivered_at']}');
      if (rt != null && !rt.isBefore(at)) seen = true;
      if (dt != null && !dt.isBefore(at)) del = true;
    }
    return seen ? 'seen' : (del ? 'delivered' : 'sent');
  }

  Future<void> _attach() async {
    setState(() => _busy = true);
    try {
      final a = await pickChatAttachment(context);
      if (a != null) {
        await supabase.from('tech_chat').insert({
          'technician_id': _me,
          'sender_id': _me,
          'sender_role': 'technician',
          'body': a.type == 'image' ? '📷 Photo' : a.type == 'video' ? '🎥 Video' : '📎 ${a.name}',
          'media_url': a.url,
          'media_type': a.type,
          'media_name': a.name,
        });
        await _load();
      }
    } catch (e) {
      if (mounted) snack(context, e is PostgrestException ? e.message : '$e', error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty) return;
    setState(() => _busy = true);
    try {
      await supabase.from('tech_chat').insert({
        'technician_id': _me,
        'sender_id': _me,
        'sender_role': 'technician',
        'body': body,
      });
      _text.clear();
      await _load();
    } catch (e) {
      if (mounted) snack(context, e is PostgrestException ? e.message : '$e', error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  String _time(dynamic v) {
    final d = DateTime.tryParse('$v')?.toLocal();
    if (d == null) return '';
    final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
    return '$h:${d.minute.toString().padLeft(2, '0')} ${d.hour >= 12 ? 'PM' : 'AM'}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const CircleAvatar(radius: 16, backgroundColor: Colors.white, backgroundImage: AssetImage('assets/logo.png')),
          const SizedBox(width: 10),
          const Expanded(child: Text('Fixeaze Support')),
        ]),
      ),
      body: Constrained(
        maxWidth: 640,
        child: Column(children: [
          Container(
            width: double.infinity,
            color: kTeal.withOpacity(.08),
            padding: const EdgeInsets.all(10),
            child: const Text('Have a concern? Message us here. The Fixeaze team will reply in this chat.',
                style: TextStyle(fontSize: 13)),
          ),
          Expanded(
            child: !_loaded
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Text('Chat is not available yet. ($_error)', textAlign: TextAlign.center),
                        ),
                      )
                    : _msgs.isEmpty
                        ? const Center(child: Text('No messages yet. Say hello!'))
                        : ListView.builder(
                            controller: _scroll,
                            padding: const EdgeInsets.all(12),
                            itemCount: _msgs.length,
                            itemBuilder: (_, i) {
                              final m = _msgs[i];
                              final mine = m['sender_role'] != 'admin';
                              return Align(
                                alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                                child: Container(
                                  margin: const EdgeInsets.symmetric(vertical: 3),
                                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: mine ? kTeal : Colors.white,
                                    border: mine ? null : Border.all(color: Colors.black12),
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    if (!mine)
                                      const Text('Fixeaze Support',
                                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kTeal)),
                                    if ('${m['media_url'] ?? ''}'.isNotEmpty) ...[
                                      ChatMedia(
                                          url: '${m['media_url']}',
                                          type: '${m['media_type'] ?? 'file'}',
                                          name: '${m['media_name'] ?? ''}',
                                          mine: mine),
                                      const SizedBox(height: 4),
                                    ] else
                                      SelectableText('${m['body']}', style: TextStyle(color: mine ? Colors.white : Colors.black87)),
                                    Row(mainAxisSize: MainAxisSize.min, children: [
                                      Text(_time(m['created_at']),
                                          style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : Colors.black45)),
                                      if (mine) ...[const SizedBox(width: 4), Ticks(_status(m))],
                                    ]),
                                  ]),
                                ),
                              );
                            },
                          ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                IconButton(onPressed: _busy ? null : _attach, icon: const Icon(Icons.attach_file)),
                Expanded(
                  child: TextField(
                    controller: _text,
                    minLines: 1,
                    maxLines: 4,
                    onSubmitted: (_) => _send(),
                    decoration: const InputDecoration(hintText: 'Type your message', border: OutlineInputBorder(), isDense: true),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
