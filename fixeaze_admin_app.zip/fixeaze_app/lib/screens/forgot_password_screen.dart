import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Forgot password: full name + mobile + email must all match the account,
/// then the person can choose a new password. Nothing is sent by email or SMS.
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();

  bool _matched = false;
  bool _busy = false;
  bool _hide = true;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    _pass.dispose();
    _pass2.dispose();
    super.dispose();
  }

  String _err(Object e) => e is PostgrestException ? e.message : '$e';

  Future<void> _check() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final ok = await supabase.rpc('reset_check', params: {
        'p_name': _name.text.trim(),
        'p_phone': _phone.text.trim(),
        'p_email': _email.text.trim(),
      });
      if (!mounted) return;
      if (ok == true) {
        setState(() => _matched = true);
      } else {
        snack(context, 'These details do not match any account. Check them and try again.',
            error: true);
      }
    } catch (e) {
      if (mounted) snack(context, _err(e), error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save() async {
    if (_pass.text.length < 6) {
      snack(context, 'Password must be at least 6 characters', error: true);
      return;
    }
    if (_pass.text != _pass2.text) {
      snack(context, 'The two passwords do not match', error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      final ok = await supabase.rpc('reset_password', params: {
        'p_name': _name.text.trim(),
        'p_phone': _phone.text.trim(),
        'p_email': _email.text.trim(),
        'p_new': _pass.text,
      });
      if (!mounted) return;
      if (ok == true) {
        snack(context, 'Password changed. Please log in with your new password.');
        Navigator.pop(context);
        return;
      }
      snack(context, 'Details no longer match. Please start again.', error: true);
      setState(() => _matched = false);
    } catch (e) {
      if (mounted) snack(context, _err(e), error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  Widget _spinnerOr(String label) => _busy
      ? const SizedBox(
          height: 20,
          width: 20,
          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
      : Text(label);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Forgot password')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Constrained(
              maxWidth: 420,
              child: Form(
                key: _form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.lock_reset, size: 56, color: kTeal),
                    const SizedBox(height: 12),
                    Text(
                      _matched
                          ? 'Details matched. Choose a new password.'
                          : 'Enter the same full name, mobile number and email you used when you signed up.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15),
                    ),
                    const SizedBox(height: 20),
                    TextFormField(
                      controller: _name,
                      enabled: !_matched,
                      textCapitalization: TextCapitalization.words,
                      decoration: const InputDecoration(
                          labelText: 'Full name', prefixIcon: Icon(Icons.badge)),
                      validator: (v) =>
                          (v == null || v.trim().length < 2) ? 'Enter your full name' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _phone,
                      enabled: !_matched,
                      keyboardType: TextInputType.phone,
                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]'))],
                      decoration: const InputDecoration(
                          labelText: 'Mobile number', prefixIcon: Icon(Icons.phone)),
                      validator: (v) => (v == null || v.replaceAll(RegExp(r'\D'), '').length < 10)
                          ? 'Enter your 10-digit mobile number'
                          : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _email,
                      enabled: !_matched,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                          labelText: 'Email', prefixIcon: Icon(Icons.email)),
                      validator: (v) =>
                          (v == null || !v.contains('@')) ? 'Enter your email' : null,
                    ),
                    const SizedBox(height: 16),
                    if (!_matched)
                      FilledButton(
                        onPressed: _busy ? null : _check,
                        child: _spinnerOr('Check my details'),
                      )
                    else ...[
                      TextFormField(
                        controller: _pass,
                        obscureText: _hide,
                        decoration: InputDecoration(
                          labelText: 'New password',
                          prefixIcon: const Icon(Icons.lock),
                          suffixIcon: IconButton(
                            icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                            onPressed: () => setState(() => _hide = !_hide),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _pass2,
                        obscureText: _hide,
                        decoration: const InputDecoration(
                            labelText: 'Repeat new password',
                            prefixIcon: Icon(Icons.lock_outline)),
                        onFieldSubmitted: (_) => _busy ? null : _save(),
                      ),
                      const SizedBox(height: 16),
                      FilledButton(
                        onPressed: _busy ? null : _save,
                        child: _spinnerOr('Save new password'),
                      ),
                      TextButton(
                        onPressed: _busy ? null : () => setState(() => _matched = false),
                        child: const Text('Back'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
