import 'package:flutter/material.dart';

import 'admin_widgets.dart';

/// Phone / desktop build of the admin app: the browser notification helper does not exist here.
class PushService {
  static const vapidPublicKey = '';
  static bool get supported => false;
  static String get permission => 'unsupported';
  static Future<String?> playSound(String kind) async => null;
  static Future<String?> enable({bool ask = true}) async =>
      'Browser notifications are only for the website. Use the admin website on this phone for alerts.';
  static Future<void> refreshIfGranted() async {}
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        SectionCard(
          title: 'Phone notifications',
          child: Muted('Alerts for SOS, bookings, tickets and chats are shown on the Overview page inside this app. '
              'Push alerts while the app is closed are available on the admin website (add it to your home screen).'),
        ),
      ],
    );
  }
}
