import 'package:flutter/material.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

// ============================================================== BANK & COMMISSION

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _payee;
  late final TextEditingController _upi;
  late final TextEditingController _bank;
  late final TextEditingController _acc;
  late final TextEditingController _ifsc;
  late final TextEditingController _pct;
  bool _busyBank = false;
  bool _busyPct = false;

  @override
  void initState() {
    super.initState();
    final x = _s.settings;
    String t(String k) => '${x[k] ?? ''}';
    _payee = TextEditingController(text: t('payee_name'));
    _upi = TextEditingController(text: t('upi_id'));
    _bank = TextEditingController(text: t('bank_name'));
    _acc = TextEditingController(text: t('account_no'));
    _ifsc = TextEditingController(text: t('ifsc'));
    final p = numOf(x['commission_pct'] ?? 20);
    _pct = TextEditingController(text: p == p.roundToDouble() ? p.toStringAsFixed(0) : '$p');
  }

  @override
  void dispose() {
    _payee.dispose();
    _upi.dispose();
    _bank.dispose();
    _acc.dispose();
    _ifsc.dispose();
    _pct.dispose();
    super.dispose();
  }

  Future<void> _saveBank() async {
    final upi = _upi.text.trim();
    if (upi.isNotEmpty && !RegExp(r'^[A-Za-z0-9.\-_]{2,}@[A-Za-z]{2,}$').hasMatch(upi)) {
      toast(context, 'UPI ID looks wrong. Example: fixeaze@okaxis', error: true);
      return;
    }
    setState(() => _busyBank = true);
    final err = await _s.settingsSave({
      'payee_name': _payee.text.trim(),
      'upi_id': upi,
      'bank_name': _bank.text.trim(),
      'account_no': _acc.text.trim(),
      'ifsc': _ifsc.text.trim().toUpperCase(),
    }, 'Fixeaze bank details');
    if (!mounted) return;
    setState(() => _busyBank = false);
    report(context, err, 'Bank details saved. New payments will show this QR.');
  }

  num? get _pctValue {
    final v = num.tryParse(_pct.text.trim());
    if (v == null || v < 0 || v > 100) return null;
    return v;
  }

  Future<void> _savePct() async {
    final v = _pctValue;
    if (v == null) {
      toast(context, 'Enter a number from 0 to 100', error: true);
      return;
    }
    final ok = await confirmBox(
        context,
        'Fixeaze keeps $v% and technicians get ${100 - v}% on every job completed from now on. '
        'Jobs already completed are not changed.',
        yes: 'Save');
    if (!ok) return;
    setState(() => _busyPct = true);
    final err = await _s.settingsSave({'commission_pct': v}, 'commission');
    if (!mounted) return;
    setState(() => _busyPct = false);
    report(context, err, 'Commission saved');
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final v = _pctValue;
    final upi = _upi.text.trim();
    final open = s.dues.where((d) => d['status'] == 'open').toList();
    num owed(Rec d) => numOf(d['amount']) - numOf(d['settled']);
    final totalOwed = open.fold<num>(0, (a, d) => a + owed(d));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['platform_settings'] != null)
          NoticeBanner(
              'Settings table is missing. Run sql/v2_part11_job_flow.sql in Supabase first. (${s.errors['platform_settings']})',
              color: kBad),
        SectionCard(
          title: 'Fixeaze bank details',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Muted(
                'The payment QR shown on the technician\'s phone is made from the UPI ID below. '
                'The other bank details are kept for your records.'),
            const SizedBox(height: 12),
            TextField(
                controller: _payee,
                decoration: const InputDecoration(labelText: 'Account holder / business name')),
            const SizedBox(height: 10),
            TextField(
                controller: _upi,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                    labelText: 'UPI ID (used for the QR)', hintText: 'example@okaxis')),
            const SizedBox(height: 10),
            TextField(controller: _bank, decoration: const InputDecoration(labelText: 'Bank name')),
            const SizedBox(height: 10),
            TextField(
                controller: _acc,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Account number')),
            const SizedBox(height: 10),
            TextField(
                controller: _ifsc,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'IFSC code')),
            const SizedBox(height: 14),
            Wrap(spacing: 10, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(0, 42)),
                onPressed: _busyBank ? null : _saveBank,
                child: _busyBank
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Save bank details'),
              ),
              if (upi.isEmpty)
                const Pill('No UPI ID: customers can only pay cash', kWarn)
              else
                const Pill('QR payments on', kOk),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        SectionCard(
          title: 'Commission',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Muted('Fixeaze share of every job. Example: 20 means Fixeaze 20% and technician 80%.'),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in const [10, 20, 25, 30])
                ActionChip(
                  label: Text('Fixeaze $p / Tech ${100 - p}'),
                  onPressed: () => setState(() => _pct.text = '$p'),
                ),
            ]),
            const SizedBox(height: 12),
            SizedBox(
              width: 220,
              child: TextField(
                controller: _pct,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(labelText: 'Fixeaze share (%)', suffixText: '%'),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              v == null ? 'Enter 0 to 100' : 'Fixeaze $v%  /  Technician ${100 - v}%   (on a Rs 1000 job: Fixeaze Rs ${(1000 * v / 100).toStringAsFixed(0)}, technician Rs ${(1000 - 1000 * v / 100).toStringAsFixed(0)})',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(0, 42)),
              onPressed: _busyPct ? null : _savePct,
              child: _busyPct
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Save commission'),
            ),
            const SizedBox(height: 6),
            const Muted(
                'QR job: customer money comes to Fixeaze, technician share goes into Payments. '
                'Cash job: technician keeps the cash and Fixeaze commission is deducted from their next payment.'),
          ]),
        ),
        const SectionTitle('Cash commission to collect from technicians'),
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          Pill('Open: ${money(totalOwed)}', totalOwed > 0 ? kWarn : kOk),
          CsvButton(
            name: 'cash_commission',
            headers: () => ['Technician', 'Booking', 'Commission', 'Already deducted', 'Remaining', 'Status', 'Created'],
            rows: () => [
              for (final d in s.dues)
                [s.nameOf(d['technician_id']), '${d['booking_id'] ?? ''}', d['amount'], d['settled'], owed(d), d['status'], fdt(d['created_at'])],
            ],
          ),
        ]),
        const SizedBox(height: 10),
        AdminTable(
          columns: const ['Technician', 'Job date', 'Commission', 'Deducted', 'Remaining', 'Status', ''],
          numeric: const {2, 3, 4},
          empty: 'No cash jobs yet.',
          rows: [
            for (final d in s.dues)
              <Widget>[
                Text(s.nameOf(d['technician_id'])),
                Text(fday(d['created_at'])),
                Text(money(d['amount'])),
                Text(money(d['settled'])),
                Text(money(owed(d))),
                d['status'] == 'settled' ? const Pill('Settled', kOk) : const Pill('Open', kWarn),
                d['status'] == 'settled'
                    ? const SizedBox.shrink()
                    : AsyncButton(
                        label: 'Mark received',
                        outlined: true,
                        onTap: () async {
                          final ok = await confirmBox(
                              context, 'Did you receive ${money(owed(d))} from ${s.nameOf(d['technician_id'])} outside the app?',
                              yes: 'Yes');
                          if (!ok) return;
                          final err = await s.dueSettle('${d['id']}');
                          if (context.mounted) report(context, err, 'Marked as received');
                        },
                      ),
              ],
          ],
        ),
      ],
    );
  }
}
