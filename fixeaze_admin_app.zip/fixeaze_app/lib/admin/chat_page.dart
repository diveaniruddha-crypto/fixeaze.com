import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../services/cloudinary_service.dart';
import '../services/pincode_service.dart';
import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';

AdminStore get _s => AdminStore.I;

/// Round profile picture (or initials).
class Avatar extends StatelessWidget {
  final String? url;
  final String name;
  final double size;
  final bool? online;
  final IconData? icon;
  const Avatar({super.key, this.url, required this.name, this.size = 40, this.online, this.icon});

  @override
  Widget build(BuildContext context) {
    final has = url != null && url!.trim().isNotEmpty;
    final circle = CircleAvatar(
      radius: size / 2,
      backgroundColor: kBrand.withOpacity(.15),
      foregroundImage: has ? NetworkImage(url!) : null,
      child: icon != null
          ? Icon(icon, size: size * .5, color: kBrand)
          : Text(initials(name), style: TextStyle(fontSize: size * .38, fontWeight: FontWeight.bold, color: kBrand)),
    );
    if (online == null) return circle;
    return Stack(clipBehavior: Clip.none, children: [
      circle,
      Positioned(
        right: -1,
        bottom: -1,
        child: Container(
          width: size * .28,
          height: size * .28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: online! ? kOk : Colors.black26,
            border: Border.all(color: Colors.white, width: 2),
          ),
        ),
      ),
    ]);
  }
}

/// Messenger-style chat: group, admins, and technicians (city wise, via Fixeaze Support).
class AdminChatPage extends StatefulWidget {
  const AdminChatPage({super.key});
  @override
  State<AdminChatPage> createState() => _AdminChatPageState();
}

class _AdminChatPageState extends State<AdminChatPage> {
  static final Map<String, String> _cityOf = {}; // pincode -> city (kept between visits)
  static bool _loadingCities = false;

  final _text = TextEditingController();
  final _search = TextEditingController();
  final _scroll = ScrollController();
  final Set<String> _openCities = {};
  String? _sel;
  bool _busy = false;
  int _lastCount = -1;
  String _lastKey = '';

  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
    _s.loadChats();
    _loadCities();
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    _s.openChatKey = null;
    _text.dispose();
    _search.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  Future<void> _loadCities() async {
    if (_loadingCities) return;
    _loadingCities = true;
    final pins = <String>{
      for (final p in _s.profiles)
        if (p['role'] == 'technician' && '${p['pincode'] ?? ''}'.isNotEmpty) '${p['pincode']}',
    }.where((p) => !_cityOf.containsKey(p)).take(80).toList();
    for (final pin in pins) {
      try {
        final info = await PincodeService.lookup(pin);
        final c = (info?.city ?? '').trim();
        _cityOf[pin] = c.isNotEmpty ? c : (info?.label ?? '').trim();
      } catch (_) {
        _cityOf[pin] = '';
      }
      if (mounted && _cityOf.length % 5 == 0) setState(() {});
    }
    _loadingCities = false;
    if (mounted) setState(() {});
  }

  String _cityName(Rec tech) {
    final pin = '${tech['pincode'] ?? ''}';
    final c = _cityOf[pin];
    if (c == null) return pin.isEmpty ? 'No pincode' : 'Loading...';
    return c.isEmpty ? 'Other ($pin)' : c;
  }

  // ------------------------------------------------------------ helpers

  Rec? _last(String key) {
    final m = _s.messagesOf(key);
    return m.isEmpty ? null : m.last;
  }

  String _preview(String key) {
    final m = _last(key);
    if (m == null) return '';
    final mine = '${m['sender_id']}' == _s.meId;
    return '${mine ? 'You: ' : ''}${m['body']}';
  }

  String _title(String key) {
    if (key == 'group') return 'Everyone (group)';
    if (key.startsWith('t:')) return _s.nameOf(key.substring(2), 'Technician');
    return _s.nameOf(key, 'Admin');
  }

  String _subtitle(String key) {
    if (key == 'group') return 'Every admin can read this';
    if (key.startsWith('t:')) {
      final p = _s.P[key.substring(2)] ?? {};
      return 'Fixeaze Support chat · ${_cityName(p)} · ${p['phone'] ?? ''}';
    }
    return _s.isOnline(key) ? 'Online · private chat' : 'Private chat';
  }

  void _open(String key) {
    setState(() {
      _sel = key;
      _lastKey = '';
    });
    _s.openChatKey = key;
    _s.markRead(key);
  }

  void _back() {
    setState(() => _sel = null);
    _s.openChatKey = null;
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty || _sel == null) return;
    setState(() => _busy = true);
    final err = await _s.chatSend(_sel!, body);
    if (!mounted) return;
    if (err == null) {
      _text.clear();
      _s.markRead(_sel!);
    } else {
      toast(context, err, error: true);
    }
    setState(() => _busy = false);
  }

  Future<void> _editProfile() async {
    await showDialog<void>(context: context, builder: (_) => const _ProfileDialog());
    if (mounted) setState(() {});
  }

  // ------------------------------------------------------------ left side

  Widget _tile(String key, {String? title, String? subtitle, String? avatar, bool? online, IconData? icon, bool indent = false}) {
    final t = title ?? _title(key);
    final n = key == _sel ? 0 : _s.unreadFor(key);
    final last = _last(key);
    return Material(
      color: key == _sel ? kBrand.withOpacity(.08) : Colors.transparent,
      child: InkWell(
        onTap: () => _open(key),
        child: Padding(
          padding: EdgeInsets.fromLTRB(indent ? 28 : 12, 8, 12, 8),
          child: Row(children: [
            Avatar(url: avatar, name: t, size: 42, online: online, icon: icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: n > 0 ? FontWeight.bold : FontWeight.w600)),
                Text(
                  subtitle ?? (_preview(key).isEmpty ? '' : _preview(key)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, color: n > 0 ? Colors.black87 : Colors.black54, fontWeight: n > 0 ? FontWeight.w600 : FontWeight.normal),
                ),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              if (last != null) Text(ago(last['created_at']), style: const TextStyle(fontSize: 10, color: Colors.black45)),
              if (n > 0)
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(color: kBad, borderRadius: BorderRadius.circular(10)),
                  child: Text('$n', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _head(String text, {int unread = 0}) => Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
        child: Row(children: [
          Text(text.toUpperCase(), style: const TextStyle(fontSize: 11, letterSpacing: .8, fontWeight: FontWeight.bold, color: Colors.black45)),
          if (unread > 0) ...[
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(color: kBad, borderRadius: BorderRadius.circular(10)),
              child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 10)),
            ),
          ],
        ]),
      );

  Widget _leftPane() {
    final q = _search.text.trim().toLowerCase();
    bool match(String s) => q.isEmpty || s.toLowerCase().contains(q);

    final partners = _s.admins.where((a) => '${a['id']}' != _s.meId && match('${a['name']}')).toList()
      ..sort((a, b) => '${a['name']}'.compareTo('${b['name']}'));

    // technicians (approved) and institution owners who may write to support
    final techs = _s.profiles.where((p) => p['role'] == 'technician' && p['approved'] == true).toList();
    final threadIds = {for (final m in _s.techChat) '${m['technician_id']}'};
    final inbox = threadIds.where((id) => match(_s.nameOf(id))).toList()
      ..sort((a, b) => ('${_last('t:$b')?['created_at']}').compareTo('${_last('t:$a')?['created_at']}'));
    final inboxUnread = inbox.fold<int>(0, (a, id) => a + _s.unreadFor('t:$id'));

    final byCity = <String, List<Rec>>{};
    for (final t in techs) {
      final city = _cityName(t);
      if (!(match('${t['name']}') || match(city) || match('${t['phone']}'))) continue;
      byCity.putIfAbsent(city, () => []).add(t);
    }
    final cities = byCity.keys.toList()..sort();

    return Container(
      color: Colors.white,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
          child: Row(children: [
            InkWell(
              onTap: _editProfile,
              borderRadius: BorderRadius.circular(30),
              child: Avatar(url: _s.avatarOf(_s.meId), name: _s.nameOf(_s.meId, 'Me'), size: 40),
            ),
            const SizedBox(width: 10),
            const Expanded(child: Text('Chats', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            IconButton(tooltip: 'My profile picture', onPressed: _editProfile, icon: const Icon(Icons.account_circle_outlined)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
          child: TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search people or cities',
              prefixIcon: const Icon(Icons.search),
              isDense: true,
              filled: true,
              fillColor: const Color(0xFFF1F3F4),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
            ),
          ),
        ),
        if (_s.chatError != null)
          Padding(
            padding: const EdgeInsets.all(8),
            child: NoticeBanner('Chat is not ready. Run sql/v2_part23_messenger.sql in Supabase. (${_s.chatError})', color: kBad),
          ),
        Expanded(
          child: ListView(children: [
            if (match('everyone group')) _tile('group', icon: Icons.groups, subtitle: _preview('group').isEmpty ? 'Message every admin' : _preview('group')),
            if (inbox.isNotEmpty) ...[
              _head('Fixeaze Support inbox', unread: inboxUnread),
              for (final id in inbox)
                _tile('t:$id', avatar: _s.avatarOf(id), subtitle: _preview('t:$id')),
            ],
            if (partners.isNotEmpty) ...[
              _head('Admins'),
              for (final a in partners)
                _tile('${a['id']}', avatar: _s.avatarOf(a['id']), online: _s.isOnline('${a['id']}')),
            ],
            _head('Technicians by city'),
            if (cities.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Muted('No technicians found.')),
            for (final city in cities)
              Theme(
                data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                  key: PageStorageKey('city-$city'),
                  initiallyExpanded: q.isNotEmpty || _openCities.contains(city),
                  onExpansionChanged: (v) => v ? _openCities.add(city) : _openCities.remove(city),
                  tilePadding: const EdgeInsets.symmetric(horizontal: 14),
                  leading: const Icon(Icons.location_city, color: kBrand),
                  title: Text('$city (${byCity[city]!.length})', style: const TextStyle(fontWeight: FontWeight.w600)),
                  trailing: () {
                    final n = byCity[city]!.fold<int>(0, (a, t) => a + _s.unreadFor('t:${t['id']}'));
                    return n > 0
                        ? Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(color: kBad, borderRadius: BorderRadius.circular(10)),
                            child: Text('$n', style: const TextStyle(color: Colors.white, fontSize: 11)),
                          )
                        : const Icon(Icons.expand_more);
                  }(),
                  children: [
                    for (final t in byCity[city]!)
                      _tile('t:${t['id']}',
                          avatar: _s.avatarOf(t['id']),
                          subtitle: _preview('t:${t['id']}').isEmpty ? '${t['phone'] ?? ''}' : _preview('t:${t['id']}'),
                          indent: true),
                  ],
                ),
              ),
            const SizedBox(height: 20),
          ]),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------ right side

  Widget _conversation(bool wide) {
    final key = _sel;
    if (key == null) {
      return const Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.forum_outlined, size: 64, color: Colors.black26),
          SizedBox(height: 10),
          Muted('Pick a chat on the left to start', size: 14),
        ]),
      );
    }
    final msgs = _s.messagesOf(key);
    if (msgs.length != _lastCount || key != _lastKey) {
      _lastCount = msgs.length;
      _lastKey = key;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
      });
    }
    if (_s.unreadFor(key) > 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _s.markRead(key));
    }
    final isTech = key.startsWith('t:');
    final title = _title(key);
    return Column(children: [
      Container(
        color: Colors.white,
        padding: const EdgeInsets.fromLTRB(8, 8, 12, 8),
        child: Row(children: [
          if (!wide) IconButton(onPressed: _back, icon: const Icon(Icons.arrow_back)),
          Avatar(
              url: key == 'group' ? null : _s.avatarOf(isTech ? key.substring(2) : key),
              name: title,
              size: 40,
              icon: key == 'group' ? Icons.groups : null),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              Text(_subtitle(key), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            ]),
          ),
        ]),
      ),
      const Divider(height: 1),
      if (isTech)
        Container(
          width: double.infinity,
          color: kInfo.withOpacity(.08),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: const Text('Replies go to the technician as "Fixeaze Support". Every admin can see this chat.', style: TextStyle(fontSize: 12)),
        ),
      Expanded(
        child: Container(
          color: const Color(0xFFF4F6F6),
          child: msgs.isEmpty
              ? Center(child: Muted('No messages yet with $title.', size: 14))
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final m = msgs[i];
                    final mine = '${m['sender_id']}' == _s.meId;
                    final sid = '${m['sender_id']}';
                    final label = isTech && m['sender_role'] == 'admin'
                        ? 'Fixeaze Support · ${_s.nameOf(sid, 'Admin')}'
                        : _s.nameOf(sid, 'Admin');
                    return _Bubble(
                      text: '${m['body']}',
                      who: mine ? 'You' : label,
                      time: parseTime(m['created_at']),
                      mine: mine,
                      avatar: _s.avatarOf(sid),
                    );
                  },
                ),
        ),
      ),
      Container(
        color: Colors.white,
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _text,
              minLines: 1,
              maxLines: 4,
              onSubmitted: (_) => _send(),
              decoration: InputDecoration(
                hintText: 'Message $title',
                isDense: true,
                filled: true,
                fillColor: const Color(0xFFF1F3F4),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send)),
        ]),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final wide = c.maxWidth >= 820;
      if (wide) {
        return Row(children: [
          SizedBox(width: 340, child: _leftPane()),
          const VerticalDivider(width: 1),
          Expanded(child: _conversation(true)),
        ]);
      }
      return _sel == null ? _leftPane() : _conversation(false);
    });
  }
}

class _Bubble extends StatelessWidget {
  final String text;
  final String who;
  final DateTime? time;
  final bool mine;
  final String? avatar;
  const _Bubble({required this.text, required this.who, required this.time, required this.mine, this.avatar});

  @override
  Widget build(BuildContext context) {
    final bubble = Container(
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .6 > 460 ? 460 : MediaQuery.of(context).size.width * .7),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: mine ? kBrand : Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(16),
          topRight: const Radius.circular(16),
          bottomLeft: Radius.circular(mine ? 16 : 4),
          bottomRight: Radius.circular(mine ? 4 : 16),
        ),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 3, offset: Offset(0, 1))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (!mine) Text(who, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kBrand)),
        SelectableText(text, style: TextStyle(color: mine ? Colors.white : Colors.black87)),
        const SizedBox(height: 2),
        Text(time == null ? '' : ftime(time!.toIso8601String()),
            style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : Colors.black45)),
      ]),
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!mine) ...[Avatar(url: avatar, name: who, size: 30), const SizedBox(width: 6)],
          Flexible(child: bubble),
          if (mine) ...[const SizedBox(width: 6), Avatar(url: avatar, name: who, size: 30)],
        ],
      ),
    );
  }
}

class _ProfileDialog extends StatefulWidget {
  const _ProfileDialog();
  @override
  State<_ProfileDialog> createState() => _ProfileDialogState();
}

class _ProfileDialogState extends State<_ProfileDialog> {
  bool _busy = false;
  String? _msg;

  Future<void> _change() async {
    setState(() {
      _busy = true;
      _msg = null;
    });
    try {
      final url = await CloudinaryService.pickAndUpload();
      if (url != null) {
        final err = await _s.setAvatar(url);
        _msg = err ?? 'Profile picture updated. Everyone can see it now.';
      }
    } catch (e) {
      _msg = e is PostgrestException ? e.message : '$e';
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final name = _s.nameOf(_s.meId, 'Me');
    return AlertDialog(
      title: const Text('My profile picture'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Avatar(url: _s.avatarOf(_s.meId), name: name, size: 110),
        const SizedBox(height: 10),
        Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: _busy ? null : _change,
          icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.photo_camera),
          label: const Text('Choose a photo'),
        ),
        if (_msg != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_msg!, textAlign: TextAlign.center)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    );
  }
}
