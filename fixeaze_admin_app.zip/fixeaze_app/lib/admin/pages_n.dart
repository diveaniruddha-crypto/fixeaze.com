import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;

import '../config.dart';
import '../services/cloudinary_service.dart';
import '../services/pincode_service.dart';
import 'admin_store.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

String _err(Object e) => e is PostgrestException ? e.message : '$e';

typedef _Row = Map<String, dynamic>;

Widget _thumb(String? url, {double size = 46}) {
  final has = url != null && url.isNotEmpty;
  return ClipRRect(
    borderRadius: BorderRadius.circular(8),
    child: Container(
      width: size,
      height: size,
      color: Colors.grey.shade200,
      child: has
          ? Image.network(CloudinaryService.optimized(url, width: 200), fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined))
          : const Icon(Icons.image_outlined, color: Colors.grey),
    ),
  );
}

// ================================================================= CATALOG
// Service  >  Products  >  Service types (servicing / repairing / installation ...)

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key});
  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  bool _loading = true;
  String? _error;
  List<_Row> _services = [];
  List<_Row> _products = [];
  List<_Row> _types = [];
  List<_Row> _prices = [];
  _Row? _svc;
  _Row? _prod;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await supabase.from('services').select().order('name');
      _services = List<_Row>.from(s);
      final p = await supabase.from('catalog_products').select().order('sort').order('name');
      _products = List<_Row>.from(p);
      final t = await supabase.from('product_services').select().order('sort').order('name');
      _types = List<_Row>.from(t);
      final pr = await supabase.from('technician_prices').select('item_id, technician_id, enabled');
      _prices = List<_Row>.from(pr);
      _error = null;
      // keep the selected rows fresh after edits
      if (_svc != null) _svc = _services.firstWhere((x) => x['id'] == _svc!['id'], orElse: () => _svc!);
      if (_prod != null) _prod = _products.firstWhere((x) => x['id'] == _prod!['id'], orElse: () => _prod!);
    } catch (e) {
      _error = _err(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _edit(String level, [_Row? row]) async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => _CatalogDialog(
        level: level,
        row: row,
        parentId: level == 'product' ? '${_svc?['id']}' : (level == 'type' ? '${_prod?['id']}' : null),
      ),
    );
    if (saved == true) {
      _s.logAction(row == null ? 'Added $level' : 'Edited $level', '${row?['name'] ?? ''}');
      await _load();
      _s.loadAll(silent: true);
    }
  }

  Future<void> _delete(String level, _Row row) async {
    final table = level == 'service' ? 'services' : (level == 'product' ? 'catalog_products' : 'product_services');
    final ok = await confirmBox(
        context,
        'Delete "${row['name']}"? Everything inside it and the technicians\' charges for it are deleted too. '
        'To just stop customers seeing it, use Edit and switch Visible off instead.',
        yes: 'Delete');
    if (!ok) return;
    String? err;
    try {
      await supabase.from(table).delete().eq('id', row['id']);
      await _load();
      _s.loadAll(silent: true);
    } catch (e) {
      err = _err(e);
      if (err.contains('violates foreign key')) {
        err = 'This is already used by bookings. Switch Visible off instead of deleting.';
      }
    }
    if (mounted) report(context, err, 'Deleted');
  }

  int _techCount(Iterable<String> itemIds) {
    final ids = itemIds.toSet();
    return _prices
        .where((p) => p['enabled'] == true && ids.contains('${p['item_id']}'))
        .map((p) => '${p['technician_id']}')
        .toSet()
        .length;
  }

  Widget _crumbs() {
    return Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 4, children: [
      TextButton(
          onPressed: () => setState(() {
                _svc = null;
                _prod = null;
              }),
          child: const Text('Services')),
      if (_svc != null) ...[
        const Icon(Icons.chevron_right, size: 18),
        TextButton(onPressed: () => setState(() => _prod = null), child: Text('${_svc!['name']}')),
      ],
      if (_prod != null) ...[
        const Icon(Icons.chevron_right, size: 18),
        Text('${_prod!['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
      ],
    ]);
  }

  Widget _vis(_Row r, [String level = 'service']) {
    final on = r['active'] != false;
    final table = level == 'service' ? 'services' : (level == 'product' ? 'catalog_products' : 'product_services');
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Switch(
        value: on,
        onChanged: (v) async {
          try {
            await supabase.from(table).update({'active': v}).eq('id', r['id']);
            r['active'] = v;
            _s.logAction(v ? 'Switched on' : 'Switched off', '${r['name']}');
            if (mounted) setState(() {});
          } catch (e) {
            if (mounted) toast(context, _err(e), error: true);
          }
        },
      ),
      Text(on ? 'On' : 'Off', style: TextStyle(color: on ? kOk : Colors.grey.shade700, fontWeight: FontWeight.w600)),
    ]);
  }

  String _range(_Row x) {
    final lo = x['price_min'], hi = x['price_max'];
    if (lo == null && hi == null) return 'Any price';
    if (lo != null && hi != null) return '${money(lo)} - ${money(hi)}';
    return lo != null ? 'From ${money(lo)}' : 'Up to ${money(hi)}';
  }

  Widget _actions(String level, _Row r, {VoidCallback? open, String? openLabel}) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      if (open != null) FilledButton.tonal(onPressed: open, child: Text(openLabel ?? 'Open')),
      const SizedBox(width: 6),
      OutlinedButton(onPressed: () => _edit(level, r), child: const Text('Edit')),
      IconButton(
          tooltip: 'Delete',
          onPressed: () => _delete(level, r),
          icon: const Icon(Icons.delete_outline, color: kBad, size: 20)),
    ]);
  }

  Widget _card(String level, _Row x, String info, {VoidCallback? open, String? openLabel}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _thumb(x['image_url'] as String?),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${x['name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                if ('${x['description'] ?? ''}'.isNotEmpty)
                  Text('${x['description']}', style: const TextStyle(color: Colors.black54, fontSize: 13)),
                const SizedBox(height: 4),
                Text(info, style: const TextStyle(fontSize: 12.5, color: Colors.black87)),
              ]),
            ),
          ]),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
            _vis(x, level),
            if (open != null) FilledButton(onPressed: open, child: Text(openLabel ?? 'Open')),
            OutlinedButton(onPressed: () => _edit(level, x), child: const Text('Edit')),
            IconButton(
                tooltip: 'Delete',
                onPressed: () => _delete(level, x),
                icon: const Icon(Icons.delete_outline, color: kBad)),
          ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final level = _svc == null ? 'service' : (_prod == null ? 'product' : 'type');
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (_error != null)
        NoticeBanner('Run the catalog SQL (part 35) in Supabase to turn this page on. ($_error)'),
      _crumbs(),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(
          child: Text(
            level == 'service'
                ? 'Services customers choose first (Electrician, Plumber ...). Open a service to add its products.'
                : level == 'product'
                    ? 'Products under ${_svc!['name']} (Fan, Light ...). Open a product to add its services (Repairing, Servicing...).'
                    : 'Service types for ${_prod!['name']} (Servicing, Repairing, Installation ...). '
                        'Technicians set their own charge for each one.',
            style: const TextStyle(color: Colors.black54),
          ),
        ),
        const SizedBox(width: 12),
        FilledButton.icon(
          onPressed: () => _edit(level),
          icon: const Icon(Icons.add),
          label: Text(level == 'service' ? 'Add service' : (level == 'product' ? 'Add product' : 'Add service (Repairing, Servicing...)')),
        ),
      ]),
      const SizedBox(height: 12),
      if (level == 'service') ...[
        if (_services.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No services yet. Tap "Add service".')),
        for (final x in _services)
          _card('service', x,
              '${_products.where((p) => p['service_id'] == x['id']).length} product(s)  |  '
              '${_techCount(_types.where((t) => _products.any((p) => p['id'] == t['product_id'] && p['service_id'] == x['id'])).map((t) => '${t['id']}'))} technician(s)',
              open: () => setState(() => _svc = x), openLabel: 'Add / open products'),
      ] else if (level == 'product') ...[
        if (_products.where((p) => p['service_id'] == _svc!['id']).isEmpty)
          const Padding(padding: EdgeInsets.all(24), child: Text('No products yet. Tap "Add product" (for example Fan, Light).')),
        for (final x in _products.where((p) => p['service_id'] == _svc!['id']))
          _card('product', x,
              '${_types.where((t) => t['product_id'] == x['id']).length} service(s)  |  '
              '${_techCount(_types.where((t) => t['product_id'] == x['id']).map((t) => '${t['id']}'))} technician(s)',
              open: () => setState(() => _prod = x), openLabel: 'Add / open services'),
      ] else ...[
        if (_types.where((t) => t['product_id'] == _prod!['id']).isEmpty)
          const Padding(padding: EdgeInsets.all(24), child: Text('No services yet. Tap "Add service" (for example Servicing, Repairing, Installation).')),
        for (final x in _types.where((t) => t['product_id'] == _prod!['id']))
          _card('type', x, '${_range(x)}  |  ${_techCount(['${x['id']}'])} technician(s)'),
      ],
    ]);
  }
}

class _CatalogDialog extends StatefulWidget {
  final String level; // service | product | type
  final _Row? row;
  final String? parentId;
  const _CatalogDialog({required this.level, this.row, this.parentId});
  @override
  State<_CatalogDialog> createState() => _CatalogDialogState();
}

class _CatalogDialogState extends State<_CatalogDialog> {
  final _name = TextEditingController();
  final _desc = TextEditingController();
  final _sort = TextEditingController(text: '0');
  final _pmin = TextEditingController();
  final _pmax = TextEditingController();
  String? _image;
  bool _active = true;
  bool _busy = false;
  bool _uploading = false;

  /// Best image size: 800 for a service, 400 for a product and for each kind of help.
  double get _imgPx => widget.level == 'service' ? 800 : 400;

  String get _table =>
      widget.level == 'service' ? 'services' : (widget.level == 'product' ? 'catalog_products' : 'product_services');
  String get _label =>
      widget.level == 'service' ? 'service' : (widget.level == 'product' ? 'product' : 'service (Repairing, Servicing...)');

  @override
  void initState() {
    super.initState();
    final r = widget.row;
    if (r != null) {
      _name.text = '${r['name'] ?? ''}';
      _desc.text = '${r['description'] ?? ''}';
      _sort.text = '${r['sort'] ?? 0}';
      _pmin.text = r['price_min'] == null ? '' : '${r['price_min']}';
      _pmax.text = r['price_max'] == null ? '' : '${r['price_max']}';
      _image = r['image_url'] as String?;
      _active = r['active'] != false;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    _sort.dispose();
    _pmin.dispose();
    _pmax.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    try {
      final f = await ImagePicker().pickImage(
          source: ImageSource.gallery, maxWidth: _imgPx, maxHeight: _imgPx, imageQuality: 80);
      if (f == null) return;
      setState(() => _uploading = true);
      final url = await CloudinaryService.uploadAny(await f.readAsBytes(), f.name);
      if (mounted) setState(() => _image = url);
    } catch (e) {
      if (mounted) toast(context, 'Upload failed: $e', error: true);
    }
    if (mounted) setState(() => _uploading = false);
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      toast(context, 'Name is required', error: true);
      return;
    }
    setState(() => _busy = true);
    final row = <String, dynamic>{
      'name': name,
      'description': _desc.text.trim().isEmpty ? null : _desc.text.trim(),
      'image_url': _image,
      'active': _active,
    };
    if (widget.level != 'service') row['sort'] = int.tryParse(_sort.text.trim()) ?? 0;
    if (widget.level == 'type') {
      row['price_min'] = num.tryParse(_pmin.text.trim());
      row['price_max'] = num.tryParse(_pmax.text.trim());
      final lo = row['price_min'] as num?, hi = row['price_max'] as num?;
      if (lo != null && hi != null && lo > hi) {
        toast(context, 'Lowest price cannot be more than highest price', error: true);
        setState(() => _busy = false);
        return;
      }
    }
    String? err;
    try {
      if (widget.row == null) {
        if (widget.level == 'service') {
          row['base_price'] = 300; // old hourly fields, no longer used by the new booking flow
          row['inspection_fee'] = 199;
        } else if (widget.level == 'product') {
          row['service_id'] = widget.parentId;
        } else {
          row['product_id'] = widget.parentId;
        }
        await supabase.from(_table).insert(row);
      } else {
        await supabase.from(_table).update(row).eq('id', widget.row!['id']);
      }
    } catch (e) {
      err = _err(e);
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      toast(context, err, error: true);
      return;
    }
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.row == null ? 'Add $_label' : 'Edit $_label'),
      content: SizedBox(
        width: 400,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(
                controller: _name,
                decoration: InputDecoration(
                    labelText: 'Name',
                    hintText: widget.level == 'service'
                        ? 'e.g. Electrician'
                        : (widget.level == 'product' ? 'e.g. Fan' : 'e.g. Repairing'),
                    border: const OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(
                controller: _desc,
                maxLines: 3,
                decoration: const InputDecoration(
                    labelText: 'Description (customers see this)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            Row(children: [
              _thumb(_image, size: 72),
              const SizedBox(width: 12),
              Expanded(
                child: Wrap(spacing: 8, runSpacing: 8, children: [
                  OutlinedButton.icon(
                    onPressed: _uploading ? null : _pick,
                    icon: _uploading
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.image_outlined, size: 18),
                    label: Text(_image == null ? 'Add image' : 'Change image'),
                  ),
                  if (_image != null)
                    TextButton(onPressed: () => setState(() => _image = null), child: const Text('Remove')),
                ]),
              ),
            ]),
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                  'Best size: ${_imgPx.toInt()} x ${_imgPx.toInt()} px, square. Big photos are shrunk to this automatically.',
                  style: const TextStyle(fontSize: 12, color: Colors.black54)),
            ),
            if (widget.level != 'service') ...[
              if (widget.level == 'type') ...[
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                      child: TextField(
                          controller: _pmin,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Lowest price Rs', border: OutlineInputBorder()))),
                  const SizedBox(width: 10),
                  Expanded(
                      child: TextField(
                          controller: _pmax,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Highest price Rs', border: OutlineInputBorder()))),
                ]),
                const Padding(
                  padding: EdgeInsets.only(top: 4),
                  child: Text('Technicians must set their charge inside this range. Leave empty for no limit.',
                      style: TextStyle(fontSize: 12, color: Colors.black54)),
                ),
              ],
              const SizedBox(height: 12),
              TextField(
                  controller: _sort,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Order number (small shows first)', border: OutlineInputBorder())),
            ],
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('On (customers can see and book)'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy || _uploading ? null : _save, child: const Text('Save')),
      ],
    );
  }
}

// ============================================== TECHNICIAN CHARGES (admin view)

Future<void> showTechnicianCharges(BuildContext context, String techId) {
  return showDialog<void>(context: context, builder: (_) => _TechChargesDialog(techId: techId));
}

class _TechChargesDialog extends StatefulWidget {
  final String techId;
  const _TechChargesDialog({required this.techId});
  @override
  State<_TechChargesDialog> createState() => _TechChargesDialogState();
}

class _TechChargesDialogState extends State<_TechChargesDialog> {
  bool _loading = true;
  String? _error;
  List<_Row> _services = [];
  List<_Row> _products = [];
  List<_Row> _types = [];
  final Map<String, _Row> _mine = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _services = List<_Row>.from(await supabase.from('services').select().order('name'));
      _products = List<_Row>.from(await supabase.from('catalog_products').select().order('sort').order('name'));
      _types = List<_Row>.from(await supabase.from('product_services').select().order('sort').order('name'));
      final pr = await supabase.from('technician_prices').select().eq('technician_id', widget.techId);
      _mine.clear();
      for (final r in pr) {
        _mine['${r['item_id']}'] = Map<String, dynamic>.from(r);
      }
    } catch (e) {
      _error = _err(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final id = widget.techId;
    final p = _s.P[id] ?? <String, dynamic>{};
    final mySvcIds = _s.tsvc.where((x) => x['technician_id'] == id).map((x) => '${x['service_id']}').toSet();
    final on = _mine.values.where((r) => r['enabled'] == true).length;
    final off = _mine.values.where((r) => r['enabled'] != true).length;
    final shown = _services.where((s) => mySvcIds.contains('${s['id']}') ||
        _products.any((pr) => pr['service_id'] == s['id'] && _types.any((t) => t['product_id'] == pr['id'] && _mine.containsKey('${t['id']}'))));

    return AlertDialog(
      title: Text('${p['name'] ?? 'Technician'}'),
      content: SizedBox(
        width: 520,
        child: _loading
            ? const SizedBox(height: 120, child: Center(child: CircularProgressIndicator()))
            : SingleChildScrollView(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (_error != null) NoticeBanner('Run the catalog SQL (part 35) first. ($_error)'),
                  Muted('${p['phone'] ?? ''}  ${p['email'] ?? ''}  PIN ${p['pincode'] ?? '-'}'),
                  const SizedBox(height: 4),
                  Muted('Services: ${_s.techServices(id).isEmpty ? 'none chosen' : _s.techServices(id).join(', ')}'),
                  const SizedBox(height: 4),
                  Text('$on item(s) switched on, $off switched off',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const Divider(),
                  if (shown.isEmpty) const Text('This technician has not set any charges yet.'),
                  for (final s in shown) ...[
                    Text('${s['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    for (final pr in _products.where((x) => x['service_id'] == s['id'])) ...[
                      Padding(
                        padding: const EdgeInsets.only(top: 8, left: 8),
                        child: Text('${pr['name']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                      for (final t in _types.where((x) => x['product_id'] == pr['id']))
                        Padding(
                          padding: const EdgeInsets.only(left: 24, top: 4),
                          child: Row(children: [
                            Expanded(child: Text('${t['name']}')),
                            () {
                              final m = _mine['${t['id']}'];
                              if (m == null) return const Text('Not set', style: TextStyle(color: Colors.grey));
                              if (m['enabled'] == true) {
                                return Text(money(m['price']), style: const TextStyle(fontWeight: FontWeight.bold));
                              }
                              final note = '${m['off_note'] ?? ''}'.isEmpty ? '' : ' - ${m['off_note']}';
                              return Flexible(
                                child: Text('OFF: ${m['off_reason']}$note',
                                    textAlign: TextAlign.end, style: const TextStyle(color: kBad, fontSize: 12)),
                              );
                            }(),
                          ]),
                        ),
                    ],
                    const SizedBox(height: 10),
                  ],
                ]),
              ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    );
  }
}

// ============================================= WHO PROVIDES WHAT (and charges)
class TechServicesPage extends StatefulWidget {
  const TechServicesPage({super.key});
  @override
  State<TechServicesPage> createState() => _TechServicesPageState();
}

class _TechServicesPageState extends State<TechServicesPage> {
  bool _loading = true;
  String? _error;
  List<_Row> _services = [];
  List<_Row> _products = [];
  List<_Row> _items = [];
  List<_Row> _prices = [];
  String _svc = '';
  final _pinFilter = TextEditingController();
  String _city = '';
  static final Map<String, String> _cityOf = {}; // pincode -> city

  @override
  void initState() {
    super.initState();
    _load();
    _loadCities();
  }

  @override
  void dispose() {
    _pinFilter.dispose();
    super.dispose();
  }

  Future<void> _loadCities() async {
    final pins = <String>{
      for (final p in _s.profiles)
        if (p['role'] == 'technician' && '${p['pincode'] ?? ''}'.isNotEmpty) '${p['pincode']}',
    }.where((x) => !_cityOf.containsKey(x)).take(80).toList();
    for (final pin in pins) {
      try {
        final info = await PincodeService.lookup(pin);
        final c = (info?.city ?? '').trim();
        _cityOf[pin] = c.isNotEmpty ? c : (info?.label ?? '').trim();
      } catch (_) {
        _cityOf[pin] = '';
      }
    }
    if (mounted) setState(() {});
  }

  bool _inArea(String techId) {
    final pin = '${_s.P[techId]?['pincode'] ?? ''}';
    final q = _pinFilter.text.trim();
    if (q.isNotEmpty && !pin.startsWith(q)) return false;
    if (_city.isNotEmpty && (_cityOf[pin] ?? '') != _city) return false;
    return true;
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _services = List<_Row>.from(await supabase.from('services').select().order('name'));
      _products = List<_Row>.from(await supabase.from('catalog_products').select().order('sort').order('name'));
      _items = List<_Row>.from(await supabase.from('product_services').select().order('sort').order('name'));
      _prices = List<_Row>.from(await supabase.from('technician_prices').select());
      if (_svc.isEmpty && _services.isNotEmpty) _svc = '${_services.first['id']}';
    } catch (e) {
      _error = _err(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Widget _chip(String text, Color c) => Container(
        margin: const EdgeInsets.only(right: 6, bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
        child: Text(text, style: TextStyle(color: c, fontSize: 12.5, fontWeight: FontWeight.w600)),
      );

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final techIds = <String>{
      for (final x in _s.tsvc)
        if ('${x['service_id']}' == _svc) '${x['technician_id']}'
    };
    for (final r in _prices) {
      final it = _items.where((i) => i['id'] == r['item_id']);
      if (it.isEmpty) continue;
      final pr = _products.where((p) => p['id'] == it.first['product_id']);
      if (pr.isNotEmpty && '${pr.first['service_id']}' == _svc) techIds.add('${r['technician_id']}');
    }
    techIds.removeWhere((t) => !_inArea(t));
    final products = _products.where((p) => '${p['service_id']}' == _svc).toList();
    final cities = (_cityOf.values.where((c) => c.isNotEmpty).toSet().toList()..sort());

    return ListView(padding: const EdgeInsets.all(16), children: [
      if (_error != null) NoticeBanner('Run the catalog SQL (part 35) first. ($_error)'),
      Row(children: [
        const Text('Service:  ', style: TextStyle(fontWeight: FontWeight.w600)),
        DropdownButton<String>(
          value: _services.any((s) => '${s['id']}' == _svc) ? _svc : null,
          items: [for (final s in _services) DropdownMenuItem(value: '${s['id']}', child: Text('${s['name']}'))],
          onChanged: (v) => setState(() => _svc = v ?? _svc),
        ),
        const Spacer(),
        IconButton(onPressed: _load, icon: const Icon(Icons.refresh), tooltip: 'Refresh'),
      ]),
      Wrap(spacing: 12, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
        SizedBox(
          width: 180,
          child: TextField(
            controller: _pinFilter,
            keyboardType: TextInputType.number,
            maxLength: 6,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
                labelText: 'Pincode', counterText: '', isDense: true, border: OutlineInputBorder(), prefixIcon: Icon(Icons.pin_drop_outlined)),
          ),
        ),
        DropdownButton<String>(
          value: cities.contains(_city) ? _city : '',
          items: [
            const DropdownMenuItem(value: '', child: Text('All cities')),
            for (final c in cities) DropdownMenuItem(value: c, child: Text(c)),
          ],
          onChanged: (v) => setState(() => _city = v ?? ''),
        ),
        if (_pinFilter.text.isNotEmpty || _city.isNotEmpty)
          TextButton(
              onPressed: () => setState(() {
                    _pinFilter.clear();
                    _city = '';
                  }),
              child: const Text('Clear filter')),
      ]),
      const SizedBox(height: 6),
      Muted('${techIds.length} technician(s) work in this service. Green = switched on with the charge. '
          'Red = switched off with the reason. Grey = has not set it yet.'),
      const SizedBox(height: 8),
      if (products.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No products in this service yet.')),
      for (final pr in products) ...[
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 4),
          child: Text('${pr['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        ),
        for (final it in _items.where((i) => i['product_id'] == pr['id']))
          () {
            final mine = _prices.where((r) => r['item_id'] == it['id'] && _inArea('${r['technician_id']}')).toList();
            final byTech = {for (final r in mine) '${r['technician_id']}': r};
            final on = mine.where((r) => r['enabled'] == true).toList()
              ..sort((a, b) => (a['price'] as num).compareTo(b['price'] as num));
            final off = mine.where((r) => r['enabled'] != true).toList();
            final notSet = techIds.where((t) => !byTech.containsKey(t)).toList();
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${it['name']}   (${on.length} providing)',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Wrap(children: [
                    for (final r in on) _chip('${_s.nameOf(r['technician_id'])}  ${money(r['price'])}', kOk),
                    for (final r in off)
                      _chip(
                          '${_s.nameOf(r['technician_id'])}: OFF (${r['off_reason'] ?? ''})', kBad),
                    for (final t in notSet) _chip('${_s.nameOf(t)}: not set', Colors.grey.shade700),
                    if (on.isEmpty && off.isEmpty && notSet.isEmpty)
                      const Text('No technician yet.', style: TextStyle(color: Colors.grey)),
                  ]),
                ]),
              ),
            );
          }(),
      ],
    ]);
  }
}
