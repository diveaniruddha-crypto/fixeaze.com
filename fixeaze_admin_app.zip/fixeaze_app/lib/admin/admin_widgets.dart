import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'csv_download.dart';

const kBrand = Color(0xFF00796B);
const kBad = Color(0xFFC62828);
const kWarn = Color(0xFFEF6C00);
const kOk = Color(0xFF2E7D32);
const kInfo = Color(0xFF1565C0);
const kViolet = Color(0xFF6A1B9A);

void toast(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: error ? kBad : null,
    ));
}

Future<bool> confirmBox(BuildContext context, String text, {String yes = 'Yes'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: Text(text),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes)),
      ],
    ),
  );
  return r == true;
}

/// Small coloured label.
class Pill extends StatelessWidget {
  final String text;
  final Color color;
  const Pill(this.text, this.color, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text,
          style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

class StatusPill extends StatelessWidget {
  final String status;
  const StatusPill(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Pill(statusLabel(status), statusColor(status));
}

class PayPill extends StatelessWidget {
  final String status;
  const PayPill(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Pill(status.isEmpty ? '-' : status, payColor(status));
}

/// The green / grey presence dot.
class PresenceDot extends StatelessWidget {
  final bool on;
  final double size;
  const PresenceDot(this.on, {super.key, this.size = 10});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: on ? const Color(0xFF22C55E) : Colors.grey.shade400,
          boxShadow: on
              ? [BoxShadow(color: const Color(0xFF22C55E).withAlpha(120), blurRadius: 6)]
              : null,
        ),
      );
}

class Muted extends StatelessWidget {
  final String text;
  final double size;
  const Muted(this.text, {super.key, this.size = 12});
  @override
  Widget build(BuildContext context) =>
      Text(text, style: TextStyle(color: Colors.black54, fontSize: size));
}

class EmptyBox extends StatelessWidget {
  final String text;
  const EmptyBox(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Center(child: Text(text, style: const TextStyle(color: Colors.black54))),
        ),
      );
}

class NoticeBanner extends StatelessWidget {
  final String text;
  final Color color;
  final Widget? action;
  const NoticeBanner(this.text, {super.key, this.color = kWarn, this.action});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withAlpha(25),
          border: Border.all(color: color.withAlpha(90)),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
            if (action != null) ...[const SizedBox(width: 8), action!],
          ],
        ),
      );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      );
}

class SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const SectionCard({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              child,
            ],
          ),
        ),
      );
}

/// One number with a label.
class StatTile {
  final String label;
  final String value;
  final String sub;
  final bool alert;
  final VoidCallback? onTap;
  const StatTile(this.label, this.value, {this.sub = '', this.alert = false, this.onTap});
}

class TileGrid extends StatelessWidget {
  final List<StatTile> tiles;
  const TileGrid(this.tiles, {super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final cols = math.max(2, (c.maxWidth / 210).floor());
      const gap = 12.0;
      final w = (c.maxWidth - gap * (cols - 1)) / cols;
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: tiles.map((t) {
          final color = t.alert ? kBad : Colors.black87;
          return SizedBox(
            width: w,
            child: Card(
              margin: EdgeInsets.zero,
              color: t.alert ? const Color(0xFFFFEBEE) : Colors.white,
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: t.onTap,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.label, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                      const SizedBox(height: 4),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(t.value,
                            style: TextStyle(
                                fontSize: 26, fontWeight: FontWeight.bold, color: color)),
                      ),
                      if (t.sub.isNotEmpty)
                        Text(t.sub, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      );
    });
  }
}

/// A scrollable table. [rows] hold ready-made cell widgets.
class AdminTable extends StatelessWidget {
  final List<String> columns;
  final List<List<Widget>> rows;
  final Set<int> numeric;
  final void Function(int index)? onRowTap;
  final String empty;
  const AdminTable({
    super.key,
    required this.columns,
    required this.rows,
    this.numeric = const {},
    this.onRowTap,
    this.empty = 'Nothing here yet.',
  });

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return EmptyBox(empty);
    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: LayoutBuilder(builder: (context, c) {
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: ConstrainedBox(
            constraints: BoxConstraints(minWidth: c.maxWidth),
            child: DataTable(
              showCheckboxColumn: false,
              headingRowHeight: 44,
              dataRowMinHeight: 48,
              dataRowMaxHeight: 64,
              columnSpacing: 22,
              headingTextStyle:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.black54),
              columns: [
                for (var i = 0; i < columns.length; i++)
                  DataColumn(label: Text(columns[i]), numeric: numeric.contains(i)),
              ],
              rows: [
                for (var r = 0; r < rows.length; r++)
                  DataRow(
                    onSelectChanged: onRowTap == null ? null : (_) => onRowTap!(r),
                    cells: [for (final w in rows[r]) DataCell(w)],
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

/// Two-line cell: bold name, grey detail.
class TwoLine extends StatelessWidget {
  final String top;
  final String bottom;
  const TwoLine(this.top, [this.bottom = '', Key? key]) : super(key: key);
  @override
  Widget build(BuildContext context) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(top, style: const TextStyle(fontWeight: FontWeight.w600)),
          if (bottom.isNotEmpty) Muted(bottom),
        ],
      );
}

/// Date range chips plus From / To pickers.
class RangeBar extends StatelessWidget {
  final DateRangeFilter filter;
  final VoidCallback onChanged;
  const RangeBar({super.key, required this.filter, required this.onChanged});

  Future<void> _pick(BuildContext context, bool from) async {
    final now = DateTime.now();
    final initial = (from ? filter.from : filter.to) ?? now;
    final d = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2023),
      lastDate: DateTime(now.year + 1),
    );
    if (d == null) return;
    final day = DateTime(d.year, d.month, d.day);
    if (from) {
      filter.from = day;
    } else {
      filter.to = day;
    }
    filter.preset = 'custom';
    onChanged();
  }

  @override
  Widget build(BuildContext context) {
    Widget chip(String p, String t) => ChoiceChip(
          label: Text(t),
          selected: filter.preset == p,
          onSelected: (_) {
            filter.apply(p);
            onChanged();
          },
        );
    Widget dateBtn(bool from) {
      final v = from ? filter.from : filter.to;
      return OutlinedButton.icon(
        style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
        onPressed: () => _pick(context, from),
        icon: const Icon(Icons.event, size: 16),
        label: Text('${from ? 'From' : 'To'}: ${v == null ? 'any' : dkey(v)}'),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          chip('today', 'Today'),
          chip('7', '7 days'),
          chip('30', '30 days'),
          chip('all', 'All time'),
          dateBtn(true),
          dateBtn(false),
        ],
      ),
    );
  }
}

/// Download button used on every page.
class CsvButton extends StatelessWidget {
  final String label;
  final String name;
  final List<String> Function() headers;
  final List<List<dynamic>> Function() rows;
  const CsvButton({
    super.key,
    this.label = 'Download report (CSV)',
    required this.name,
    required this.headers,
    required this.rows,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
      onPressed: () {
        try {
          final f = downloadCsv(name, headers(), rows());
          toast(context, 'Downloaded $f');
        } catch (e) {
          toast(context, 'Could not download: $e', error: true);
        }
      },
      icon: const Icon(Icons.download, size: 18),
      label: Text(label),
    );
  }
}

/// A private KYC photo (needs a signed link), tap to enlarge.
class KycImage extends StatefulWidget {
  final String path;
  final double size;
  const KycImage(this.path, {super.key, this.size = 110});
  @override
  State<KycImage> createState() => _KycImageState();
}

class _KycImageState extends State<KycImage> {
  late Future<String?> _url;

  @override
  void initState() {
    super.initState();
    _url = AdminStore.I.signedUrl(widget.path);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String?>(
      future: _url,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return _box(const Center(child: CircularProgressIndicator(strokeWidth: 2)));
        }
        final url = snap.data;
        if (url == null) {
          return _box(const Center(child: Text('Could not\nload', textAlign: TextAlign.center, style: TextStyle(fontSize: 11))));
        }
        return NetPhoto(url, size: widget.size);
      },
    );
  }

  Widget _box(Widget child) => Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
            color: Colors.black12, borderRadius: BorderRadius.circular(10)),
        child: child,
      );
}

/// Thumbnail that opens full size when tapped.
class NetPhoto extends StatelessWidget {
  final String url;
  final double size;
  const NetPhoto(this.url, {super.key, this.size = 90});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => showDialog<void>(
        context: context,
        builder: (ctx) => Dialog(
          child: Stack(
            children: [
              InteractiveViewer(
                child: Image.network(url,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Padding(
                        padding: EdgeInsets.all(40), child: Text('Could not load image'))),
              ),
              Positioned(
                right: 4,
                top: 4,
                child: IconButton.filled(
                    onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close)),
              ),
            ],
          ),
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.network(url,
            width: size,
            height: size,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
                width: size,
                height: size,
                color: Colors.black12,
                child: const Icon(Icons.broken_image))),
      ),
    );
  }
}

class KeyValue extends StatelessWidget {
  final List<List<String>> items;
  const KeyValue(this.items, {super.key});
  @override
  Widget build(BuildContext context) => Column(
        children: [
          for (final it in items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                      width: 110,
                      child: Text(it[0],
                          style: const TextStyle(color: Colors.black54, fontSize: 13))),
                  Expanded(child: SelectableText(it[1].isEmpty ? '-' : it[1])),
                ],
              ),
            ),
        ],
      );
}

// ================================================================ charts

class ChartSeries {
  final String name;
  final Color color;
  final List<double> values;
  const ChartSeries(this.name, this.color, this.values);
}

/// Vertical grouped bars.
class BarChart extends StatelessWidget {
  final List<String> labels;
  final List<ChartSeries> series;
  final double height;
  const BarChart({super.key, required this.labels, required this.series, this.height = 220});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: height,
          width: double.infinity,
          child: CustomPaint(painter: _BarPainter(labels, series)),
        ),
        if (series.length > 1) ...[
          const SizedBox(height: 8),
          Wrap(spacing: 14, runSpacing: 4, children: [
            for (final s in series)
              Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 10, height: 10, decoration: BoxDecoration(color: s.color, borderRadius: BorderRadius.circular(2))),
                const SizedBox(width: 5),
                Text(s.name, style: const TextStyle(fontSize: 12)),
              ]),
          ]),
        ],
      ],
    );
  }
}

class _BarPainter extends CustomPainter {
  final List<String> labels;
  final List<ChartSeries> series;
  _BarPainter(this.labels, this.series);

  void _text(Canvas c, String t, Offset o, {double size = 10, Color color = Colors.black54, bool center = false, bool right = false}) {
    final tp = TextPainter(
      text: TextSpan(text: t, style: TextStyle(fontSize: size, color: color)),
      textDirection: TextDirection.ltr,
    )..layout();
    var dx = o.dx;
    if (center) dx -= tp.width / 2;
    if (right) dx -= tp.width;
    tp.paint(c, Offset(dx, o.dy - tp.height / 2));
  }

  @override
  void paint(Canvas canvas, Size size) {
    const left = 32.0, bottom = 22.0, top = 6.0;
    final w = size.width - left;
    final h = size.height - bottom - top;
    var maxV = 0.0;
    for (final s in series) {
      for (final v in s.values) {
        if (v > maxV) maxV = v;
      }
    }
    if (maxV <= 0) maxV = 1;
    // Round the axis top to a tidy number.
    final mag = math.pow(10, (math.log(maxV) / math.ln10).floor()).toDouble();
    var axisMax = (maxV / mag).ceil() * mag;
    if (axisMax < maxV) axisMax = maxV;

    final grid = Paint()
      ..color = Colors.black12
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = top + h - h * i / 4;
      canvas.drawLine(Offset(left, y), Offset(size.width, y), grid);
      final v = axisMax * i / 4;
      _text(canvas, v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1),
          Offset(left - 6, y), right: true);
    }
    final n = labels.length;
    if (n == 0) return;
    final slot = w / n;
    final groupW = slot * 0.72;
    final barW = groupW / series.length;
    final every = math.max(1, (n / (w / 44)).ceil());
    for (var i = 0; i < n; i++) {
      final gx = left + slot * i + (slot - groupW) / 2;
      for (var s = 0; s < series.length; s++) {
        final v = i < series[s].values.length ? series[s].values[i] : 0.0;
        final bh = h * (v / axisMax);
        if (bh <= 0) continue;
        final rect = RRect.fromRectAndCorners(
          Rect.fromLTWH(gx + barW * s, top + h - bh, math.max(1, barW - 1), bh),
          topLeft: const Radius.circular(4),
          topRight: const Radius.circular(4),
        );
        canvas.drawRRect(rect, Paint()..color = series[s].color);
      }
      if (i % every == 0) {
        _text(canvas, labels[i], Offset(left + slot * i + slot / 2, size.height - 8), center: true);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter old) => true;
}

class Slice {
  final String label;
  final double value;
  final Color color;
  const Slice(this.label, this.value, this.color);
}

/// Doughnut with a legend.
class DonutChart extends StatelessWidget {
  final List<Slice> slices;
  const DonutChart(this.slices, {super.key});

  @override
  Widget build(BuildContext context) {
    final total = slices.fold<double>(0, (s, x) => s + x.value);
    return Row(
      children: [
        SizedBox(
          width: 130,
          height: 130,
          child: CustomPaint(painter: _DonutPainter(slices, total)),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final s in slices)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Container(width: 10, height: 10, decoration: BoxDecoration(color: s.color, shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(s.label, style: const TextStyle(fontSize: 13))),
                    Text(s.value.toInt().toString(), style: const TextStyle(fontWeight: FontWeight.w600)),
                  ]),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _DonutPainter extends CustomPainter {
  final List<Slice> slices;
  final double total;
  _DonutPainter(this.slices, this.total);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(14, 14, size.width - 28, size.height - 28);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 24
      ..strokeCap = StrokeCap.butt;
    if (total <= 0) {
      p.color = Colors.black12;
      canvas.drawArc(rect, 0, math.pi * 2, false, p);
      return;
    }
    var start = -math.pi / 2;
    for (final s in slices) {
      if (s.value <= 0) continue;
      final sweep = math.pi * 2 * s.value / total;
      p.color = s.color;
      canvas.drawArc(rect, start, math.max(0.01, sweep - 0.03), false, p);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter old) => true;
}

/// Horizontal bars with labels (top services).
class HBarChart extends StatelessWidget {
  final List<MapEntry<String, double>> items;
  final Color color;
  const HBarChart(this.items, {super.key, this.color = kInfo});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const Muted('No data yet.');
    final maxV = items.fold<double>(1, (m, e) => e.value > m ? e.value : m);
    return Column(
      children: [
        for (final e in items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(children: [
              SizedBox(width: 110, child: Text(e.key, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  return Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      height: 14,
                      width: math.max(3, c.maxWidth * e.value / maxV),
                      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4)),
                    ),
                  );
                }),
              ),
              const SizedBox(width: 8),
              Text(e.value.toInt().toString(), style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ),
      ],
    );
  }
}
