import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;

import '../config.dart';
import '../services/cloudinary_service.dart';
import '../theme.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

String _oerr(Object e) => e is PostgrestException ? e.message : '$e';

typedef _R = Map<String, dynamic>;

Widget _othumb(String? url, {double size = 46}) {
  final has = url != null && url.isNotEmpty;
  return ClipRRect(
    borderRadius: BorderRadius.circular(8),
    child: Container(
      width: size,
      height: size,
      color: Colors.grey.shade200,
      child: has
          ? Image.network(CloudinaryService.optimized(url, width: 200), fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined))
          : const Icon(Icons.image_outlined, color: Colors.grey),
    ),
  );
}

// ================================================================ CARE TIPS
// Product (Fan, AC ...)  >  Daily tips and Monthly tips

class TipsAdminPage extends StatefulWidget {
  const TipsAdminPage({super.key});
  @override
  State<TipsAdminPage> createState() => _TipsAdminPageState();
}

class _TipsAdminPageState extends State<TipsAdminPage> {
  bool _loading = true;
  String? _error;
  List<_R> _products = [];
  List<_R> _tips = [];
  _R? _open;
  String _freq = 'daily';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _products = List<_R>.from(await supabase.from('tip_products').select().order('sort').order('name'));
      _tips = List<_R>.from(await supabase.from('maintenance_tips').select().order('sort').order('title'));
      _error = null;
      if (_open != null) _open = _products.firstWhere((p) => p['id'] == _open!['id'], orElse: () => _open!);
    } catch (e) {
      _error = _oerr(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  int _count(_R p, String f) =>
      _tips.where((t) => t['tip_product_id'] == p['id'] && t['frequency'] == f).length;

  Future<void> _editProduct([_R? row]) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => _TipProductDialog(row: row));
    if (ok == true) await _load();
  }

  Future<void> _deleteProduct(_R p) async {
    final ok = await confirmBox(context,
        'Delete "${p['name']}" and all its daily and monthly tips?\nTo only hide it from customers, switch it Off instead.',
        yes: 'Delete');
    if (!ok) return;
    String? err;
    try {
      await supabase.from('tip_products').delete().eq('id', p['id']);
      await _load();
    } catch (e) {
      err = _oerr(e);
    }
    if (mounted) report(context, err, 'Deleted');
  }

  Future<void> _editTip([_R? row]) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _TipDialog(product: _open!, frequency: row?['frequency'] ?? _freq, row: row),
    );
    if (ok == true) await _load();
  }

  Future<void> _deleteTip(_R t) async {
    final ok = await confirmBox(context, 'Delete the tip "${t['title']}"?', yes: 'Delete');
    if (!ok) return;
    String? err;
    try {
      await supabase.from('maintenance_tips').delete().eq('id', t['id']);
      await _load();
    } catch (e) {
      err = _oerr(e);
    }
    if (mounted) report(context, err, 'Deleted');
  }

  Widget _switch(String table, _R r) {
    final on = r['active'] != false;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Switch(
        value: on,
        onChanged: (v) async {
          try {
            await supabase.from(table).update({'active': v}).eq('id', r['id']);
            r['active'] = v;
            if (mounted) setState(() {});
          } catch (e) {
            if (mounted) toast(context, _oerr(e), error: true);
          }
        },
      ),
      Text(on ? 'On' : 'Off', style: TextStyle(color: on ? kOk : Colors.grey.shade700, fontWeight: FontWeight.w600)),
    ]);
  }

  Widget _productCard(_R p) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _othumb(p['image_url'] as String?),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('${_count(p, 'daily')} daily tip(s)  |  ${_count(p, 'monthly')} monthly tip(s)',
                    style: const TextStyle(fontSize: 12.5)),
              ]),
            ),
          ]),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
            _switch('tip_products', p),
            FilledButton(onPressed: () => setState(() => _open = p), child: const Text('Add / open tips')),
            OutlinedButton(onPressed: () => _editProduct(p), child: const Text('Edit')),
            IconButton(
                tooltip: 'Delete',
                onPressed: () => _deleteProduct(p),
                icon: const Icon(Icons.delete_outline, color: kBad)),
          ]),
        ]),
      ),
    );
  }

  Widget _tipCard(_R t) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${t['title']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 2),
          Text('${t['body'] ?? ''}', style: const TextStyle(color: Colors.black54, fontSize: 13)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
            _switch('maintenance_tips', t),
            OutlinedButton(onPressed: () => _editTip(t), child: const Text('Edit')),
            IconButton(
                tooltip: 'Delete',
                onPressed: () => _deleteTip(t),
                icon: const Icon(Icons.delete_outline, color: kBad)),
          ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final tips = _open == null
        ? const <_R>[]
        : _tips.where((t) => t['tip_product_id'] == _open!['id'] && t['frequency'] == _freq).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (_error != null)
        NoticeBanner('Run v2_part40_tip_products.sql in Supabase to turn this page on. ($_error)'),
      Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 4, children: [
        TextButton(onPressed: () => setState(() => _open = null), child: const Text('Care tips')),
        if (_open != null) ...[
          const Icon(Icons.chevron_right, size: 18),
          Text('${_open!['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(
          child: Text(
            _open == null
                ? 'Products customers see in the Tips tab (Fan, AC, Geyser ...). Open a product to add its daily and monthly tips.'
                : 'Tips customers see after they tap ${_open!['name']}.',
            style: const TextStyle(color: Colors.black54),
          ),
        ),
        const SizedBox(width: 12),
        FilledButton.icon(
          onPressed: () => _open == null ? _editProduct() : _editTip(),
          icon: const Icon(Icons.add),
          label: Text(_open == null ? 'Add product' : 'Add ${_freq == 'daily' ? 'daily' : 'monthly'} tip'),
        ),
      ]),
      const SizedBox(height: 12),
      if (_open == null) ...[
        if (_products.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No products yet. Tap "Add product".')),
        for (final p in _products) _productCard(p),
      ] else ...[
        SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'daily', icon: const Icon(Icons.today), label: Text('Daily (${_count(_open!, 'daily')})')),
            ButtonSegment(value: 'monthly', icon: const Icon(Icons.calendar_month), label: Text('Monthly (${_count(_open!, 'monthly')})')),
          ],
          selected: {_freq},
          onSelectionChanged: (s) => setState(() => _freq = s.first),
        ),
        const SizedBox(height: 12),
        if (tips.isEmpty)
          Padding(padding: const EdgeInsets.all(24), child: Text('No ${_freq == 'daily' ? 'daily' : 'monthly'} tips yet. Tap the Add button.')),
        for (final t in tips) _tipCard(t),
      ],
    ]);
  }
}

class _TipProductDialog extends StatefulWidget {
  final _R? row;
  const _TipProductDialog({this.row});
  @override
  State<_TipProductDialog> createState() => _TipProductDialogState();
}

class _TipProductDialogState extends State<_TipProductDialog> {
  final _name = TextEditingController();
  final _sort = TextEditingController(text: '0');
  String? _image;
  bool _active = true;
  bool _busy = false;
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    final r = widget.row;
    if (r != null) {
      _name.text = '${r['name'] ?? ''}';
      _sort.text = '${r['sort'] ?? 0}';
      _image = r['image_url'] as String?;
      _active = r['active'] != false;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _sort.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    try {
      final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 400, maxHeight: 400, imageQuality: 80);
      if (f == null) return;
      setState(() => _uploading = true);
      final url = await CloudinaryService.uploadAny(await f.readAsBytes(), f.name);
      if (mounted) setState(() => _image = url);
    } catch (e) {
      if (mounted) toast(context, 'Upload failed: $e', error: true);
    }
    if (mounted) setState(() => _uploading = false);
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      toast(context, 'Name is required', error: true);
      return;
    }
    setState(() => _busy = true);
    final row = {
      'name': name,
      'image_url': _image,
      'sort': int.tryParse(_sort.text.trim()) ?? 0,
      'active': _active,
    };
    String? err;
    try {
      if (widget.row == null) {
        await supabase.from('tip_products').insert(row);
      } else {
        await supabase.from('tip_products').update(row).eq('id', widget.row!['id']);
        // keep the name saved with each tip in step
        await supabase.from('maintenance_tips').update({'product': name}).eq('tip_product_id', widget.row!['id']);
      }
    } catch (e) {
      err = _oerr(e);
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      toast(context, err, error: true);
      return;
    }
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.row == null ? 'Add product' : 'Edit product'),
      content: SizedBox(
        width: 400,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Product name (Fan, AC, Geyser ...)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            Row(children: [
              _othumb(_image, size: 72),
              const SizedBox(width: 12),
              Expanded(
                child: Wrap(spacing: 8, runSpacing: 8, children: [
                  OutlinedButton.icon(
                    onPressed: _uploading ? null : _pick,
                    icon: _uploading
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.image_outlined, size: 18),
                    label: Text(_image == null ? 'Add image' : 'Change image'),
                  ),
                  if (_image != null) TextButton(onPressed: () => setState(() => _image = null), child: const Text('Remove')),
                ]),
              ),
            ]),
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('Best size: 400 x 400 px, square. Big photos are shrunk to this automatically.',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
            ),
            const SizedBox(height: 12),
            TextField(
                controller: _sort,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Order number (1 shows first)', border: OutlineInputBorder())),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Visible to customers'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? 'Saving...' : 'Save')),
      ],
    );
  }
}

class _TipDialog extends StatefulWidget {
  final _R product;
  final String frequency;
  final _R? row;
  const _TipDialog({required this.product, required this.frequency, this.row});
  @override
  State<_TipDialog> createState() => _TipDialogState();
}

class _TipDialogState extends State<_TipDialog> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  final _sort = TextEditingController(text: '0');
  late String _freq;
  bool _active = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _freq = widget.frequency;
    final r = widget.row;
    if (r != null) {
      _title.text = '${r['title'] ?? ''}';
      _body.text = '${r['body'] ?? ''}';
      _sort.text = '${r['sort'] ?? 0}';
      _active = r['active'] != false;
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    _sort.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_title.text.trim().isEmpty || _body.text.trim().isEmpty) {
      toast(context, 'Please fill the title and the tip', error: true);
      return;
    }
    setState(() => _busy = true);
    final row = {
      'frequency': _freq,
      'product': '${widget.product['name']}',
      'tip_product_id': widget.product['id'],
      'title': _title.text.trim(),
      'body': _body.text.trim(),
      'sort': int.tryParse(_sort.text.trim()) ?? 0,
      'active': _active,
    };
    String? err;
    try {
      if (widget.row == null) {
        await supabase.from('maintenance_tips').insert(row);
      } else {
        await supabase.from('maintenance_tips').update(row).eq('id', widget.row!['id']);
      }
    } catch (e) {
      err = _oerr(e);
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      toast(context, err, error: true);
      return;
    }
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.row == null ? 'Add tip for ${widget.product['name']}' : 'Edit tip'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'daily', label: Text('Daily')),
                ButtonSegment(value: 'monthly', label: Text('Monthly')),
              ],
              selected: {_freq},
              onSelectionChanged: (s) => setState(() => _freq = s.first),
            ),
            const SizedBox(height: 12),
            TextField(controller: _title, decoration: const InputDecoration(labelText: 'Short title', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(
                controller: _body,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'The tip (what the customer should do)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(
                controller: _sort,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Order number (1 shows first)', border: OutlineInputBorder())),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Visible to customers'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? 'Saving...' : 'Save')),
      ],
    );
  }
}

// ============================================================ SEND TO PHONES
// Admin writes a title and message and sends it to all customers, all technicians or everyone.

class BroadcastPage extends StatefulWidget {
  const BroadcastPage({super.key});
  @override
  State<BroadcastPage> createState() => _BroadcastPageState();
}

class _BroadcastPageState extends State<BroadcastPage> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  String _target = 'customer';
  bool _busy = false;
  String? _msg;
  bool _ok = false;

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_title.text.trim().isEmpty || _body.text.trim().isEmpty) {
      setState(() {
        _ok = false;
        _msg = 'Write a title and a message first.';
      });
      return;
    }
    final who = _target == 'customer'
        ? 'all customers'
        : _target == 'technician'
            ? 'all technicians'
            : 'everyone (customers and technicians)';
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Send now?'),
        content: Text('"${_title.text.trim()}" will go to $who.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Send')),
        ],
      ),
    );
    if (yes != true) return;
    setState(() {
      _busy = true;
      _msg = null;
    });
    try {
      final n = await supabase.rpc('admin_broadcast', params: {
        'p_target': _target,
        'p_title': _title.text.trim(),
        'p_body': _body.text.trim(),
      });
      if (!mounted) return;
      setState(() {
        _ok = true;
        _msg = 'Sent to about $n phone(s). It arrives in a few seconds.';
        _title.clear();
        _body.clear();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _ok = false;
        _msg = _oerr(e);
      });
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'Send a phone notification',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Muted('Goes to the Fixeaze app on phones where people are logged in and allowed notifications.'),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final t in const [
                ['customer', 'Customers'],
                ['technician', 'Technicians'],
                ['all', 'Everyone'],
              ])
                ChoiceChip(
                  label: Text(t[1]),
                  selected: _target == t[0],
                  onSelected: (_) => setState(() => _target = t[0]),
                ),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _title,
              maxLength: 60,
              decoration: const InputDecoration(labelText: 'Title', hintText: 'Special offer'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _body,
              maxLength: 200,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Message', hintText: '20% off AC service this week'),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              style: FilledButton.styleFrom(minimumSize: const Size(0, 46)),
              onPressed: _busy ? null : _send,
              icon: const Icon(Icons.send_outlined),
              label: Text(_busy ? 'Sending...' : 'Send'),
            ),
            if (_msg != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_msg!, style: TextStyle(color: _ok ? kOk : kBad, fontWeight: FontWeight.w600)),
              ),
          ]),
        ),
      ],
    );
  }
}
