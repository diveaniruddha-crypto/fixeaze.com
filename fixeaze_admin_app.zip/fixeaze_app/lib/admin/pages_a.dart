import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';

typedef NavFn = void Function(String page);

AdminStore get _s => AdminStore.I;

String _money(dynamic v) {
  if (v == null || '$v'.isEmpty) return '';
  final n = numOf(v);
  return '₹${n == n.roundToDouble() ? n.toStringAsFixed(0) : n.toStringAsFixed(2)}';
}

String money(dynamic v) => _money(v);

/// Button that shows a spinner while its async job runs.
class AsyncButton extends StatefulWidget {
  final String label;
  final Future<void> Function() onTap;
  final Color? color;
  final bool outlined;
  final IconData? icon;
  const AsyncButton({
    super.key,
    required this.label,
    required this.onTap,
    this.color,
    this.outlined = false,
    this.icon,
  });

  @override
  State<AsyncButton> createState() => _AsyncButtonState();
}

class _AsyncButtonState extends State<AsyncButton> {
  bool _busy = false;

  Future<void> _go() async {
    setState(() => _busy = true);
    try {
      await widget.onTap();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final child = _busy
        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
        : Text(widget.label);
    final size = const Size(0, 38);
    if (widget.outlined) {
      return OutlinedButton(
        style: OutlinedButton.styleFrom(
            minimumSize: size, foregroundColor: widget.color),
        onPressed: _busy ? null : _go,
        child: child,
      );
    }
    return FilledButton(
      style: FilledButton.styleFrom(
          minimumSize: size,
          backgroundColor: widget.color,
          padding: const EdgeInsets.symmetric(horizontal: 14)),
      onPressed: _busy ? null : _go,
      child: child,
    );
  }
}

/// Shows the result of a change: red toast on error, normal toast on success.
void report(BuildContext context, String? error, String ok) {
  if (!context.mounted) return;
  toast(context, error ?? ok, error: error != null);
}

// ============================================================== OVERVIEW

class OverviewPage extends StatelessWidget {
  final NavFn onNav;
  const OverviewPage({super.key, required this.onNav});

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final customers = s.profiles.where((p) => p['role'] == 'customer').length;
    final techs = s.profiles.where((p) => p['role'] == 'technician' && p['approved'] == true).toList();
    final paused = techs.where((t) => s.TP[t['id']]?['paused'] == true).length;
    final now = DateTime.now();
    final todayKey = dkey(now);
    final perDay = <String, int>{};
    for (final b in s.bookings) {
      final t = parseTime(b['scheduled_at']);
      if (t == null) continue;
      final k = dkey(t.toLocal());
      perDay[k] = (perDay[k] ?? 0) + 1;
    }
    final today = DateTime(now.year, now.month, now.day);
    final days = [for (var i = 13; i >= 0; i--) today.subtract(Duration(days: i))];
    final active = s.bookings.where((b) => b['status'] == 'accepted' || b['status'] == 'in_progress').length;
    final completed = s.bookings.where((b) => b['status'] == 'completed').toList();
    final revenue = completed.fold<num>(0, (a, b) => a + numOf(b['price']));
    final due = s.payments.where((p) => p['status'] == 'pending' || p['status'] == 'processing');
    final owed = due.fold<num>(0, (a, p) => a + numOf(p['amount']));
    final paid = s.payments.where((p) => p['status'] == 'paid').fold<num>(0, (a, p) => a + numOf(p['amount']));
    final rated = s.tprof.where((t) => numOf(t['rating']) > 0).toList();
    final avg = rated.isEmpty ? 0.0 : rated.fold<num>(0, (a, t) => a + numOf(t['rating'])) / rated.length;
    final nSos = s.openSos.length;
    final nApp = s.pendingTechs.length;
    final nPay = due.length;
    final unassigned = s.bookings.where((b) => b['status'] == 'pending' && b['technician_id'] == null).length;
    final bToday = perDay[todayKey] ?? 0;

    final order = ['pending', 'accepted', 'in_progress', 'completed', 'cancelled'];
    final colors = [kWarn, kInfo, kViolet, kOk, Colors.grey];
    final perSvc = <String, double>{};
    for (final b in s.bookings) {
      final n = s.svcName(b['service_id']);
      perSvc[n] = (perSvc[n] ?? 0) + 1;
    }
    final top = perSvc.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    Widget attn(String text, Color c, String page) => ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.circle, size: 12, color: c),
          title: Text(text),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => onNav(page),
        );

    final attention = <Widget>[
      if (nSos > 0) attn('$nSos open SOS alert${nSos > 1 ? 's need' : ' needs'} attention', kBad, 'sos'),
      if (nApp > 0) attn('$nApp technician${nApp > 1 ? 's' : ''} waiting for approval', kWarn, 'approvals'),
      if (nPay > 0) attn('$nPay payment${nPay > 1 ? 's' : ''} to pay (${_money(owed)})', kInfo, 'payments'),
      if (unassigned > 0) attn('$unassigned booking${unassigned > 1 ? 's' : ''} with no technician yet', kViolet, 'bookings'),
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TileGrid([
          StatTile('Open SOS', '$nSos', sub: nSos > 0 ? 'Respond now' : 'All clear', alert: nSos > 0, onTap: () => onNav('sos')),
          StatTile('Awaiting approval', '$nApp', sub: 'technicians', onTap: () => onNav('approvals')),
          StatTile('Bookings today', '$bToday', sub: '$active active now', onTap: () => onNav('bookings')),
          StatTile('Completed jobs', '${completed.length}', sub: '${_money(revenue)} billed', onTap: () => onNav('bookings')),
          StatTile('Customers', '$customers', sub: 'registered', onTap: () => onNav('people')),
          StatTile('Technicians', '${techs.length}', sub: paused > 0 ? 'approved · $paused paused' : 'approved', onTap: () => onNav('people')),
          StatTile('To pay technicians', _money(owed), sub: '${_money(paid)} paid so far', onTap: () => onNav('payments')),
          StatTile('Avg rating', avg == 0 ? '-' : avg.toStringAsFixed(1), sub: '${rated.length} rated technicians'),
        ]),
        const SizedBox(height: 16),
        LayoutBuilder(builder: (context, c) {
          final wide = c.maxWidth > 760;
          final chart = SectionCard(
            title: 'Bookings, last 14 days',
            child: BarChart(
              labels: [for (final d in days) '${d.day}/${d.month}'],
              series: [
                ChartSeries('Bookings', kBrand, [for (final d in days) (perDay[dkey(d)] ?? 0).toDouble()]),
              ],
            ),
          );
          final needs = SectionCard(
            title: 'Needs attention',
            child: attention.isEmpty
                ? const Padding(padding: EdgeInsets.all(8), child: Muted('Nothing urgent. Nice.', size: 14))
                : Column(children: attention),
          );
          if (!wide) return Column(children: [chart, const SizedBox(height: 16), needs]);
          return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: 3, child: chart),
            const SizedBox(width: 16),
            Expanded(flex: 2, child: needs),
          ]);
        }),
        const SizedBox(height: 16),
        LayoutBuilder(builder: (context, c) {
          final wide = c.maxWidth > 760;
          final status = SectionCard(
            title: 'Booking status',
            child: DonutChart([
              for (var i = 0; i < order.length; i++)
                Slice(statusLabel(order[i]),
                    s.bookings.where((b) => b['status'] == order[i]).length.toDouble(), colors[i]),
            ]),
          );
          final svc = SectionCard(title: 'Bookings by service', child: HBarChart(top.take(8).toList()));
          if (!wide) return Column(children: [status, const SizedBox(height: 16), svc]);
          return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: status),
            const SizedBox(width: 16),
            Expanded(child: svc),
          ]);
        }),
        const SizedBox(height: 16),
        Align(
          alignment: Alignment.centerLeft,
          child: CsvButton(
            name: 'overview',
            headers: () => ['Metric', 'Value'],
            rows: () => [
              ['Customers', customers],
              ['Technicians (approved)', techs.length],
              ['Technicians awaiting approval', nApp],
              ['Open SOS alerts', nSos],
              ['Total bookings', s.bookings.length],
              ['Completed jobs', completed.length],
              ['Billed on completed jobs', revenue],
              ['Owed to technicians', owed],
              ['Paid to technicians', paid],
              for (final o in order)
                ['Bookings: ${statusLabel(o)}', s.bookings.where((b) => b['status'] == o).length],
            ],
          ),
        ),
      ],
    );
  }
}

// ============================================================== APPROVALS

class ApprovalsPage extends StatelessWidget {
  const ApprovalsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final list = s.pendingTechs;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          const Expanded(
              child: Muted(
                  'Check the Aadhaar photo and selfie, confirm the names match, then approve. Photos are private and open only here.',
                  size: 13)),
          const SizedBox(width: 12),
          CsvButton(
            name: 'technician_applications',
            headers: () => [
              'Name', 'Email', 'Phone', 'Pincode', 'Aadhaar name', 'Name matches', 'Aadhaar last 4',
              'Bank', 'IFSC', 'Account (last 4)', 'UPI', 'Services', 'Experience (yrs)', 'Hourly rate'
            ],
            rows: () => [
              for (final p in s.pendingTechs)
                () {
                  final k = s.KYC['${p['id']}'] ?? <String, dynamic>{};
                  final t = s.TP['${p['id']}'] ?? <String, dynamic>{};
                  final acc = '${k['bank_account_no'] ?? ''}';
                  return <dynamic>[
                    p['name'], p['email'], p['phone'], p['pincode'], k['aadhaar_name'],
                    k['aadhaar_name'] == null ? '' : (normName(k['aadhaar_name']) == normName(p['name']) ? 'yes' : 'no'),
                    k['aadhaar_last4'], k['bank_name'], k['bank_ifsc'],
                    acc.length > 4 ? acc.substring(acc.length - 4) : acc,
                    k['upi_id'], s.techServices('${p['id']}').join('; '),
                    t['experience_years'], t['hourly_rate'],
                  ];
                }(),
            ],
          ),
        ]),
        const SizedBox(height: 12),
        if (list.isEmpty)
          const EmptyBox('No technicians are waiting for approval.')
        else
          LayoutBuilder(builder: (context, c) {
            final cols = c.maxWidth > 900 ? 2 : 1;
            final w = (c.maxWidth - 16 * (cols - 1)) / cols;
            return Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [for (final p in list) SizedBox(width: w, child: _ApprovalCard(p))],
            );
          }),
      ],
    );
  }
}

class _ApprovalCard extends StatelessWidget {
  final Rec p;
  const _ApprovalCard(this.p);

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final id = '${p['id']}';
    final k = s.KYC[id];
    final t = s.TP[id] ?? <String, dynamic>{};
    final match = k == null ? null : normName(k['aadhaar_name']) == normName(p['name']);
    final svcs = s.techServices(id);
    final selfie = k == null ? null : k['selfie_image_path'];
    final aadhaar = k == null ? null : k['aadhaar_image_path'];

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              CircleAvatar(radius: 22, child: Text(initials(p['name']))),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${p['name'] ?? 'Unnamed'}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  Muted('${p['email'] ?? ''}'),
                  Muted('${p['phone'] ?? ''} · PIN ${p['pincode'] ?? '-'}'),
                ]),
              ),
            ]),
            const SizedBox(height: 12),
            if (k == null)
              const NoticeBanner('Application incomplete: no Aadhaar / KYC details were saved.')
            else ...[
              Row(children: [
                const Muted('Aadhaar name: ', size: 13),
                Flexible(child: Text('${k['aadhaar_name'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w600))),
                const SizedBox(width: 8),
                match == true ? const Pill('matches', kOk) : const Pill('does not match', kBad),
              ]),
              const SizedBox(height: 8),
              KeyValue([
                ['Aadhaar no.', 'XXXX XXXX ${k['aadhaar_last4'] ?? ''}'],
                ['Consent', k['consent'] == true ? 'given' : 'MISSING'],
                ['Shift confirmed', k['shift_confirmed'] == true ? 'yes' : 'no'],
              ]),
              const SizedBox(height: 8),
              Wrap(spacing: 10, runSpacing: 10, children: [
                if (aadhaar != null && '$aadhaar'.isNotEmpty) KycImage('$aadhaar', size: 120),
                if (selfie != null && '$selfie'.isNotEmpty) KycImage('$selfie', size: 120),
                if (selfie == null || '$selfie'.isEmpty) const Muted('No selfie'),
              ]),
              const Divider(height: 24),
              KeyValue([
                ['Bank holder', '${k['bank_holder_name'] ?? ''}'],
                ['Bank', '${k['bank_name'] ?? ''}'],
                ['Account no.', '${k['bank_account_no'] ?? ''}'],
                ['IFSC', '${k['bank_ifsc'] ?? ''}'],
                ['UPI', '${k['upi_id'] ?? ''}'],
              ]),
            ],
            const Divider(height: 24),
            KeyValue([
              ['Services', svcs.join(', ')],
              ['Experience', t['experience_years'] == null ? '' : '${t['experience_years']} years'],
              ['Hourly rate', t['hourly_rate'] == null ? '' : _money(t['hourly_rate'])],
              ['Shift', '${'${t['shift_start'] ?? ''}'.padRight(5).substring(0, 5).trim()} - ${'${t['shift_end'] ?? ''}'.padRight(5).substring(0, 5).trim()}'],
            ]),
            const SizedBox(height: 12),
            AsyncButton(
              label: 'Approve technician',
              color: kOk,
              onTap: () async {
                final ok = await confirmBox(context, 'Approve this technician? They can accept jobs straight away.', yes: 'Approve');
                if (!ok || !context.mounted) return;
                final err = await _s.setApproved(id, true);
                report(context, err, 'Technician approved');
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================== SOS

class SosPage extends StatefulWidget {
  const SosPage({super.key});
  @override
  State<SosPage> createState() => _SosPageState();
}

class _SosPageState extends State<SosPage> {
  final _range = DateRangeFilter('all');

  List<Rec> _list() {
    const rank = {'open': 0, 'acknowledged': 1, 'resolved': 2};
    final l = _s.sos.where((a) => _range.contains(a['created_at'])).toList();
    l.sort((a, b) {
      final r = (rank[a['status']] ?? 3).compareTo(rank[b['status']] ?? 3);
      return r != 0 ? r : '${b['created_at']}'.compareTo('${a['created_at']}');
    });
    return l;
  }

  @override
  Widget build(BuildContext context) {
    final list = _list();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        RangeBar(filter: _range, onChanged: () => setState(() {})),
        Align(
          alignment: Alignment.centerLeft,
          child: CsvButton(
            name: 'sos_alerts',
            headers: () => ['Time', 'Technician', 'Phone', 'Status', 'Latitude', 'Longitude', 'Map link', 'Booking', 'Note', 'Resolved at'],
            rows: () => [
              for (final a in _list())
                [
                  fdt(a['created_at']), _s.nameOf(a['technician_id']), _s.P['${a['technician_id']}']?['phone'] ?? '',
                  a['status'], a['lat'], a['lng'],
                  a['lat'] != null ? 'https://www.google.com/maps?q=${a['lat']},${a['lng']}' : '',
                  a['booking_id'], a['note'], a['resolved_at'] == null ? '' : fdt(a['resolved_at']),
                ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (list.isEmpty)
          const EmptyBox('No SOS alerts in this period.')
        else
          LayoutBuilder(builder: (context, c) {
            final cols = c.maxWidth > 900 ? 2 : 1;
            final w = (c.maxWidth - 16 * (cols - 1)) / cols;
            return Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [for (final a in list) SizedBox(width: w, child: SosCard(a))],
            );
          }),
      ],
    );
  }
}

class SosCard extends StatelessWidget {
  final Rec a;
  const SosCard(this.a, {super.key});

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final p = s.P['${a['technician_id']}'] ?? <String, dynamic>{};
    final status = '${a['status']}';
    final color = status == 'open' ? kBad : status == 'acknowledged' ? kWarn : kOk;
    final lat = a['lat'];
    final lng = a['lng'];
    final bk = a['booking_id'] == null
        ? null
        : s.bookings.cast<Rec?>().firstWhere((b) => b!['id'] == a['booking_id'], orElse: () => null);
    final phone = '${p['phone'] ?? ''}';

    return Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: status == 'open' ? kBad : Colors.black12, width: status == 'open' ? 2 : 1),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.nameOf(a['technician_id'], 'Technician'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  Muted(phone),
                ]),
              ),
              Pill(status, color),
            ]),
            const SizedBox(height: 6),
            Muted('${fdt(a['created_at'])} · ${ago(a['created_at'])}${a['accuracy_m'] != null ? ' · accuracy ~${numOf(a['accuracy_m']).round()} m' : ''}', size: 13),
            if (bk != null) ...[
              const SizedBox(height: 6),
              Text('During job: ${s.svcName(bk['service_id'])} at ${bk['address'] ?? ''}', style: const TextStyle(fontSize: 13)),
            ],
            const SizedBox(height: 10),
            if (lat != null && lng != null)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.black.withAlpha(10), borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  const Icon(Icons.location_on, color: kBad),
                  const SizedBox(width: 8),
                  Expanded(child: SelectableText('${numOf(lat).toStringAsFixed(5)}, ${numOf(lng).toStringAsFixed(5)}')),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(minimumSize: const Size(0, 38)),
                    onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps?q=$lat,$lng'), webOnlyWindowName: '_blank'),
                    icon: const Icon(Icons.map, size: 18),
                    label: const Text('Open map'),
                  ),
                ]),
              )
            else
              NoticeBanner('Location not available${a['note'] != null ? ': ${a['note']}' : ''}. Call the technician.'),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (phone.isNotEmpty)
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                  onPressed: () => launchUrl(Uri.parse('tel:$phone')),
                  icon: const Icon(Icons.call, size: 18),
                  label: const Text('Call'),
                ),
              if (status == 'open')
                AsyncButton(
                  label: 'Acknowledge',
                  outlined: true,
                  onTap: () async {
                    final err = await _s.sosSet('${a['id']}', 'acknowledged');
                    report(context, err, 'Acknowledged');
                  },
                ),
              if (status != 'resolved')
                AsyncButton(
                  label: 'Mark resolved',
                  color: kOk,
                  onTap: () async {
                    final err = await _s.sosSet('${a['id']}', 'resolved');
                    report(context, err, 'Resolved');
                  },
                ),
            ]),
          ],
        ),
      ),
    );
  }
}
