import 'package:flutter/material.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

Rec _find(List<Rec> list, dynamic id) =>
    list.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{});

// ============================================================== PAYMENTS

class PaymentsPage extends StatefulWidget {
  const PaymentsPage({super.key});
  @override
  State<PaymentsPage> createState() => _PaymentsPageState();
}

class _PaymentsPageState extends State<PaymentsPage> {
  final _range = DateRangeFilter('all');
  String _status = 'all';

  List<Rec> _all() => _s.payments.where((p) => _range.contains(p['created_at'])).toList();
  List<Rec> _list() {
    final a = _all();
    return _status == 'all' ? a : a.where((p) => p['status'] == _status).toList();
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final all = _all();
    num sum(List<String> st) =>
        all.where((p) => st.contains(p['status'])).fold<num>(0, (a, p) => a + numOf(p['amount']));
    final list = _list();
    final missing = s.bookingsWithoutPayment.length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TileGrid([
          StatTile('To pay', money(sum(['pending', 'processing']))),
          StatTile('Paid', money(sum(['paid']))),
          StatTile('Failed', money(sum(['failed']))),
        ]),
        const SizedBox(height: 16),
        if (missing > 0)
          NoticeBanner(
            '$missing completed job${missing > 1 ? 's have' : ' has'} no payment row (finished before payments were switched on).',
            action: AsyncButton(
              label: 'Create missing payments',
              outlined: true,
              onTap: () async {
                final err = await _s.createMissingPayments();
                report(context, err, 'Payment rows created');
              },
            ),
          ),
        RangeBar(filter: _range, onChanged: () => setState(() {})),
        Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          for (final st in ['all', 'pending', 'processing', 'paid', 'failed'])
            ChoiceChip(
              label: Text(st[0].toUpperCase() + st.substring(1)),
              selected: _status == st,
              onSelected: (_) => setState(() => _status = st),
            ),
          CsvButton(
            name: 'technician_payments',
            headers: () => ['Created', 'Technician', 'Phone', 'Service', 'Job date', 'Amount', 'Status', 'Paid on', 'Reference', 'Note'],
            rows: () => [
              for (final p in _list())
                () {
                  final b = _find(s.bookings, p['booking_id']);
                  return <dynamic>[
                    fdt(p['created_at']), s.nameOf(p['technician_id']), s.P['${p['technician_id']}']?['phone'] ?? '',
                    b.isEmpty ? '' : s.svcName(b['service_id']), b.isEmpty ? '' : fdt(b['scheduled_at']),
                    numOf(p['amount']), p['status'], p['paid_at'] == null ? '' : fdt(p['paid_at']),
                    p['reference'], p['note'],
                  ];
                }(),
            ],
          ),
        ]),
        const SizedBox(height: 12),
        AdminTable(
          columns: const ['Created', 'Technician', 'Job', 'Amount', 'Status', 'Reference', ''],
          numeric: const {3},
          empty: 'No payments here yet.',
          rows: [
            for (final p in list)
              () {
                final b = _find(s.bookings, p['booking_id']);
                final id = '${p['id']}';
                return <Widget>[
                  Text(fday(p['created_at'])),
                  TwoLine(s.nameOf(p['technician_id'], 'Technician'), '${s.P['${p['technician_id']}']?['phone'] ?? ''}'),
                  TwoLine(b.isEmpty ? '-' : s.svcName(b['service_id']), b.isEmpty ? '' : fday(b['scheduled_at'])),
                  Text(money(p['amount']), style: const TextStyle(fontWeight: FontWeight.bold)),
                  Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    PayPill('${p['status'] ?? ''}'),
                    if (p['paid_at'] != null) Muted(fday(p['paid_at'])),
                  ]),
                  Text('${p['reference'] ?? ''}'),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    if (p['status'] != 'paid')
                      AsyncButton(
                        label: 'Mark paid',
                        color: kOk,
                        onTap: () async {
                          final ok = await confirmBox(context, 'Mark this payment as PAID? The technician will be notified.', yes: 'Mark paid');
                          if (!ok || !context.mounted) return;
                          final err = await _s.payQuick(id);
                          report(context, err, 'Marked as paid');
                        },
                      ),
                    const SizedBox(width: 6),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                      onPressed: () => showDialog<void>(context: context, builder: (_) => _PaymentDialog(p)),
                      child: const Text('Edit'),
                    ),
                  ]),
                ];
              }(),
          ],
        ),
        const SizedBox(height: 8),
        const Muted('Changing a status automatically sends the technician an update in their Payments tab.'),
      ],
    );
  }
}

class _PaymentDialog extends StatefulWidget {
  final Rec p;
  const _PaymentDialog(this.p);
  @override
  State<_PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends State<_PaymentDialog> {
  late String _status;
  late final TextEditingController _amount;
  late final TextEditingController _ref;
  late final TextEditingController _note;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final p = widget.p;
    _status = ['pending', 'processing', 'paid', 'failed'].contains(p['status']) ? '${p['status']}' : 'pending';
    _amount = TextEditingController(text: '${p['amount'] ?? ''}');
    _ref = TextEditingController(text: '${p['reference'] ?? ''}');
    _note = TextEditingController(text: '${p['note'] ?? ''}');
  }

  @override
  void dispose() {
    _amount.dispose();
    _ref.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    final err = await _s.paySave('${widget.p['id']}', {
      'status': _status,
      'amount': numOf(_amount.text),
      'reference': _ref.text.trim().isEmpty ? null : _ref.text.trim(),
      'note': _note.text.trim().isEmpty ? null : _note.text.trim(),
    });
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, 'Payment updated');
    if (err == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final k = _s.KYC['${widget.p['technician_id']}'];
    final bank = k == null || k['bank_account_no'] == null
        ? 'No bank details on file'
        : 'A/c ${k['bank_account_no']} · ${k['bank_ifsc'] ?? ''} · ${k['bank_holder_name'] ?? ''}${k['upi_id'] != null ? ' · UPI ${k['upi_id']}' : ''}';
    return AlertDialog(
      title: Text('Payment to ${_s.nameOf(widget.p['technician_id'], 'technician')}'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText(bank, style: const TextStyle(fontSize: 13, color: Colors.black54)),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: _status,
              decoration: const InputDecoration(labelText: 'Status'),
              items: [for (final s in ['pending', 'processing', 'paid', 'failed']) DropdownMenuItem(value: s, child: Text(s))],
              onChanged: (v) => setState(() => _status = v ?? _status),
            ),
            const SizedBox(height: 12),
            TextField(
                controller: _amount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Amount (₹)')),
            const SizedBox(height: 12),
            TextField(controller: _ref, decoration: const InputDecoration(labelText: 'Bank / UPI reference (UTR)')),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: const InputDecoration(labelText: 'Note (shown if failed)')),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _busy ? null : _save,
          child: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Save'),
        ),
      ],
    );
  }
}

// ============================================================== BOOKINGS

class BookingsPage extends StatefulWidget {
  const BookingsPage({super.key});
  @override
  State<BookingsPage> createState() => _BookingsPageState();
}

class _BookingsPageState extends State<BookingsPage> {
  final _range = DateRangeFilter('all');
  final _search = TextEditingController();
  String _status = 'all';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Rec> _list() {
    final s = _s;
    final term = _search.text.trim().toLowerCase();
    return s.bookings.where((b) {
      if (!_range.contains(b['scheduled_at'])) return false;
      if (_status != 'all' && b['status'] != _status) return false;
      if (term.isEmpty) return true;
      final hay = [
        s.nameOf(b['customer_id'], ''), s.nameOf(b['technician_id'], ''), s.svcName(b['service_id']),
        b['address'] ?? '', b['pincode'] ?? '',
      ].join(' ').toLowerCase();
      return hay.contains(term);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final list = _list();
    final shown = list.take(300).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        RangeBar(filter: _range, onChanged: () => setState(() {})),
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SizedBox(
            width: 280,
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                  hintText: 'Search name, service, address, pincode',
                  prefixIcon: Icon(Icons.search),
                  isDense: true),
            ),
          ),
          SizedBox(
            width: 170,
            child: DropdownButtonFormField<String>(
              value: _status,
              isDense: true,
              items: [
                for (final st in ['all', 'pending', 'accepted', 'in_progress', 'completed', 'cancelled'])
                  DropdownMenuItem(value: st, child: Text(st == 'all' ? 'All statuses' : statusLabel(st))),
              ],
              onChanged: (v) => setState(() => _status = v ?? 'all'),
            ),
          ),
          Muted('${list.length} booking${list.length == 1 ? '' : 's'}', size: 13),
          CsvButton(
            name: 'bookings',
            headers: () => ['When', 'Service', 'Type', 'Hours', 'Customer', 'Customer phone', 'Technician', 'Status', 'Price', 'Estimate min', 'Estimate max', 'Address', 'Pincode'],
            rows: () => [
              for (final b in _list())
                [
                  fdt(b['scheduled_at']), s.svcName(b['service_id']), b['booking_type'], b['hours'],
                  s.nameOf(b['customer_id'], ''), s.P['${b['customer_id']}']?['phone'] ?? '',
                  s.nameOf(b['technician_id'], ''), b['status'], b['price'], b['estimated_min'],
                  b['estimated_max'], b['address'], b['pincode'],
                ],
            ],
          ),
        ]),
        const SizedBox(height: 12),
        AdminTable(
          columns: const ['When', 'Service', 'Customer', 'Technician', 'Status', 'Price'],
          numeric: const {5},
          empty: 'No bookings match.',
          onRowTap: (i) => showDialog<void>(context: context, builder: (_) => _BookingDialog(shown[i])),
          rows: [
            for (final b in shown)
              <Widget>[
                Text(fdt(b['scheduled_at'])),
                TwoLine(s.svcName(b['service_id']),
                    b['booking_type'] == 'inspection' ? 'Inspection' : 'Hourly${b['hours'] != null ? ' · ${b['hours']} h' : ''}'),
                Text(s.nameOf(b['customer_id'])),
                b['technician_id'] == null ? const Muted('Not assigned', size: 14) : Text(s.nameOf(b['technician_id'])),
                StatusPill('${b['status'] ?? ''}'),
                Text(b['price'] != null ? money(b['price']) : '-'),
              ],
          ],
        ),
        if (list.length > 300) const Padding(padding: EdgeInsets.only(top: 8), child: Muted('Showing the first 300. Use search or dates to narrow down.')),
      ],
    );
  }
}

class _BookingDialog extends StatefulWidget {
  final Rec b;
  const _BookingDialog(this.b);
  @override
  State<_BookingDialog> createState() => _BookingDialogState();
}

class _BookingDialogState extends State<_BookingDialog> {
  late final TextEditingController _price;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _price = TextEditingController(text: widget.b['price'] == null ? '' : '${widget.b['price']}');
  }

  @override
  void dispose() {
    _price.dispose();
    super.dispose();
  }

  List<String> _urls(dynamic v) => v is List ? v.map((e) => '$e').where((e) => e.startsWith('http')).toList() : <String>[];

  Future<void> _savePrice() async {
    if (_price.text.trim().isEmpty) {
      toast(context, 'Enter a price', error: true);
      return;
    }
    setState(() => _busy = true);
    final err = await _s.bookingSetPrice('${widget.b['id']}', numOf(_price.text));
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, 'Price saved');
    if (err == null) Navigator.pop(context);
  }

  Future<void> _cancel() async {
    final ok = await confirmBox(context, 'Cancel this booking? This cannot be undone.', yes: 'Cancel booking');
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final err = await _s.bookingCancel('${widget.b['id']}');
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, 'Booking cancelled');
    if (err == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final b = widget.b;
    final c = s.P['${b['customer_id']}'] ?? <String, dynamic>{};
    final t = s.P['${b['technician_id']}'] ?? <String, dynamic>{};
    final photos = _urls(b['photos']);
    final done = _urls(b['completion_photos']);
    final status = '${b['status'] ?? ''}';
    return AlertDialog(
      title: Row(children: [
        Expanded(child: Text(s.svcName(b['service_id']))),
        StatusPill(status),
      ]),
      content: SizedBox(
        width: 480,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Muted(fdt(b['scheduled_at']), size: 13),
            const SizedBox(height: 10),
            KeyValue([
              ['Customer', '${c['name'] ?? '-'} · ${c['phone'] ?? ''}\n${c['email'] ?? ''}'],
              ['Technician', b['technician_id'] == null ? 'Not assigned yet' : '${t['name'] ?? '-'} · ${t['phone'] ?? ''}'],
              ['Address', '${b['address'] ?? ''} ${b['pincode'] != null ? '(${b['pincode']})' : ''}'],
              ['Type', b['booking_type'] == 'inspection' ? 'Estimate & inspection' : 'Hourly${b['hours'] != null ? ', ${b['hours']} h' : ''}'],
              ['Estimate', b['estimated_min'] == null ? '' : '${money(b['estimated_min'])} - ${money(b['estimated_max'])}'],
              ['Notes', '${b['notes'] ?? ''}'],
            ]),
            if (photos.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [for (final u in photos) NetPhoto(u, size: 90)]),
            ],
            if (done.isNotEmpty) ...[
              const SizedBox(height: 10),
              const Muted('Completion photos'),
              const SizedBox(height: 4),
              Wrap(spacing: 8, runSpacing: 8, children: [for (final u in done) NetPhoto(u, size: 90)]),
            ],
            const Divider(height: 28),
            TextField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'Final price (₹)',
                  helperText: "Updates the technician's pending payment"),
            ),
          ]),
        ),
      ),
      actions: [
        if (status != 'cancelled' && status != 'completed')
          TextButton(
              onPressed: _busy ? null : _cancel,
              style: TextButton.styleFrom(foregroundColor: kBad),
              child: const Text('Cancel booking')),
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Close')),
        FilledButton(
          onPressed: _busy ? null : _savePrice,
          child: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Save price'),
        ),
      ],
    );
  }
}

// ============================================================== PEOPLE

class PeoplePage extends StatefulWidget {
  const PeoplePage({super.key});
  @override
  State<PeoplePage> createState() => _PeoplePageState();
}

class _PeoplePageState extends State<PeoplePage> {
  bool _tech = true;
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  bool _match(Rec p) {
    final term = _search.text.trim().toLowerCase();
    if (term.isEmpty) return true;
    return ['${p['name'] ?? ''}', '${p['email'] ?? ''}', '${p['phone'] ?? ''}', '${p['pincode'] ?? ''}']
        .join(' ')
        .toLowerCase()
        .contains(term);
  }

  List<Rec> _techs() => _s.profiles.where((p) => p['role'] == 'technician' && _match(p)).toList();
  List<Rec> _custs() => _s.profiles.where((p) => p['role'] == 'customer' && _match(p)).toList();
  int _jobs(String id) => _s.bookings.where((b) => b['technician_id'] == id && b['status'] == 'completed').length;

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final techs = _techs();
    final custs = _custs();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: true, label: Text('Technicians')),
              ButtonSegment(value: false, label: Text('Customers')),
            ],
            selected: {_tech},
            onSelectionChanged: (v) => setState(() => _tech = v.first),
          ),
          SizedBox(
            width: 280,
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                  hintText: 'Search name, email, phone, pincode', prefixIcon: Icon(Icons.search), isDense: true),
            ),
          ),
          if (_tech)
            CsvButton(
              name: 'technicians',
              headers: () => ['Name', 'Email', 'Phone', 'Pincode', 'Status', 'Services', 'Hourly rate', 'Rating', 'Completed jobs'],
              rows: () => [
                for (final p in _techs())
                  () {
                    final t = s.TP['${p['id']}'] ?? <String, dynamic>{};
                    return <dynamic>[
                      p['name'], p['email'], p['phone'], p['pincode'],
                      p['approved'] == true ? (t['paused'] == true ? 'paused' : 'active') : 'not approved',
                      s.techServices('${p['id']}').join('; '), t['hourly_rate'], t['rating'], _jobs('${p['id']}'),
                    ];
                  }(),
              ],
            )
          else
            CsvButton(
              name: 'customers',
              headers: () => ['Name', 'Email', 'Phone', 'Pincode', 'Bookings'],
              rows: () => [
                for (final p in _custs())
                  [p['name'], p['email'], p['phone'], p['pincode'], s.bookings.where((b) => b['customer_id'] == p['id']).length],
              ],
            ),
        ]),
        const SizedBox(height: 12),
        if (_tech)
          AdminTable(
            columns: const ['Technician', 'Contact', 'Services', 'Rate', 'Jobs', 'Status', ''],
            numeric: const {3, 4},
            empty: 'No technicians found.',
            rows: [
              for (final p in techs)
                () {
                  final id = '${p['id']}';
                  final t = s.TP[id] ?? <String, dynamic>{};
                  final approved = p['approved'] == true;
                  final rating = numOf(t['rating']);
                  return <Widget>[
                    TwoLine('${p['name'] ?? '-'}', '${p['email'] ?? ''}'),
                    TwoLine('${p['phone'] ?? ''}', 'PIN ${p['pincode'] ?? '-'}'),
                    ConstrainedBox(constraints: const BoxConstraints(maxWidth: 200), child: Text(s.techServices(id).join(', '), maxLines: 2, overflow: TextOverflow.ellipsis)),
                    Text(t['hourly_rate'] != null ? money(t['hourly_rate']) : '-'),
                    Text('${_jobs(id)}${rating > 0 ? ' · ★${rating.toStringAsFixed(1)}' : ''}'),
                    approved ? (t['paused'] == true ? const Pill('Paused', kWarn) : const Pill('Active', kOk)) : Pill('Not approved', Colors.grey.shade700),
                    AsyncButton(
                      label: approved ? 'Suspend' : 'Approve',
                      color: approved ? kBad : kOk,
                      onTap: () async {
                        final ok = await confirmBox(
                            context,
                            approved ? 'Suspend this technician? They will stop receiving jobs.' : 'Approve this technician?',
                            yes: approved ? 'Suspend' : 'Approve');
                        if (!ok || !context.mounted) return;
                        final err = await _s.setApproved(id, !approved);
                        report(context, err, approved ? 'Suspended' : 'Approved');
                      },
                    ),
                  ];
                }(),
            ],
          )
        else
          AdminTable(
            columns: const ['Customer', 'Email', 'Phone', 'Pincode', 'Bookings'],
            numeric: const {4},
            empty: 'No customers found.',
            rows: [
              for (final p in custs)
                <Widget>[
                  Text('${p['name'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text('${p['email'] ?? ''}'),
                  Text('${p['phone'] ?? ''}'),
                  Text('${p['pincode'] ?? '-'}'),
                  Text('${s.bookings.where((b) => b['customer_id'] == p['id']).length}'),
                ],
            ],
          ),
      ],
    );
  }
}

// ============================================================== SERVICES

class ServicesPage extends StatelessWidget {
  const ServicesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size(0, 40)),
            onPressed: () => showDialog<void>(context: context, builder: (_) => const _ServiceDialog(null)),
            icon: const Icon(Icons.add),
            label: const Text('Add service'),
          ),
          CsvButton(
            name: 'services',
            headers: () => ['Name', 'Base price per hour', 'Inspection fee', 'Visible'],
            rows: () => [
              for (final x in s.services) [x['name'], x['base_price'], x['inspection_fee'], x['active'] == false ? 'hidden' : 'active'],
            ],
          ),
          const Muted('Customers see only Active services. Inspection fee is the fixed visit price.'),
        ]),
        const SizedBox(height: 12),
        AdminTable(
          columns: const ['Name', 'Base price (₹/hr)', 'Inspection fee (₹)', 'Visible', ''],
          numeric: const {1, 2},
          empty: 'No services yet.',
          rows: [
            for (final x in s.services)
              <Widget>[
                Text('${x['name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(money(x['base_price'])),
                Text(money(x['inspection_fee'])),
                x['active'] == false ? Pill('Hidden', Colors.grey.shade700) : const Pill('Active', kOk),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                  onPressed: () => showDialog<void>(context: context, builder: (_) => _ServiceDialog(x)),
                  child: const Text('Edit'),
                ),
              ],
          ],
        ),
      ],
    );
  }
}

class _ServiceDialog extends StatefulWidget {
  final Rec? svc;
  const _ServiceDialog(this.svc);
  @override
  State<_ServiceDialog> createState() => _ServiceDialogState();
}

class _ServiceDialogState extends State<_ServiceDialog> {
  late final TextEditingController _name;
  late final TextEditingController _base;
  late final TextEditingController _insp;
  late bool _active;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final x = widget.svc;
    _name = TextEditingController(text: x == null ? '' : '${x['name'] ?? ''}');
    _base = TextEditingController(text: x == null ? '300' : '${x['base_price'] ?? ''}');
    _insp = TextEditingController(text: x == null ? '199' : '${x['inspection_fee'] ?? ''}');
    _active = x == null ? true : x['active'] != false;
  }

  @override
  void dispose() {
    _name.dispose();
    _base.dispose();
    _insp.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      toast(context, 'Name is required', error: true);
      return;
    }
    setState(() => _busy = true);
    final String? err;
    if (widget.svc == null) {
      err = await _s.serviceCreate(name, numOf(_base.text), numOf(_insp.text));
    } else {
      err = await _s.serviceSave('${widget.svc!['id']}', {
        'name': name,
        'base_price': _base.text.trim().isEmpty ? null : numOf(_base.text),
        'inspection_fee': _insp.text.trim().isEmpty ? null : numOf(_insp.text),
        'active': _active,
      });
    }
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, 'Service saved');
    if (err == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.svc == null ? 'Add service' : 'Edit service'),
      content: SizedBox(
        width: 380,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name (e.g. Plumbing)')),
            const SizedBox(height: 12),
            TextField(
                controller: _base,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Base price per hour (₹)')),
            const SizedBox(height: 12),
            TextField(
                controller: _insp,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Inspection fee (₹)')),
            if (widget.svc != null)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Visible to customers'),
                value: _active,
                onChanged: (v) => setState(() => _active = v),
              ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _busy ? null : _save,
          child: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : Text(widget.svc == null ? 'Create' : 'Save'),
        ),
      ],
    );
  }
}

// ============================================================== TEAM

class TeamPage extends StatefulWidget {
  const TeamPage({super.key});
  @override
  State<TeamPage> createState() => _TeamPageState();
}

class _TeamPageState extends State<TeamPage> {
  final _range = DateRangeFilter('7');
  String _admin = 'all';

  List<Rec> _rows() {
    final l = _s.activity
        .where((x) => _range.contains(x['day']) && (_admin == 'all' || x['admin_id'] == _admin))
        .toList();
    l.sort((a, b) {
      final d = '${b['day']}'.compareTo('${a['day']}');
      return d != 0 ? d : _s.nameOf(a['admin_id']).compareTo(_s.nameOf(b['admin_id']));
    });
    return l;
  }

  List<Rec> _acts() => _s.actions
      .where((x) => _range.contains(x['created_at']) && (_admin == 'all' || x['admin_id'] == _admin))
      .toList();

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final rows = _rows();
    final acts = _acts();
    final admins = s.admins.where((a) => _admin == 'all' || a['id'] == _admin).toList();
    final today = dkey(DateTime.now());
    final tracking = s.errors['tracking'];

    final days = rows.map((x) => '${x['day']}').toSet().toList()..sort();
    final lastDays = days.length > 31 ? days.sublist(days.length - 31) : days;
    final palette = [kBrand, kInfo, kViolet, kWarn, kOk];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (tracking != null) NoticeBanner(tracking, color: kBad),
        LayoutBuilder(builder: (context, c) {
          final cols = c.maxWidth > 900 ? 3 : c.maxWidth > 600 ? 2 : 1;
          final w = (c.maxWidth - 12 * (cols - 1)) / cols;
          if (s.admins.isEmpty) return const EmptyBox('No admin accounts found.');
          return Wrap(spacing: 12, runSpacing: 12, children: [
            for (final a in s.admins)
              SizedBox(
                width: w,
                child: () {
                  final id = '${a['id']}';
                  final on = s.isOnline(id);
                  final pr = s.presenceOf(id);
                  final act = s.activity.firstWhere(
                      (x) => x['admin_id'] == a['id'] && '${x['day']}' == today,
                      orElse: () => <String, dynamic>{});
                  final isMe = s.me != null && s.me!['id'] == a['id'];
                  return Card(
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          PresenceDot(on, size: 12),
                          const SizedBox(width: 8),
                          Expanded(child: Text('${a['name'] ?? a['email'] ?? 'Admin'}', style: const TextStyle(fontWeight: FontWeight.bold))),
                          if (isMe) const Pill('you', kInfo),
                        ]),
                        const SizedBox(height: 4),
                        Muted(on
                            ? 'Online${pr != null && pr['page'] != null ? ' · viewing ${pr['page']}' : ''}'
                            : (pr != null ? 'Offline · last seen ${ago(pr['last_seen'])}' : 'Has not used tracking yet')),
                        const SizedBox(height: 8),
                        KeyValue([
                          ['Online today', hm(numOf(act['seconds_online']))],
                          ['Active today', hm(numOf(act['seconds_active']))],
                          ['First seen', ftime(act['first_seen'])],
                        ]),
                      ]),
                    ),
                  );
                }(),
              ),
          ]);
        }),
        const SizedBox(height: 16),
        RangeBar(filter: _range, onChanged: () => setState(() {})),
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SizedBox(
            width: 220,
            child: DropdownButtonFormField<String>(
              value: _admin,
              isDense: true,
              items: [
                const DropdownMenuItem(value: 'all', child: Text('All admins')),
                for (final a in s.admins)
                  DropdownMenuItem(value: '${a['id']}', child: Text('${a['name'] ?? a['email'] ?? 'Admin'}')),
              ],
              onChanged: (v) => setState(() => _admin = v ?? 'all'),
            ),
          ),
          CsvButton(
            label: 'Time report (CSV)',
            name: 'admin_time_report',
            headers: () => ['Date', 'Admin', 'Online (hours)', 'Active (hours)', 'First seen', 'Last seen'],
            rows: () => [
              for (final x in _rows())
                [x['day'], s.nameOf(x['admin_id']), hrs(numOf(x['seconds_online'])), hrs(numOf(x['seconds_active'])), fdt(x['first_seen']), fdt(x['last_seen'])],
            ],
          ),
          CsvButton(
            label: 'Action log (CSV)',
            name: 'admin_action_log',
            headers: () => ['When', 'Admin', 'Action', 'Detail'],
            rows: () => [for (final x in _acts()) [fdt(x['created_at']), s.nameOf(x['admin_id'], ''), x['action'], x['detail'] ?? '']],
          ),
        ]),
        const Padding(
          padding: EdgeInsets.only(top: 6),
          child: Muted('Online = dashboard open. Active = you used it in the last minute.'),
        ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'Active hours per day',
          child: lastDays.isEmpty
              ? const Muted('No tracked time in this period yet.', size: 14)
              : BarChart(
                  labels: [for (final d in lastDays) fday(d).replaceAll(RegExp(r',? ?\d{4}$'), '')],
                  series: [
                    for (var i = 0; i < admins.length; i++)
                      ChartSeries(
                        '${admins[i]['name'] ?? admins[i]['email'] ?? 'Admin'}',
                        palette[i % palette.length],
                        [
                          for (final d in lastDays)
                            () {
                              final r = s.activity.firstWhere(
                                  (x) => x['admin_id'] == admins[i]['id'] && '${x['day']}' == d,
                                  orElse: () => <String, dynamic>{});
                              return hrs(numOf(r['seconds_active']));
                            }(),
                        ],
                      ),
                  ],
                ),
        ),
        const SectionTitle('Summary for the period'),
        AdminTable(
          columns: const ['Admin', 'Days worked', 'Online', 'Active', 'Avg active / day', 'Actions'],
          numeric: const {1, 2, 3, 4, 5},
          empty: 'No admins.',
          rows: [
            for (final a in admins)
              () {
                final mine = rows.where((x) => x['admin_id'] == a['id']).toList();
                final on = mine.fold<num>(0, (t, x) => t + numOf(x['seconds_online']));
                final ac = mine.fold<num>(0, (t, x) => t + numOf(x['seconds_active']));
                final d = mine.where((x) => numOf(x['seconds_online']) > 0).length;
                return <Widget>[
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    PresenceDot(s.isOnline('${a['id']}')),
                    const SizedBox(width: 8),
                    Text('${a['name'] ?? a['email'] ?? 'Admin'}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  ]),
                  Text('$d'),
                  Text(hm(on)),
                  Text(hm(ac)),
                  Text(d > 0 ? hm(ac / d) : '-'),
                  Text('${acts.where((x) => x['admin_id'] == a['id']).length}'),
                ];
              }(),
          ],
        ),
        const SectionTitle('Day by day'),
        AdminTable(
          columns: const ['Date', 'Admin', 'Online', 'Active', 'First seen', 'Last seen'],
          numeric: const {2, 3},
          empty: 'No tracked time in this period yet.',
          rows: [
            for (final x in rows)
              <Widget>[
                Text(fday(x['day'])),
                Text(s.nameOf(x['admin_id'])),
                Text(hm(numOf(x['seconds_online']))),
                Text(hm(numOf(x['seconds_active']))),
                Text(ftime(x['first_seen'])),
                Text(ftime(x['last_seen'])),
              ],
          ],
        ),
        const SectionTitle('Action log'),
        AdminTable(
          columns: const ['When', 'Admin', 'Action', 'Detail'],
          empty: 'No actions in this period.',
          rows: [
            for (final x in acts.take(150))
              <Widget>[
                Text(fdt(x['created_at'])),
                Text(s.nameOf(x['admin_id'])),
                Text('${x['action'] ?? ''}'),
                ConstrainedBox(constraints: const BoxConstraints(maxWidth: 320), child: Text('${x['detail'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis)),
              ],
          ],
        ),
        if (acts.length > 150) const Padding(padding: EdgeInsets.only(top: 8), child: Muted('Showing the latest 150. Download the CSV for all.')),
      ],
    );
  }
}
