import 'dart:convert';
import 'dart:js_interop';
import 'dart:typed_data';

import 'package:web/web.dart' as web;

import 'admin_store.dart';
import 'admin_util.dart';

String _cell(dynamic v) {
  var s = v == null ? '' : '$v';
  // Stop spreadsheet programs from running text that starts like a formula.
  if (RegExp(r'^[=@]').hasMatch(s) || RegExp(r'^[+\-](?![\d\s]*$)').hasMatch(s)) {
    s = "'$s";
  }
  if (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r')) {
    s = '"${s.replaceAll('"', '""')}"';
  }
  return s;
}

/// Downloads a CSV file in the browser (opens fine in Excel / Google Sheets).
/// Returns the file name.
String downloadCsv(String name, List<String> headers, List<List<dynamic>> rows) {
  final text = '﻿${[headers, ...rows].map((r) => r.map(_cell).join(',')).join('\r\n')}';
  final bytes = Uint8List.fromList(utf8.encode(text));
  final blob = web.Blob(<JSAny>[bytes.toJS].toJS, web.BlobPropertyBag(type: 'text/csv;charset=utf-8'));
  final url = web.URL.createObjectURL(blob);
  final fileName = '${name}_${dkey(DateTime.now())}.csv';
  final a = web.document.createElement('a') as web.HTMLAnchorElement;
  a.href = url;
  a.download = fileName;
  web.document.body!.append(a);
  a.click();
  a.remove();
  Future.delayed(const Duration(seconds: 1), () => web.URL.revokeObjectURL(url));
  AdminStore.I.logAction('Downloaded report', '$name (${rows.length} rows)');
  return fileName;
}
