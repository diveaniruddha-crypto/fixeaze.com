import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import 'admin_util.dart';

/// Everything the admin dashboard knows, loaded once and shared by all pages.
class AdminStore extends ChangeNotifier with WidgetsBindingObserver {
  AdminStore._();
  static final AdminStore I = AdminStore._();

  // ---- session ----
  Rec? me;
  bool booting = true;
  bool loaded = false;
  bool loading = false;
  String page = 'overview';

  // ---- data ----
  List<Rec> profiles = [];
  List<Rec> tprof = [];
  List<Rec> kyc = [];
  List<Rec> tsvc = [];
  List<Rec> services = [];
  List<Rec> bookings = [];
  List<Rec> payments = [];
  List<Rec> sos = [];
  List<Rec> reviews = [];
  List<Rec> activity = [];
  List<Rec> presence = [];
  List<Rec> actions = [];
  List<Rec> dues = [];
  List<Rec> promos = [];
  Rec settings = {};
  Map<String, String> errors = {};

  Map<String, Rec> P = {};
  Map<String, Rec> TP = {};
  Map<String, Rec> KYC = {};
  Map<String, Rec> SVC = {};

  // ---- tracking ----
  Timer? _timer;
  DateTime _lastTouch = DateTime.now();
  bool _foreground = true;
  bool trackWarned = false;
  StreamSubscription<List<Map<String, dynamic>>>? _sosSub;
  Set<String>? _knownSos;
  Rec? sosBanner;

  // ---------------------------------------------------------------- getters
  List<Rec> get admins => profiles.where((p) => p['role'] == 'admin').toList();
  List<Rec> get pendingTechs =>
      profiles.where((p) => p['role'] == 'technician' && p['approved'] != true).toList();
  List<Rec> get openSos => sos.where((s) => s['status'] == 'open').toList();
  int get duePayments =>
      payments.where((p) => p['status'] == 'pending' || p['status'] == 'processing').length;

  String nameOf(dynamic id, [String fallback = '-']) {
    final p = P['$id'];
    final n = p == null ? null : p['name'];
    return (n == null || '$n'.trim().isEmpty) ? fallback : '$n';
  }

  String svcName(dynamic id) {
    final s = SVC['$id'];
    return s == null ? 'Other' : '${s['name'] ?? 'Service'}';
  }

  List<String> techServices(String id) => tsvc
      .where((x) => x['technician_id'] == id)
      .map((x) => SVC['${x['service_id']}']?['name'])
      .where((n) => n != null)
      .map((n) => '$n')
      .toList();

  Rec? presenceOf(String id) {
    for (final p in presence) {
      if (p['admin_id'] == id) return p;
    }
    return null;
  }

  bool isOnline(String id) {
    if (me != null && me!['id'] == id) return true;
    final p = presenceOf(id);
    if (p == null) return false;
    final t = parseTime(p['last_seen']);
    return t != null && DateTime.now().difference(t).inSeconds < 100;
  }

  String payLabel(String id) {
    final p = payments.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{});
    return '${nameOf(p['technician_id'], 'technician')} ${p['amount'] ?? ''}';
  }

  // ---------------------------------------------------------------- loading
  Future<List<Rec>> _fetch(String table, {String? orderBy, bool asc = true, int? limit}) async {
    try {
      dynamic q = supabase.from(table).select('*');
      if (orderBy != null) q = q.order(orderBy, ascending: asc);
      if (limit != null) q = q.limit(limit);
      final data = await q;
      return (data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      errors[table] = e is PostgrestException ? e.message : '$e';
      return <Rec>[];
    }
  }

  Future<void> loadAll({bool silent = false}) async {
    if (loading) return;
    loading = true;
    if (!silent) notifyListeners();
    errors = {};
    final r = await Future.wait<List<Rec>>([
      _fetch('profiles'),
      _fetch('technician_profiles'),
      _fetch('technician_kyc'),
      _fetch('technician_services'),
      _fetch('services', orderBy: 'name'),
      _fetch('bookings', orderBy: 'scheduled_at', asc: false, limit: 2000),
      _fetch('technician_payments', orderBy: 'created_at', asc: false),
      _fetch('sos_alerts', orderBy: 'created_at', asc: false),
      _fetch('reviews'),
      _fetch('admin_activity', orderBy: 'day', asc: false, limit: 3000),
      _fetch('admin_presence'),
      _fetch('admin_actions', orderBy: 'created_at', asc: false, limit: 1500),
      _fetch('cash_dues', orderBy: 'created_at', asc: false),
      _fetch('platform_settings'),
      _fetch('promos', orderBy: 'created_at', asc: false),
    ]);
    profiles = r[0];
    tprof = r[1];
    kyc = r[2];
    tsvc = r[3];
    services = r[4];
    bookings = r[5];
    payments = r[6];
    sos = r[7];
    reviews = r[8];
    activity = r[9];
    presence = r[10];
    actions = r[11];
    dues = r[12];
    settings = r[13].isEmpty ? <String, dynamic>{} : r[13].first;
    promos = r[14];
    P = {for (final x in profiles) '${x['id']}': x};
    TP = {for (final x in tprof) '${x['id']}': x};
    KYC = {for (final x in kyc) '${x['id']}': x};
    SVC = {for (final x in services) '${x['id']}': x};
    loaded = true;
    loading = false;
    _updateTitle();
    notifyListeners();
  }

  void _updateTitle() {
    final n = openSos.length;
    try {
      SystemChrome.setApplicationSwitcherDescription(ApplicationSwitcherDescription(
        label: n > 0 ? '($n SOS) Fixeaze Admin' : 'Fixeaze Admin',
        primaryColor: 0xFF00796B,
      ));
    } catch (_) {}
  }

  // ---------------------------------------------------------------- auth
  Future<void> restore() async {
    try {
      final s = supabase.auth.currentSession;
      if (s != null) await _enter(s.user.id, s.user.email);
    } catch (_) {
      // Not an admin or session expired: show the login screen.
    }
    booting = false;
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async {
    final res = await supabase.auth.signInWithPassword(email: email.trim(), password: password);
    final u = res.user;
    if (u == null) throw 'Could not sign in.';
    await _enter(u.id, u.email);
    notifyListeners();
  }

  Future<void> _enter(String uid, String? email) async {
    final row = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (row == null || row['role'] != 'admin') {
      await supabase.auth.signOut();
      throw 'This account is not an admin account.';
    }
    me = Map<String, dynamic>.from(row);
    await loadAll(silent: true);
    _watchSos();
    _startTracking();
  }

  Future<void> signOut() async {
    _timer?.cancel();
    _sosSub?.cancel();
    _sosSub = null;
    _knownSos = null;
    try {
      await supabase.rpc('admin_offline');
    } catch (_) {}
    await supabase.auth.signOut();
    me = null;
    loaded = false;
    sosBanner = null;
    notifyListeners();
  }

  // ---------------------------------------------------------------- live SOS
  void _watchSos() {
    _sosSub?.cancel();
    _knownSos = null;
    try {
      _sosSub = supabase.from('sos_alerts').stream(primaryKey: ['id']).listen((rows) {
        final list = rows.map((e) => Map<String, dynamic>.from(e)).toList()
          ..sort((a, b) => '${b['created_at']}'.compareTo('${a['created_at']}'));
        final ids = list.map((e) => '${e['id']}').toSet();
        final known = _knownSos;
        if (known != null) {
          for (final a in list) {
            if (a['status'] == 'open' && !known.contains('${a['id']}')) {
              sosBanner = a;
            }
          }
        }
        _knownSos = ids;
        sos = list;
        _updateTitle();
        notifyListeners();
      }, onError: (_) {});
    } catch (_) {}
  }

  void dismissSosBanner() {
    sosBanner = null;
    notifyListeners();
  }

  // ---------------------------------------------------------------- tracking
  void touch() => _lastTouch = DateTime.now();

  void start() => WidgetsBinding.instance.addObserver(this);

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (_foreground && me != null) ping();
  }

  void _startTracking() {
    _timer?.cancel();
    ping().then((_) => refreshPresence());
    _timer = Timer.periodic(const Duration(seconds: 30), (_) async {
      await ping();
      await refreshPresence();
    });
  }

  Future<void> ping() async {
    if (me == null) return;
    final active = _foreground && DateTime.now().difference(_lastTouch).inSeconds < 60;
    try {
      await supabase.rpc('admin_ping', params: {'p_active': active, 'p_page': page});
    } catch (_) {
      if (!trackWarned) {
        trackWarned = true;
        errors['tracking'] = 'Time tracking is off: run v2_part10_admin_tracking.sql in Supabase.';
        notifyListeners();
      }
    }
  }

  Future<void> refreshPresence() async {
    if (me == null) return;
    presence = await _fetch('admin_presence');
    notifyListeners();
  }

  void setPage(String p) {
    page = p;
    notifyListeners();
  }

  void logAction(String action, [String? detail]) {
    () async {
      try {
        await supabase.rpc('admin_log', params: {'p_action': action, 'p_detail': detail});
      } catch (_) {}
    }();
  }

  // ---------------------------------------------------------------- changes
  /// Runs a database change, logs it, reloads. Returns an error message or null.
  Future<String?> _run(Future<dynamic> Function() change, String action, [String? detail]) async {
    try {
      await change();
    } on PostgrestException catch (e) {
      return e.message;
    } catch (e) {
      return '$e';
    }
    logAction(action, detail);
    await loadAll(silent: true);
    return null;
  }

  Future<String?> setApproved(String id, bool on) => _run(
      () => supabase.from('profiles').update({'approved': on}).eq('id', id),
      on ? 'Approved technician' : 'Suspended technician',
      nameOf(id));

  Future<String?> sosSet(String id, String status) {
    final who = nameOf(sos.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{})['technician_id']);
    return _run(
        () => supabase.from('sos_alerts').update({
              'status': status,
              'resolved_at': status == 'resolved' ? DateTime.now().toUtc().toIso8601String() : null,
            }).eq('id', id),
        'SOS $status',
        who);
  }

  Future<String?> payQuick(String id) => _run(
      () => supabase.from('technician_payments').update({'status': 'paid'}).eq('id', id),
      'Marked payment paid',
      payLabel(id));

  Future<String?> paySave(String id, Map<String, dynamic> patch) => _run(
      () => supabase.from('technician_payments').update(patch).eq('id', id),
      'Edited payment -> ${patch['status']}',
      payLabel(id));

  List<Rec> get bookingsWithoutPayment => bookings
      .where((b) =>
          b['status'] == 'completed' &&
          b['technician_id'] != null &&
          !payments.any((p) => p['booking_id'] == b['id']))
      .toList();

  Future<String?> createMissingPayments() {
    final rows = bookingsWithoutPayment
        .map((b) => <String, dynamic>{
              'booking_id': b['id'],
              'technician_id': b['technician_id'],
              'amount': numOf(b['price']),
            })
        .toList();
    if (rows.isEmpty) return Future.value(null);
    return _run(() => supabase.from('technician_payments').insert(rows),
        'Created missing payments', '${rows.length} rows');
  }

  Future<String?> bookingSetPrice(String id, num price) => _run(
      () => supabase.from('bookings').update({'price': price}).eq('id', id),
      'Set booking price',
      'Booking ${id.substring(0, 8)} = $price');

  Future<String?> bookingCancel(String id) => _run(
      () => supabase.from('bookings').update({'status': 'cancelled'}).eq('id', id),
      'Cancelled booking',
      'Booking ${id.substring(0, 8)}');

  Future<String?> serviceSave(String id, Map<String, dynamic> patch) => _run(
      () => supabase.from('services').update(patch).eq('id', id),
      'Edited service',
      '${patch['name']}');

  Future<String?> serviceCreate(String name, num base, num insp) => _run(
      () => supabase
          .from('services')
          .insert({'name': name, 'base_price': base, 'inspection_fee': insp, 'active': true}),
      'Added service',
      name);

  num get commissionPct => numOf(settings['commission_pct'] ?? 20);

  Future<String?> settingsSave(Map<String, dynamic> patch, String what) => _run(
      () => supabase
          .from('platform_settings')
          .update({...patch, 'updated_at': DateTime.now().toUtc().toIso8601String()}).eq('id', 1),
      'Changed $what',
      patch.containsKey('commission_pct') ? 'Fixeaze ${patch['commission_pct']}%' : null);

  Future<String?> dueSettle(String id) {
    final d = dues.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{});
    return _run(
        () => supabase.from('cash_dues').update({
              'settled': d['amount'],
              'status': 'settled',
              'settled_at': DateTime.now().toUtc().toIso8601String(),
            }).eq('id', id),
        'Marked cash commission received',
        '${nameOf(d['technician_id'])} ${d['amount']}');
  }

  Future<String?> promoSave(String? id, Map<String, dynamic> data) {
    final what = '${data['kind'] == 'ad' ? 'advertisement' : 'banner'} "${data['title']}"';
    if (id == null) {
      return _run(() => supabase.from('promos').insert(data), 'Added $what');
    }
    return _run(() => supabase.from('promos').update(data).eq('id', id), 'Edited $what');
  }

  Future<String?> promoDelete(String id, String title) =>
      _run(() => supabase.from('promos').delete().eq('id', id), 'Deleted promo', title);

  Future<String?> signedUrl(String path) async {
    try {
      return await supabase.storage.from('kyc').createSignedUrl(path, 900);
    } catch (_) {
      return null;
    }
  }
}
