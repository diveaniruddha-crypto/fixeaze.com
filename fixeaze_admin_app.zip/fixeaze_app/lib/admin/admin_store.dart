import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import 'admin_util.dart';
import 'push_service.dart';

/// Everything the admin dashboard knows, loaded once and shared by all pages.
class AdminStore extends ChangeNotifier with WidgetsBindingObserver {
  AdminStore._();
  static final AdminStore I = AdminStore._();

  // ---- session ----
  Rec? me;
  bool booting = true;
  bool loaded = false;
  bool loading = false;
  bool _pushChecked = false;
  String page = 'overview';

  // ---- data ----
  List<Rec> profiles = [];
  List<Rec> tprof = [];
  List<Rec> kyc = [];
  List<Rec> tsvc = [];
  List<Rec> services = [];
  List<Rec> bookings = [];
  List<Rec> payments = [];
  List<Rec> sos = [];
  List<Rec> reviews = [];
  List<Rec> activity = [];
  List<Rec> presence = [];
  List<Rec> actions = [];
  List<Rec> dues = [];
  List<Rec> promos = [];
  List<Rec> schedule = [];
  List<Rec> tickets = [];
  List<Rec> contacts = [];
  List<Rec> calls = [];
  List<Rec> departed = [];
  List<Rec> payouts = [];
  List<Rec> institutions = [];
  List<Rec> cancellations = [];
  List<Rec> custReviews = [];
  Rec settings = {};

  // ---- chats (group, admin-to-admin, technician support) ----
  List<Rec> adminChat = [];
  List<Rec> techChat = [];
  Map<String, DateTime> reads = {};
  List<Rec> allReads = [];
  String? chatError;
  String? openChatKey; // conversation currently on screen
  Timer? _chatTimer;
  final DateTime _chatStart = DateTime.now();
  final Set<String> _chatSeen = {};
  bool _chatPrimed = false;
  void Function(String title, String body)? onIncoming;
  Map<String, String> errors = {};

  Map<String, Rec> P = {};
  Map<String, Rec> TP = {};
  Map<String, Rec> KYC = {};
  Map<String, Rec> SVC = {};

  // ---- tracking ----
  Timer? _timer;
  DateTime _lastTouch = DateTime.now();
  bool _foreground = true;
  bool trackWarned = false;
  StreamSubscription<List<Map<String, dynamic>>>? _sosSub;
  Set<String>? _knownSos;
  Rec? sosBanner;

  // ---------------------------------------------------------------- getters
  List<Rec> get admins => profiles.where((p) => p['role'] == 'admin').toList();
  List<Rec> get pendingTechs =>
      profiles.where((p) => p['role'] == 'technician' && p['approved'] != true).toList();
  List<Rec> get openSos => sos.where((s) => s['status'] == 'open').toList();
  int get duePayments =>
      payments.where((p) => p['status'] == 'pending' || p['status'] == 'processing').length;

  String nameOf(dynamic id, [String fallback = '-']) {
    final p = P['$id'];
    final n = p == null ? null : p['name'];
    return (n == null || '$n'.trim().isEmpty) ? fallback : '$n';
  }

  String svcName(dynamic id) {
    final s = SVC['$id'];
    return s == null ? 'Other' : '${s['name'] ?? 'Service'}';
  }

  List<String> techServices(String id) => tsvc
      .where((x) => x['technician_id'] == id)
      .map((x) => SVC['${x['service_id']}']?['name'])
      .where((n) => n != null)
      .map((n) => '$n')
      .toList();

  Rec? presenceOf(String id) {
    for (final p in presence) {
      if (p['admin_id'] == id) return p;
    }
    return null;
  }

  bool isOnline(String id) {
    if (me != null && me!['id'] == id) return true;
    final p = presenceOf(id);
    if (p == null) return false;
    final t = parseTime(p['last_seen']);
    return t != null && DateTime.now().difference(t).inSeconds < 100;
  }

  String payLabel(String id) {
    final p = payments.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{});
    return '${nameOf(p['technician_id'], 'technician')} ${p['amount'] ?? ''}';
  }

  // ---------------------------------------------------------------- loading
  Future<List<Rec>> _fetch(String table, {String? orderBy, bool asc = true, int? limit}) async {
    try {
      dynamic q = supabase.from(table).select('*');
      if (orderBy != null) q = q.order(orderBy, ascending: asc);
      if (limit != null) q = q.limit(limit);
      final data = await q;
      return (data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      errors[table] = e is PostgrestException ? e.message : '$e';
      return <Rec>[];
    }
  }

  /// Reads every row (the server hands out 1000 at a time).
  Future<List<Rec>> _fetchAll(String table) async {
    final out = <Rec>[];
    try {
      for (var from = 0; from < 100000; from += 1000) {
        final data = await supabase
            .from(table)
            .select('*')
            .order('created_at', ascending: false)
            .order('id')
            .range(from, from + 999);
        final l = (data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
        out.addAll(l);
        if (l.length < 1000) break;
      }
    } catch (e) {
      errors[table] = e is PostgrestException ? e.message : '$e';
    }
    return out;
  }

  Future<void> loadAll({bool silent = false}) async {
    if (loading) return;
    loading = true;
    if (!silent) notifyListeners();
    errors = {};
    final r = await Future.wait<List<Rec>>([
      _fetch('profiles'),
      _fetch('technician_profiles'),
      _fetch('technician_kyc'),
      _fetch('technician_services'),
      _fetch('services', orderBy: 'name'),
      _fetch('bookings', orderBy: 'scheduled_at', asc: false, limit: 2000),
      _fetch('technician_payments', orderBy: 'created_at', asc: false),
      _fetch('sos_alerts', orderBy: 'created_at', asc: false),
      _fetch('reviews'),
      _fetch('admin_activity', orderBy: 'day', asc: false, limit: 3000),
      _fetch('admin_presence'),
      _fetch('admin_actions', orderBy: 'created_at', asc: false, limit: 1500),
      _fetch('cash_dues', orderBy: 'created_at', asc: false),
      _fetch('platform_settings'),
      _fetch('promos', orderBy: 'created_at', asc: false),
      _fetch('technician_schedule'),
      _fetch('support_tickets', orderBy: 'updated_at', asc: false, limit: 1000),
      _fetchAll('contacts'),
      _fetchAll('contact_calls'),
      _fetchAll('departed_users'),
      _fetchAll('technician_payouts'),
      _fetchAll('institutions'),
      _fetchAll('cancellations'),
      _fetchAll('customer_reviews'),
    ]);
    profiles = r[0];
    tprof = r[1];
    kyc = r[2];
    tsvc = r[3];
    services = r[4];
    bookings = r[5];
    payments = r[6];
    sos = r[7];
    reviews = r[8];
    activity = r[9];
    presence = r[10];
    actions = r[11];
    dues = r[12];
    settings = r[13].isEmpty ? <String, dynamic>{} : r[13].first;
    promos = r[14];
    schedule = r[15];
    tickets = r[16];
    contacts = r[17];
    calls = r[18];
    departed = r[19];
    payouts = r[20];
    institutions = r[21];
    cancellations = r[22];
    custReviews = r[23];
    P = {for (final x in profiles) '${x['id']}': x};
    TP = {for (final x in tprof) '${x['id']}': x};
    KYC = {for (final x in kyc) '${x['id']}': x};
    SVC = {for (final x in services) '${x['id']}': x};
    loaded = true;
    loading = false;
    if (!_pushChecked) {
      _pushChecked = true;
      PushService.refreshIfGranted();
    }
    _updateTitle();
    notifyListeners();
  }

  void _updateTitle() {
    final n = openSos.length;
    try {
      SystemChrome.setApplicationSwitcherDescription(ApplicationSwitcherDescription(
        label: n > 0 ? '($n SOS) Fixeaze Admin' : 'Fixeaze Admin',
        primaryColor: 0xFF00796B,
      ));
    } catch (_) {}
  }

  // ---------------------------------------------------------------- auth
  Future<void> restore() async {
    try {
      final s = supabase.auth.currentSession;
      if (s != null) await _enter(s.user.id, s.user.email);
    } catch (_) {
      // Not an admin or session expired: show the login screen.
    }
    booting = false;
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async {
    final res = await supabase.auth.signInWithPassword(email: email.trim(), password: password);
    final u = res.user;
    if (u == null) throw 'Could not sign in.';
    await _enter(u.id, u.email);
    notifyListeners();
  }

  Future<void> _enter(String uid, String? email) async {
    final row = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (row == null || row['role'] != 'admin') {
      await supabase.auth.signOut();
      throw 'This account is not an admin account.';
    }
    me = Map<String, dynamic>.from(row);
    await loadAll(silent: true);
    _watchSos();
    _startTracking();
  }

  Future<void> signOut() async {
    _timer?.cancel();
    _chatTimer?.cancel();
    _sosSub?.cancel();
    _sosSub = null;
    _knownSos = null;
    try {
      await supabase.rpc('admin_offline');
    } catch (_) {}
    await supabase.auth.signOut();
    me = null;
    loaded = false;
    sosBanner = null;
    notifyListeners();
  }

  // ---------------------------------------------------------------- live SOS
  void _watchSos() {
    _sosSub?.cancel();
    _knownSos = null;
    try {
      _sosSub = supabase.from('sos_alerts').stream(primaryKey: ['id']).listen((rows) {
        final list = rows.map((e) => Map<String, dynamic>.from(e)).toList()
          ..sort((a, b) => '${b['created_at']}'.compareTo('${a['created_at']}'));
        final ids = list.map((e) => '${e['id']}').toSet();
        final known = _knownSos;
        if (known != null) {
          for (final a in list) {
            if (a['status'] == 'open' && !known.contains('${a['id']}')) {
              sosBanner = a;
            }
          }
        }
        _knownSos = ids;
        sos = list;
        _updateTitle();
        notifyListeners();
      }, onError: (_) {});
    } catch (_) {}
  }

  void dismissSosBanner() {
    sosBanner = null;
    notifyListeners();
  }

  // ---------------------------------------------------------------- tracking
  void touch() => _lastTouch = DateTime.now();

  void start() => WidgetsBinding.instance.addObserver(this);

  // ---------------------------------------------------------------- chats
  String get meId => supabase.auth.currentUser?.id ?? '';

  String? avatarOf(dynamic id) {
    final u = P['$id']?['avatar_url'];
    return (u == null || '$u'.trim().isEmpty) ? null : '$u';
  }

  /// Conversation key of an admin_chat row: 'group' or the other admin's id.
  String adminKey(Rec m) {
    if (m['to_user'] == null) return 'group';
    return '${m['sender_id']}' == meId ? '${m['to_user']}' : '${m['sender_id']}';
  }

  String techKey(Rec m) => 't:${m['technician_id']}';

  /// Messages of one conversation, oldest first.
  List<Rec> messagesOf(String key) => key.startsWith('t:')
      ? techChat.where((m) => techKey(m) == key).toList()
      : adminChat.where((m) => adminKey(m) == key).toList();

  Iterable<MapEntry<String, Rec>> get _allChatMsgs sync* {
    for (final m in adminChat) {
      yield MapEntry(adminKey(m), m);
    }
    for (final m in techChat) {
      yield MapEntry(techKey(m), m);
    }
  }

  DateTime _readAt(String key) => reads[key] ?? _chatStart;

  int unreadFor(String key) {
    final since = _readAt(key);
    return messagesOf(key)
        .where((m) => '${m['sender_id']}' != meId && (parseTime(m['created_at'])?.isAfter(since) ?? false))
        .length;
  }

  int get chatUnread {
    final since = <String, DateTime>{};
    var n = 0;
    for (final e in _allChatMsgs) {
      final m = e.value;
      if ('${m['sender_id']}' == meId) continue;
      final at = parseTime(m['created_at']);
      if (at == null) continue;
      final r = since.putIfAbsent(e.key, () => _readAt(e.key));
      if (at.isAfter(r)) n++;
    }
    return n;
  }

  Future<void> loadChats() async {
    if (me == null) return;
    try {
      final a = await supabase.from('admin_chat').select().order('created_at', ascending: false).limit(500);
      final t = await supabase.from('tech_chat').select().order('created_at', ascending: false).limit(800);
      final r = await supabase.from('chat_reads').select();
      allReads = (r as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      adminChat = (a as List).map((e) => Map<String, dynamic>.from(e as Map)).toList().reversed.toList();
      techChat = (t as List).map((e) => Map<String, dynamic>.from(e as Map)).toList().reversed.toList();
      reads = {
        for (final x in allReads)
          if ('${x['user_id']}' == meId) '${x['thread']}': parseTime(x['read_at']) ?? _chatStart,
      };
      chatError = null;
    } catch (e) {
      chatError = e is PostgrestException ? e.message : '$e';
      notifyListeners();
      return;
    }
    // tell the admin about brand-new messages from other people
    final fresh = <MapEntry<String, Rec>>[];
    for (final e in _allChatMsgs) {
      final id = '${e.value['id']}';
      if (_chatSeen.add(id) && _chatPrimed && '${e.value['sender_id']}' != meId) fresh.add(e);
    }
    _chatPrimed = true;
    _markDelivered();
    for (final e in fresh) {
      if (openChatKey == e.key) continue;
      final who = e.key.startsWith('t:') ? nameOf(e.value['sender_id'], 'Technician') : nameOf(e.value['sender_id'], 'Admin');
      final label = e.key == 'group' ? '$who (group)' : (e.key.startsWith('t:') ? '$who (support)' : who);
      onIncoming?.call(label, '${e.value['body']}');
    }
    notifyListeners();
  }

  /// Tell the senders that their messages reached this admin ("delivered").
  Future<void> _markDelivered() async {
    final latest = <String, DateTime>{};
    for (final e in _allChatMsgs) {
      if ('${e.value['sender_id']}' == meId) continue;
      final at = parseTime(e.value['created_at']);
      if (at == null) continue;
      final cur = latest[e.key];
      if (cur == null || at.isAfter(cur)) latest[e.key] = at;
    }
    final rows = <Map<String, dynamic>>[];
    latest.forEach((key, at) {
      Rec? mine;
      for (final r in allReads) {
        if ('${r['user_id']}' == meId && '${r['thread']}' == key) mine = r;
      }
      final d = mine == null ? null : parseTime(mine['delivered_at']);
      if (d == null || d.isBefore(at)) {
        rows.add({'user_id': meId, 'thread': key, 'delivered_at': DateTime.now().toUtc().toIso8601String()});
      }
    });
    if (rows.isEmpty) return;
    try {
      await supabase.from('chat_reads').upsert(rows);
    } catch (_) {}
  }

  /// 'sent', 'delivered' or 'seen' for a message I sent.
  String msgStatus(String key, Rec m) {
    final at = parseTime(m['created_at']);
    if (at == null) return 'sent';
    Iterable<Rec> rows;
    if (key == 'group') {
      rows = allReads.where((r) => '${r['thread']}' == 'group' && '${r['user_id']}' != meId);
    } else if (key.startsWith('t:')) {
      rows = allReads.where((r) => '${r['thread']}' == key && '${r['user_id']}' == key.substring(2));
    } else {
      rows = allReads.where((r) => '${r['thread']}' == meId && '${r['user_id']}' == key);
    }
    var seen = false, del = false;
    for (final r in rows) {
      final rt = parseTime(r['read_at']);
      final dt = parseTime(r['delivered_at']);
      if (rt != null && !rt.isBefore(at)) seen = true;
      if (dt != null && !dt.isBefore(at)) del = true;
    }
    return seen ? 'seen' : (del ? 'delivered' : 'sent');
  }

  Future<void> markRead(String key) async {
    reads[key] = DateTime.now();
    notifyListeners();
    try {
      await supabase.from('chat_reads').upsert({
        'user_id': meId,
        'thread': key,
        'read_at': DateTime.now().toUtc().toIso8601String(),
      });
    } catch (_) {}
  }

  Future<String?> chatSend(String key, String body, {String? mediaUrl, String? mediaType, String? mediaName}) async {
    final media = <String, dynamic>{
      if (mediaUrl != null) 'media_url': mediaUrl,
      if (mediaType != null) 'media_type': mediaType,
      if (mediaName != null) 'media_name': mediaName,
    };
    try {
      if (key.startsWith('t:')) {
        await supabase.from('tech_chat').insert({
          'technician_id': key.substring(2),
          'sender_id': meId,
          'sender_role': 'admin',
          'body': body,
          ...media,
        });
      } else {
        await supabase.from('admin_chat').insert({
          'sender_id': meId,
          'body': body,
          'to_user': key == 'group' ? null : key,
          ...media,
        });
      }
      await loadChats();
      return null;
    } catch (e) {
      return e is PostgrestException ? e.message : '$e';
    }
  }

  String statusOf(dynamic id) => '${P['$id']?['status_text'] ?? ''}'.trim();

  Future<String?> setStatus(String text) async {
    try {
      await supabase.rpc('set_my_status', params: {'p_status': text});
      await loadAll(silent: true);
      return null;
    } catch (e) {
      return e is PostgrestException ? e.message : '$e';
    }
  }

  Future<String?> setAvatar(String url) async {
    try {
      await supabase.rpc('set_my_avatar', params: {'p_url': url});
      await loadAll(silent: true);
      return null;
    } catch (e) {
      return e is PostgrestException ? e.message : '$e';
    }
  }


  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (_foreground && me != null) ping();
  }

  void _startTracking() {
    _timer?.cancel();
    ping().then((_) => refreshPresence());
    _chatTimer?.cancel();
    loadChats();
    _chatTimer = Timer.periodic(const Duration(seconds: 5), (_) => loadChats());
    _timer = Timer.periodic(const Duration(seconds: 30), (_) async {
      await ping();
      await refreshPresence();
    });
  }

  Future<void> ping() async {
    if (me == null) return;
    final active = _foreground && DateTime.now().difference(_lastTouch).inSeconds < 60;
    try {
      await supabase.rpc('admin_ping', params: {'p_active': active, 'p_page': page});
    } catch (_) {
      if (!trackWarned) {
        trackWarned = true;
        errors['tracking'] = 'Time tracking is off: run v2_part10_admin_tracking.sql in Supabase.';
        notifyListeners();
      }
    }
  }

  Future<void> refreshPresence() async {
    if (me == null) return;
    presence = await _fetch('admin_presence');
    notifyListeners();
  }

  void setPage(String p) {
    page = p;
    notifyListeners();
  }

  void logAction(String action, [String? detail]) {
    () async {
      try {
        await supabase.rpc('admin_log', params: {'p_action': action, 'p_detail': detail});
      } catch (_) {}
    }();
  }

  // ---------------------------------------------------------------- changes
  /// Runs a database change, logs it, reloads. Returns an error message or null.
  Future<String?> _run(Future<dynamic> Function() change, String action, [String? detail]) async {
    try {
      await change();
    } on PostgrestException catch (e) {
      return e.message;
    } catch (e) {
      return '$e';
    }
    logAction(action, detail);
    await loadAll(silent: true);
    return null;
  }

  Future<String?> setApproved(String id, bool on) => _run(
      () => supabase.from('profiles').update({'approved': on}).eq('id', id),
      on ? 'Approved technician' : 'Suspended technician',
      nameOf(id));

  Future<String?> sosSet(String id, String status) {
    final who = nameOf(sos.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{})['technician_id']);
    return _run(
        () => supabase.from('sos_alerts').update({
              'status': status,
              'resolved_at': status == 'resolved' ? DateTime.now().toUtc().toIso8601String() : null,
            }).eq('id', id),
        'SOS $status',
        who);
  }

  Future<String?> payQuick(String id) => _run(
      () => supabase.from('technician_payments').update({'status': 'paid'}).eq('id', id),
      'Marked payment paid',
      payLabel(id));

  Future<String?> paySave(String id, Map<String, dynamic> patch) => _run(
      () => supabase.from('technician_payments').update(patch).eq('id', id),
      'Edited payment -> ${patch['status']}',
      payLabel(id));

  List<Rec> get bookingsWithoutPayment => bookings
      .where((b) =>
          b['status'] == 'completed' &&
          b['technician_id'] != null &&
          !payments.any((p) => p['booking_id'] == b['id']))
      .toList();

  Future<String?> createMissingPayments() {
    final rows = bookingsWithoutPayment
        .map((b) => <String, dynamic>{
              'booking_id': b['id'],
              'technician_id': b['technician_id'],
              'amount': numOf(b['price']),
            })
        .toList();
    if (rows.isEmpty) return Future.value(null);
    return _run(() => supabase.from('technician_payments').insert(rows),
        'Created missing payments', '${rows.length} rows');
  }

  Future<String?> bookingSetPrice(String id, num price) => _run(
      () => supabase.from('bookings').update({'price': price}).eq('id', id),
      'Set booking price',
      'Booking ${id.substring(0, 8)} = $price');

  Future<String?> bookingCancel(String id) => _run(
      () => supabase.from('bookings').update({'status': 'cancelled'}).eq('id', id),
      'Cancelled booking',
      'Booking ${id.substring(0, 8)}');

  Future<String?> serviceSave(String id, Map<String, dynamic> patch) => _run(
      () => supabase.from('services').update(patch).eq('id', id),
      'Edited service',
      '${patch['name']}');

  Future<String?> serviceCreate(String name, num base, num insp) => _run(
      () => supabase
          .from('services')
          .insert({'name': name, 'base_price': base, 'inspection_fee': insp, 'active': true}),
      'Added service',
      name);

  num get commissionPct => numOf(settings['commission_pct'] ?? 20);

  Future<String?> settingsSave(Map<String, dynamic> patch, String what) => _run(
      () => supabase
          .from('platform_settings')
          .update({...patch, 'updated_at': DateTime.now().toUtc().toIso8601String()}).eq('id', 1),
      'Changed $what',
      patch.containsKey('commission_pct') ? 'Fixeaze ${patch['commission_pct']}%' : null);

  Future<String?> dueSettle(String id) {
    final d = dues.firstWhere((x) => x['id'] == id, orElse: () => <String, dynamic>{});
    return _run(
        () => supabase.from('cash_dues').update({
              'settled': d['amount'],
              'status': 'settled',
              'settled_at': DateTime.now().toUtc().toIso8601String(),
            }).eq('id', id),
        'Marked cash commission received',
        '${nameOf(d['technician_id'])} ${d['amount']}');
  }

  Future<String?> assignBooking(String bookingId, String techId, String note) => _run(
      () => supabase.rpc('admin_assign_booking',
          params: {'p_booking': bookingId, 'p_technician': techId, 'p_note': note}),
      'Assigned booking to technician',
      nameOf(techId));

  Future<String?> ticketReply(String ticketId, String body) => _run(
      () => supabase.from('support_messages').insert({
            'ticket_id': ticketId,
            'sender_id': supabase.auth.currentUser!.id,
            'sender_role': 'admin',
            'body': body,
          }),
      'Replied to support ticket',
      ticketId);

  Future<String?> ticketStatus(String ticketId, String status) => _run(
      () => supabase.from('support_tickets').update({'status': status}).eq('id', ticketId),
      status == 'closed' ? 'Closed support ticket' : 'Reopened support ticket',
      ticketId);

  int get openTickets => tickets.where((t) => t['status'] == 'open').length;

  Future<String?> contactsAdd(List<Map<String, dynamic>> rows) => _run(() async {
        final uid = supabase.auth.currentUser!.id;
        final data = [for (final r in rows) {...r, 'added_by': uid}];
        for (var i = 0; i < data.length; i += 200) {
          await supabase.from('contacts').insert(data.sublist(i, i + 200 > data.length ? data.length : i + 200));
        }
      }, 'Added contacts', '${rows.length} contact(s)');

  Future<String?> contactDelete(String id, String label) =>
      _run(() => supabase.from('contacts').delete().eq('id', id), 'Deleted contact', label);

  Future<String?> callLog(String id, String outcome, String note, String label) => _run(
      () => supabase.rpc('contact_log_call', params: {'p_contact': id, 'p_outcome': outcome, 'p_note': note}),
      outcome == 'note' ? 'Added contact note' : 'Logged call: $outcome',
      label);

  /// The institution this account owns, or null.
  Rec? institutionOfOwner(dynamic ownerId) {
    for (final i in institutions) {
      if ('${i['owner_id']}' == '$ownerId') return i;
    }
    return null;
  }

  /// Who is paid for this technician's jobs: the institution owner, or the technician.
  String payeeOf(dynamic techId) {
    final inst = TP['$techId']?['institution_id'];
    if (inst != null) {
      for (final i in institutions) {
        if ('${i['id']}' == '$inst') return '${i['owner_id']}';
      }
    }
    return '$techId';
  }

  /// Display name of a payee (institution name for owners).
  String payeeName(dynamic id) {
    final inst = institutionOfOwner(id);
    return inst != null ? '${inst['name']}' : nameOf(id);
  }

  /// Technicians whose average rating is below 3 (and not already blocked).
  List<Rec> get lowRated => tprof.where((t) {
        final r = numOf(t['rating']);
        if (r <= 0 || r >= 3) return false;
        final bu = parseTime(P['${t['id']}']?['blocked_until']);
        return bu == null || bu.isBefore(DateTime.now());
      }).toList();

  Future<String?> reverseReview(String kind, String id, bool reverse, String note) => _run(
      () => supabase.rpc('admin_reverse_review',
          params: {'p_kind': kind, 'p_id': id, 'p_reverse': reverse, 'p_note': note}),
      reverse ? 'Reversed a $kind rating' : 'Restored a $kind rating');

  Future<String?> blockUser(String id, int days, String reason) => _run(
      () => supabase.rpc('admin_block_user', params: {'p_user': id, 'p_days': days, 'p_reason': reason}),
      days <= 0 ? 'Unblocked' : 'Blocked for $days days',
      nameOf(id));

  Future<String?> institutionStatus(String id, String status) => _run(
      () => supabase.rpc('admin_set_institution_status', params: {'p_institution': id, 'p_status': status}),
      'Institution -> $status',
      institutions.where((i) => '${i['id']}' == id).map((i) => '${i['name']}').join());

  Future<String?> salarySchedule(String? techId, DateTime from, DateTime to, DateTime payOn) => _run(
      () => supabase.rpc('admin_schedule_payout', params: {
            'p_technician': techId,
            'p_from': from.toUtc().toIso8601String(),
            'p_to': to.toUtc().toIso8601String(),
            'p_pay_on': payOn.toIso8601String().substring(0, 10),
          }),
      'Set payout date ${payOn.toIso8601String().substring(0, 10)}',
      techId == null ? 'all technicians' : payeeName(techId));

  Future<String?> salaryPay(String techId, DateTime from, DateTime to, String ref, String note) => _run(
      () => supabase.rpc('admin_pay_period', params: {
            'p_technician': techId,
            'p_from': from.toUtc().toIso8601String(),
            'p_to': to.toUtc().toIso8601String(),
            'p_reference': ref,
            'p_note': note,
          }),
      'Paid salary',
      payeeName(techId));

  Future<String?> bankSave(String payeeId, Map<String, dynamic> patch) => _run(
      () => institutionOfOwner(payeeId) != null
          ? supabase.from('institutions').update(patch).eq('owner_id', payeeId)
          : supabase.from('technician_kyc').update(patch).eq('id', payeeId),
      'Edited bank details',
      payeeName(payeeId));

  Future<String?> sendNote(String bookingId, String toRole, String body) => _run(
      () => supabase.rpc('admin_send_note',
          params: {'p_booking': bookingId, 'p_to_role': toRole, 'p_body': body}),
      'Sent note to $toRole',
      body);

  Future<String?> promoSave(String? id, Map<String, dynamic> data) {
    final what = '${data['kind'] == 'ad' ? 'advertisement' : 'banner'} "${data['title']}"';
    if (id == null) {
      return _run(() => supabase.from('promos').insert(data), 'Added $what');
    }
    return _run(() => supabase.from('promos').update(data).eq('id', id), 'Edited $what');
  }

  Future<String?> promoDelete(String id, String title) =>
      _run(() => supabase.from('promos').delete().eq('id', id), 'Deleted promo', title);

  Future<String?> signedUrl(String path) async {
    try {
      return await supabase.storage.from('kyc').createSignedUrl(path, 900);
    } catch (_) {
      return null;
    }
  }
}
