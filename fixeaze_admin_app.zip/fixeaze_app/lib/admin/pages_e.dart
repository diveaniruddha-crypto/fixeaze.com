import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

const int _deadlineMin = 30;

// ============================================================== availability helpers

class _Avail {
  final String label;
  final Color color;
  final bool free;
  const _Avail(this.label, this.color, this.free);
}

double? _km(double? a, double? b, double? c, double? d) {
  if (a == null || b == null || c == null || d == null) return null;
  const r = 6371.0;
  double rad(double x) => x * math.pi / 180;
  final dLat = rad(c - a);
  final dLng = rad(d - b);
  final h = math.pow(math.sin(dLat / 2), 2) +
      math.cos(rad(a)) * math.cos(rad(c)) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(h.toDouble()));
}

double? _dbl(dynamic v) => v == null ? null : double.tryParse('$v');

int? _mins(dynamic t) {
  if (t == null) return null;
  final p = '$t'.split(':');
  if (p.length < 2) return null;
  final h = int.tryParse(p[0]);
  final m = int.tryParse(p[1]);
  if (h == null || m == null) return null;
  return h * 60 + m;
}

bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

bool _activeJob(Rec b) {
  final st = '${b['status']}';
  return st == 'accepted' || st == 'in_progress';
}

/// Is this technician free at [when]? Ignores booking [ignoreId] itself.
_Avail _availability(String techId, DateTime when, {double hours = 2, String? ignoreId}) {
  final tp = _s.TP[techId] ?? <String, dynamic>{};
  if (tp['paused'] == true) return const _Avail('Paused', kWarn, false);

  Rec? day;
  for (final x in _s.schedule) {
    final d = parseTime(x['day']);
    if (x['technician_id'] == techId && d != null && _sameDay(d, when)) {
      day = x;
      break;
    }
  }
  if (day != null && day['kind'] == 'leave') return const _Avail('On leave', kBad, false);

  final start = _mins(day != null && day['kind'] == 'shift' ? day['shift_start'] : tp['shift_start']);
  final end = _mins(day != null && day['kind'] == 'shift' ? day['shift_end'] : tp['shift_end']);
  final at = when.hour * 60 + when.minute;
  if (start != null && end != null && (at < start || at >= end)) {
    return const _Avail('Off shift', kWarn, false);
  }

  final endWhen = when.add(Duration(minutes: (hours * 60).round()));
  for (final o in _s.bookings) {
    if (o['technician_id'] != techId || '${o['id']}' == ignoreId || !_activeJob(o)) continue;
    final os = parseTime(o['scheduled_at'])?.toLocal();
    if (os == null) continue;
    final oh = numOf(o['hours']) > 0 ? numOf(o['hours']).toDouble() : 2.0;
    final oe = os.add(Duration(minutes: (oh * 60).round()));
    if (when.isBefore(oe) && os.isBefore(endWhen)) return const _Avail('Busy', kBad, false);
  }
  return const _Avail('Free', kOk, true);
}

// ============================================================== DISPATCH PAGE

class DispatchPage extends StatefulWidget {
  const DispatchPage({super.key});
  @override
  State<DispatchPage> createState() => _DispatchPageState();
}

class _DispatchPageState extends State<DispatchPage> {
  Timer? _tick;
  int _n = 0;
  String _svcFilter = '';

  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
    _tick = Timer.periodic(const Duration(seconds: 30), (_) {
      _n++;
      if (_n % 2 == 0) _s.loadAll(silent: true);
      if (mounted) setState(() {});
    });
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _tick?.cancel();
    _s.removeListener(_changed);
    super.dispose();
  }

  DateTime _received(Rec b) => (parseTime(b['created_at']) ?? DateTime.now()).toLocal();

  int _waitMin(Rec b) => DateTime.now().difference(_received(b)).inMinutes;

  String _techNames(Rec b) => _s.nameOf(b['technician_id']);

  Future<void> _assign(Rec b) async {
    await showDialog<void>(context: context, builder: (_) => _AssignDialog(booking: b));
  }

  Future<void> _note(Rec b) async {
    await showDialog<void>(context: context, builder: (_) => _NoteDialog(booking: b));
  }

  Widget _booked(Rec b) {
    final id = b['preferred_technician_id'];
    if (id == null) return const Text('Any available');
    final m = _waitMin(b);
    return TwoLine(s_nameOf(id), m >= 30 ? 'Open to all now' : 'Reserved, ${30 - m} min left');
  }

  String s_nameOf(dynamic id) => _s.nameOf(id);

  Widget _waitPill(Rec b) {
    final m = _waitMin(b);
    if (m >= _deadlineMin) return Pill('OTC: ${m - _deadlineMin} min over', kBad);
    return Pill('${_deadlineMin - m} min left', m >= 20 ? kWarn : kInfo);
  }

  String _dur(Duration d) {
    final m = d.inMinutes;
    if (m < 1) return 'under 1 min';
    if (m < 60) return '$m min';
    return '${d.inHours} h ${m % 60} min';
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final waiting = s.bookings
        .where((b) => b['status'] == 'pending' && b['technician_id'] == null)
        .toList()
      ..sort((a, b) => _received(a).compareTo(_received(b)));
    final overdue = waiting.where((b) => _waitMin(b) >= _deadlineMin).toList();

    final now = DateTime.now();
    final accepted = s.bookings.where((b) {
      final t = parseTime(b['accepted_at'])?.toLocal();
      return t != null && b['technician_id'] != null && _sameDay(t, now);
    }).toList()
      ..sort((a, b) => '${b['accepted_at']}'.compareTo('${a['accepted_at']}'));

    final recent = s.bookings.where((b) => b['technician_id'] != null && b['accepted_at'] != null).toList()
      ..sort((a, b) => '${b['accepted_at']}'.compareTo('${a['accepted_at']}'));

    final techs = s.profiles.where((p) => p['role'] == 'technician' && p['approved'] == true).toList();
    final free = <Rec>[];
    for (final t in techs) {
      final id = '${t['id']}';
      if (_svcFilter.isNotEmpty && !s.tsvc.any((x) => x['technician_id'] == id && '${x['service_id']}' == _svcFilter)) {
        continue;
      }
      free.add(t);
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['technician_schedule'] != null)
          NoticeBanner('Calendar data not loaded: ${s.errors['technician_schedule']}', color: kWarn),
        if (s.errors['bookings'] != null) NoticeBanner('${s.errors['bookings']}', color: kBad),
        TileGrid([
          StatTile('Waiting for a technician', '${waiting.length}', sub: 'No one has accepted yet'),
          StatTile('Over $_deadlineMin min (OTC)', '${overdue.length}',
              sub: 'Assign these now', alert: overdue.isNotEmpty),
          StatTile('Accepted today', '${accepted.length}'),
          StatTile('Technicians free now',
              '${techs.where((t) => _availability('${t['id']}', now).free).length}',
              sub: 'of ${techs.length} approved'),
        ]),
        const SectionTitle('Bookings waiting for a technician'),
        const Muted('If the customer picked a technician, that technician has 30 minutes to accept. '
            'After that the booking opens to every eligible technician nearby and shows as OTC, and you can assign it yourself. '
            'If the customer chose Any available, all eligible technicians in the area see it at once.'),
        const SizedBox(height: 8),
        AdminTable(
          columns: const ['Received', 'Deadline', 'Customer', 'Service', 'Booked technician', 'Job time', 'Address', 'Status', ''],
          empty: 'No booking is waiting. Everything has a technician.',
          rows: [
            for (final b in waiting)
              <Widget>[
                TwoLine(fdt(b['created_at']), ago(b['created_at'])),
                Text(ftime(_received(b).add(const Duration(minutes: _deadlineMin)))),
                TwoLine(s.nameOf(b['customer_id']), '${s.P['${b['customer_id']}']?['phone'] ?? ''}'),
                Text(s.svcName(b['service_id'])),
                _booked(b),
                Text(fdt(b['scheduled_at'])),
                SizedBox(width: 200, child: Text('${b['address'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis)),
                _waitPill(b),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size(0, 38)),
                    onPressed: () => _assign(b),
                    child: const Text('Assign'),
                  ),
                  const SizedBox(width: 6),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                    onPressed: () => _note(b),
                    child: const Text('Note'),
                  ),
                ]),
              ],
          ],
        ),
        const SectionTitle('Recently accepted'),
        AdminTable(
          columns: const ['Received', 'Accepted', 'Time to accept', 'Customer', 'Service', 'Technician', 'Status', ''],
          empty: 'No accepted bookings yet.',
          rows: [
            for (final b in recent.take(40))
              () {
                final r = _received(b);
                final a = parseTime(b['accepted_at'])?.toLocal() ?? r;
                final took = a.difference(r);
                final late = took.inMinutes >= _deadlineMin;
                return <Widget>[
                  Text(fdt(b['created_at'])),
                  Text(fdt(b['accepted_at'])),
                  late ? Pill(_dur(took), kBad) : Pill(_dur(took), kOk),
                  Text(s.nameOf(b['customer_id'])),
                  Text(s.svcName(b['service_id'])),
                  TwoLine(_techNames(b), '${s.P['${b['technician_id']}']?['phone'] ?? ''}'),
                  StatusPill('${b['status']}'),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                    onPressed: () => _note(b),
                    child: const Text('Note'),
                  ),
                ];
              }(),
          ],
        ),
        const SectionTitle('Technicians: who is available now'),
        Wrap(spacing: 10, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          const Text('Service:'),
          DropdownButton<String>(
            value: _svcFilter,
            items: [
              const DropdownMenuItem(value: '', child: Text('All services')),
              for (final v in s.services) DropdownMenuItem(value: '${v['id']}', child: Text('${v['name']}')),
            ],
            onChanged: (v) => setState(() => _svcFilter = v ?? ''),
          ),
        ]),
        const SizedBox(height: 8),
        AdminTable(
          columns: const ['Technician', 'Phone', 'Services', 'Shift', 'Today', 'Availability'],
          empty: 'No approved technicians for this service.',
          rows: [
            for (final t in free)
              () {
                final id = '${t['id']}';
                final tp = s.TP[id] ?? <String, dynamic>{};
                final av = _availability(id, now);
                final jobs = s.bookings
                    .where((b) =>
                        b['technician_id'] == id &&
                        _activeJob(b) &&
                        (parseTime(b['scheduled_at'])?.toLocal().let((d) => _sameDay(d, now)) ?? false))
                    .length;
                String sh(dynamic v) => v == null ? '' : '$v'.substring(0, math.min(5, '$v'.length));
                return <Widget>[
                  Text(s.nameOf(id)),
                  Text('${t['phone'] ?? ''}'),
                  SizedBox(width: 200, child: Text(s.techServices(id).join(', '), maxLines: 2, overflow: TextOverflow.ellipsis)),
                  Text(tp['shift_start'] == null ? '-' : '${sh(tp['shift_start'])} - ${sh(tp['shift_end'])}'),
                  Text('$jobs job${jobs == 1 ? '' : 's'}'),
                  Pill(av.label, av.color),
                ];
              }(),
          ],
        ),
      ],
    );
  }
}

extension _Let<T> on T {
  R let<R>(R Function(T) f) => f(this);
}

// ============================================================== ASSIGN DIALOG

class _AssignDialog extends StatefulWidget {
  final Rec booking;
  const _AssignDialog({required this.booking});
  @override
  State<_AssignDialog> createState() => _AssignDialogState();
}

class _AssignDialogState extends State<_AssignDialog> {
  String? _pick;
  bool _all = false;
  bool _busy = false;
  final _note = TextEditingController();

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final svc = '${b['service_id']}';
    final when = (parseTime(b['scheduled_at']) ?? DateTime.now()).toLocal();
    final hrs = numOf(b['hours']) > 0 ? numOf(b['hours']).toDouble() : 2.0;
    final bLat = _dbl(b['lat']);
    final bLng = _dbl(b['lng']);

    final rows = <Map<String, dynamic>>[];
    for (final p in _s.profiles) {
      if (p['role'] != 'technician' || p['approved'] != true) continue;
      final id = '${p['id']}';
      final offers = _s.tsvc.any((x) => x['technician_id'] == id && '${x['service_id']}' == svc);
      if (!offers && !_all) continue;
      rows.add({
        'p': p,
        'av': _availability(id, when, hours: hrs, ignoreId: '${b['id']}'),
        'km': _km(bLat, bLng, _dbl(p['lat']), _dbl(p['lng'])),
        'offers': offers,
      });
    }
    rows.sort((a, c) {
      final fa = (a['av'] as _Avail).free ? 0 : 1;
      final fc = (c['av'] as _Avail).free ? 0 : 1;
      if (fa != fc) return fa - fc;
      final ka = (a['km'] as double?) ?? 9999;
      final kc = (c['km'] as double?) ?? 9999;
      return ka.compareTo(kc);
    });

    return AlertDialog(
      title: const Text('Assign a technician'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${_s.svcName(b['service_id'])} for ${_s.nameOf(b['customer_id'])}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            Muted('Job time: ${fdt(b['scheduled_at'])}\n${b['address'] ?? ''}'),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              title: const Text('Show technicians who do not offer this service'),
              value: _all,
              onChanged: (v) => setState(() => _all = v),
            ),
            if (rows.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Muted('No technician found.')),
            for (final r in rows)
              () {
                final p = r['p'] as Rec;
                final av = r['av'] as _Avail;
                final km = r['km'] as double?;
                final id = '${p['id']}';
                return RadioListTile<String>(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  value: id,
                  groupValue: _pick,
                  onChanged: (v) => setState(() => _pick = v),
                  title: Row(children: [
                    Flexible(child: Text(_s.nameOf(id), overflow: TextOverflow.ellipsis)),
                    const SizedBox(width: 8),
                    Pill(av.label, av.color),
                  ]),
                  subtitle: Text([
                    '${p['phone'] ?? ''}',
                    if (km != null) '${km.toStringAsFixed(1)} km away',
                    if (r['offers'] != true) 'does not offer this service',
                  ].where((e) => e.isNotEmpty).join(' · ')),
                );
              }(),
            const SizedBox(height: 8),
            TextField(
              controller: _note,
              maxLines: 2,
              decoration: const InputDecoration(
                  labelText: 'Note for the technician (optional)', border: OutlineInputBorder()),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _busy || _pick == null
              ? null
              : () async {
                  final a = _availability(_pick!, when, hours: hrs, ignoreId: '${b['id']}');
                  if (!a.free) {
                    final ok = await confirmBox(
                        context, '${_s.nameOf(_pick)} is marked "${a.label}" at that time. Assign anyway?',
                        yes: 'Assign anyway');
                    if (!ok) return;
                  }
                  setState(() => _busy = true);
                  final err = await _s.assignBooking('${b['id']}', _pick!, _note.text.trim());
                  if (!mounted) return;
                  setState(() => _busy = false);
                  report(context, err, 'Assigned. The technician and customer have been told.');
                  if (err == null) Navigator.pop(context);
                },
          child: const Text('Assign'),
        ),
      ],
    );
  }
}

// ============================================================== NOTE DIALOG

class _NoteDialog extends StatefulWidget {
  final Rec booking;
  const _NoteDialog({required this.booking});
  @override
  State<_NoteDialog> createState() => _NoteDialogState();
}

class _NoteDialogState extends State<_NoteDialog> {
  String _to = 'customer';
  bool _busy = false;
  final _text = TextEditingController();

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final hasTech = b['technician_id'] != null;
    return AlertDialog(
      title: const Text('Send a note'),
      content: SizedBox(
        width: 440,
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Muted('${_s.svcName(b['service_id'])} · ${_s.nameOf(b['customer_id'])}'),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: [
              const ButtonSegment(value: 'customer', label: Text('To customer')),
              ButtonSegment(value: 'technician', label: const Text('To technician'), enabled: hasTech),
            ],
            selected: {_to},
            onSelectionChanged: (v) => setState(() => _to = v.first),
          ),
          if (!hasTech) const Padding(padding: EdgeInsets.only(top: 6), child: Muted('No technician assigned yet.')),
          const SizedBox(height: 12),
          TextField(
            controller: _text,
            maxLines: 4,
            decoration: const InputDecoration(labelText: 'Note', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 6),
          const Muted('Customers see it on their booking. Technicians see it under updates in Payments.'),
        ]),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _busy
              ? null
              : () async {
                  if (_text.text.trim().isEmpty) {
                    toast(context, 'Write a note first', error: true);
                    return;
                  }
                  setState(() => _busy = true);
                  final err = await _s.sendNote('${b['id']}', _to, _text.text.trim());
                  if (!mounted) return;
                  setState(() => _busy = false);
                  report(context, err, 'Note sent');
                  if (err == null) Navigator.pop(context);
                },
          child: const Text('Send'),
        ),
      ],
    );
  }
}

/// Is this approved technician free right now? (used by the Areas page)
bool techFreeNow(String techId) => _availability(techId, DateTime.now()).free;
