import 'dart:convert';
import 'dart:typed_data';

import '../services/file_save.dart';
import 'admin_store.dart';
import 'admin_util.dart';

String _cell(dynamic v) {
  var s = v == null ? '' : '$v';
  if (RegExp(r'^[=@]').hasMatch(s) || RegExp(r'^[+\-](?![\d\s]*$)').hasMatch(s)) {
    s = "'$s";
  }
  if (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r')) {
    s = '"${s.replaceAll('"', '""')}"';
  }
  return s;
}

/// Phone / desktop: asks where to save the CSV file. Returns the file name.
String downloadCsv(String name, List<String> headers, List<List<dynamic>> rows) {
  final text = '﻿${[headers, ...rows].map((r) => r.map(_cell).join(',')).join('\r\n')}';
  final fileName = '${name}_${dkey(DateTime.now())}.csv';
  saveBytes(fileName, Uint8List.fromList(utf8.encode(text)), 'text/csv');
  AdminStore.I.logAction('Downloaded report', '$name (${rows.length} rows)');
  return fileName;
}
