import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';
import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';
import 'pages_b.dart';
import 'pages_c.dart';
import 'pages_d.dart';

class AdminApp extends StatefulWidget {
  const AdminApp({super.key});
  @override
  State<AdminApp> createState() => _AdminAppState();
}

class _AdminAppState extends State<AdminApp> {
  bool _onKey(KeyEvent e) {
    AdminStore.I.touch();
    return false;
  }

  @override
  void initState() {
    super.initState();
    AdminStore.I.start();
    HardwareKeyboard.instance.addHandler(_onKey);
    AdminStore.I.restore();
  }

  @override
  void dispose() {
    HardwareKeyboard.instance.removeHandler(_onKey);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => AdminStore.I.touch(),
      onPointerMove: (_) => AdminStore.I.touch(),
      onPointerHover: (_) => AdminStore.I.touch(),
      onPointerSignal: (_) => AdminStore.I.touch(),
      child: MaterialApp(
        title: 'Fixeaze Admin',
        debugShowCheckedModeBanner: false,
        theme: buildTheme().copyWith(
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black87,
            elevation: 0,
            scrolledUnderElevation: 1,
          ),
        ),
        home: ListenableBuilder(
          listenable: AdminStore.I,
          builder: (context, _) {
            final s = AdminStore.I;
            if (s.booting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            if (s.me == null) return const AdminLogin();
            return const AdminShell();
          },
        ),
      ),
    );
  }
}

// ================================================================= login

class AdminLogin extends StatefulWidget {
  const AdminLogin({super.key});
  @override
  State<AdminLogin> createState() => _AdminLoginState();
}

class _AdminLoginState extends State<AdminLogin> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  bool _show = false;
  String? _err;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    if (_email.text.trim().isEmpty || _pass.text.isEmpty) {
      setState(() => _err = 'Enter your email and password.');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      await AdminStore.I.signIn(_email.text, _pass.text);
    } catch (e) {
      if (mounted) setState(() => _err = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: AutofillGroup(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(10)),
                          child: const Icon(Icons.build, color: Colors.white),
                        ),
                        const SizedBox(width: 10),
                        const Text('Fixeaze', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                      ]),
                      const SizedBox(height: 4),
                      const Center(child: Muted('Admin dashboard', size: 14)),
                      const SizedBox(height: 22),
                      TextField(
                        controller: _email,
                        keyboardType: TextInputType.emailAddress,
                        autofillHints: const [AutofillHints.email],
                        decoration: const InputDecoration(labelText: 'Email'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _pass,
                        obscureText: !_show,
                        autofillHints: const [AutofillHints.password],
                        onSubmitted: (_) => _go(),
                        decoration: InputDecoration(
                          labelText: 'Password',
                          suffixIcon: IconButton(
                            icon: Icon(_show ? Icons.visibility_off : Icons.visibility),
                            onPressed: () => setState(() => _show = !_show),
                          ),
                        ),
                      ),
                      if (_err != null) ...[
                        const SizedBox(height: 10),
                        Text(_err!, style: const TextStyle(color: kBad)),
                      ],
                      const SizedBox(height: 18),
                      FilledButton(
                        onPressed: _busy ? null : _go,
                        child: _busy
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : const Text('Sign in'),
                      ),
                      const SizedBox(height: 10),
                      const Center(child: Muted('Only accounts with role = admin can enter.')),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ================================================================= shell

class _NavItem {
  final String id;
  final String label;
  final IconData icon;
  const _NavItem(this.id, this.label, this.icon);
}

const _items = [
  _NavItem('overview', 'Overview', Icons.dashboard_outlined),
  _NavItem('approvals', 'Approvals', Icons.verified_user_outlined),
  _NavItem('sos', 'SOS alerts', Icons.emergency_outlined),
  _NavItem('payments', 'Payments', Icons.account_balance_wallet_outlined),
  _NavItem('bookings', 'Bookings', Icons.event_note_outlined),
  _NavItem('people', 'People', Icons.people_outline),
  _NavItem('services', 'Services', Icons.handyman_outlined),
  _NavItem('promos', 'Banners & ads', Icons.campaign_outlined),
  _NavItem('settings', 'Bank & commission', Icons.account_balance_outlined),
  _NavItem('team', 'Team', Icons.groups_outlined),
];

class AdminShell extends StatelessWidget {
  const AdminShell({super.key});

  void _go(BuildContext context, String id, {bool closeDrawer = false}) {
    AdminStore.I.setPage(id);
    if (closeDrawer) Navigator.pop(context);
  }

  Widget _page(String id) {
    switch (id) {
      case 'approvals':
        return ApprovalsPage(key: ValueKey('approvals'));
      case 'sos':
        return SosPage(key: ValueKey('sos'));
      case 'payments':
        return PaymentsPage(key: ValueKey('payments'));
      case 'bookings':
        return BookingsPage(key: ValueKey('bookings'));
      case 'people':
        return PeoplePage(key: ValueKey('people'));
      case 'services':
        return ServicesPage(key: ValueKey('services'));
      case 'promos':
        return PromosPage(key: ValueKey('promos'));
      case 'settings':
        return SettingsPage(key: ValueKey('settings'));
      case 'team':
        return TeamPage(key: ValueKey('team'));
      default:
        return OverviewPage(key: const ValueKey('overview'), onNav: AdminStore.I.setPage);
    }
  }

  int _badge(String id) {
    final s = AdminStore.I;
    switch (id) {
      case 'sos':
        return s.openSos.length;
      case 'approvals':
        return s.pendingTechs.length;
      case 'payments':
        return s.duePayments;
      default:
        return 0;
    }
  }

  Widget _sidebar(BuildContext context, {bool drawer = false}) {
    final s = AdminStore.I;
    final team = s.admins.toList()
      ..sort((a, b) {
        final o = (s.isOnline('${b['id']}') ? 1 : 0) - (s.isOnline('${a['id']}') ? 1 : 0);
        return o != 0 ? o : '${a['name']}'.compareTo('${b['name']}');
      });
    return Material(
      color: Colors.white,
      child: SizedBox(
      width: 250,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
              child: Row(children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(9)),
                  child: const Icon(Icons.build, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 10),
                const Text('Fixeaze', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(width: 6),
                const Muted('Admin'),
              ]),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  for (final it in _items)
                    ListTile(
                      dense: true,
                      selected: s.page == it.id,
                      selectedTileColor: kBrand.withAlpha(25),
                      selectedColor: kBrand,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      leading: Icon(it.icon),
                      title: Text(it.label, style: const TextStyle(fontWeight: FontWeight.w600)),
                      trailing: _badge(it.id) > 0
                          ? Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: it.id == 'sos' ? kBad : kWarn,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text('${_badge(it.id)}',
                                  style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                            )
                          : null,
                      onTap: () => _go(context, it.id, closeDrawer: drawer),
                    ),
                ],
              ),
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 4),
              child: Align(alignment: Alignment.centerLeft, child: const Muted('TEAM')),
            ),
            for (final a in team.take(6))
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 3),
                child: Row(children: [
                  PresenceDot(s.isOnline('${a['id']}')),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '${a['name'] ?? a['email'] ?? 'Admin'}${s.me != null && s.me!['id'] == a['id'] ? ' (you)' : ''}',
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13),
                    ),
                  ),
                  Muted(s.isOnline('${a['id']}')
                      ? 'online'
                      : (s.presenceOf('${a['id']}') == null ? 'never' : ago(s.presenceOf('${a['id']}')!['last_seen']))),
                ]),
              ),
            const SizedBox(height: 10),
            ListTile(
              dense: true,
              leading: const Icon(Icons.logout),
              title: Text('Sign out · ${s.me?['name'] ?? ''}', overflow: TextOverflow.ellipsis),
              onTap: () async {
                final ok = await confirmBox(context, 'Sign out of the admin dashboard?', yes: 'Sign out');
                if (ok) await AdminStore.I.signOut();
              },
            ),
          ],
        ),
      ),
      ),
    );
  }

  Widget _sosBanner(BuildContext context) {
    final s = AdminStore.I;
    final b = s.sosBanner;
    if (b == null) return const SizedBox.shrink();
    return Material(
      color: kBad,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            const Icon(Icons.emergency, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(
              child: Text('SOS from ${s.nameOf(b['technician_id'], 'a technician')}! Respond now.',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            TextButton(
              style: TextButton.styleFrom(foregroundColor: Colors.white),
              onPressed: () {
                s.dismissSosBanner();
                s.setPage('sos');
              },
              child: const Text('Open'),
            ),
            IconButton(
              color: Colors.white,
              onPressed: s.dismissSosBanner,
              icon: const Icon(Icons.close),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AdminStore.I,
        builder: (context, _) => _content(context),
      );

  Widget _content(BuildContext context) {
    final s = AdminStore.I;
    final wide = MediaQuery.of(context).size.width >= 900;
    final title = _items.firstWhere((i) => i.id == s.page, orElse: () => _items.first).label;

    final failed = s.errors.entries.where((e) => e.key != 'tracking').toList();

    final body = Column(
      children: [
        _sosBanner(context),
        if (failed.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: NoticeBanner(
              'Some data could not load: ${failed.map((e) => '${e.key}: ${e.value}').join(' · ')}\n'
              'If it says "permission denied" or "does not exist", run v2_part9_admin_access.sql and '
              'v2_part10_admin_tracking.sql in Supabase, and make sure this account has role = admin.',
              color: kBad,
            ),
          ),
        Expanded(
          child: !s.loaded
              ? const Center(child: CircularProgressIndicator())
              : Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1200),
                    child: _page(s.page),
                  ),
                ),
        ),
      ],
    );

    final appBar = AppBar(
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      actions: [
        IconButton(
          tooltip: 'Refresh data',
          onPressed: s.loading ? null : () => s.loadAll(silent: true),
          icon: s.loading
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.refresh),
        ),
        const SizedBox(width: 6),
      ],
    );

    if (wide) {
      return Scaffold(
        appBar: appBar,
        body: Row(children: [
          _sidebar(context),
          const VerticalDivider(width: 1),
          Expanded(child: body),
        ]),
      );
    }
    return Scaffold(
      appBar: appBar,
      drawer: Drawer(child: _sidebar(context, drawer: true)),
      body: body,
    );
  }
}
