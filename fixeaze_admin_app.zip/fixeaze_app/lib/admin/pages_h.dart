import 'package:flutter/material.dart';

import '../services/pincode_service.dart';
import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';
import 'pages_e.dart' show techFreeNow;

AdminStore get _s => AdminStore.I;

const _noPin = 'No pincode';

class _Area {
  final String name;
  final List<Rec> techs = [];
  final List<Rec> custs = [];
  int departedTechs = 0;
  int departedCusts = 0;
  int bookings = 0;
  _Area(this.name);
}

class AreasPage extends StatefulWidget {
  const AreasPage({super.key});
  @override
  State<AreasPage> createState() => _AreasPageState();
}

class _AreasPageState extends State<AreasPage> {
  String _by = 'pin'; // pin | city
  int _days = 30;
  String _sort = 'total';
  final _q = TextEditingController();
  final Map<String, String> _cityOf = {}; // pincode -> city
  bool _loadingCities = false;

  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
    _loadCities();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    _q.dispose();
    super.dispose();
  }

  Set<String> _pins() {
    final out = <String>{};
    for (final p in _s.profiles) {
      final x = '${p['pincode'] ?? ''}'.trim();
      if (PincodeService.isValid(x)) out.add(x);
    }
    return out;
  }

  Future<void> _loadCities() async {
    if (_loadingCities) return;
    _loadingCities = true;
    final pins = _pins().where((p) => !_cityOf.containsKey(p)).take(60).toList();
    for (final pin in pins) {
      try {
        final info = await PincodeService.lookup(pin);
        final c = (info?.city ?? '').trim();
        _cityOf[pin] = c.isNotEmpty ? c : ((info?.label ?? '').trim());
      } catch (_) {
        _cityOf[pin] = '';
      }
      if (!mounted) return;
      if (_by == 'city') setState(() {});
    }
    _loadingCities = false;
  }

  String _areaKey(String pin) {
    if (pin.isEmpty) return _noPin;
    if (_by == 'pin') return pin;
    final c = _cityOf[pin];
    if (c == null) return 'Loading city...';
    return c.isEmpty ? 'Unknown city ($pin)' : c;
  }

  bool _inPeriod(dynamic ts, DateTime now) {
    if (_days == 0) return true;
    final d = parseTime(ts)?.toLocal();
    return d != null && d.isAfter(now.subtract(Duration(days: _days)));
  }

  DateTime? _activity(Rec b) => (parseTime(b['scheduled_at']) ?? parseTime(b['created_at']))?.toLocal();

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final now = DateTime.now();
    final cut30 = now.subtract(const Duration(days: 30));

    // customer pincode: profile first, else any booking
    final bookingPin = <String, String>{};
    for (final b in s.bookings) {
      final c = '${b['customer_id']}';
      final p = '${b['pincode'] ?? ''}'.trim();
      if (p.isNotEmpty) bookingPin.putIfAbsent(c, () => p);
    }
    String pinOf(Rec p) {
      final x = '${p['pincode'] ?? ''}'.trim();
      if (x.isNotEmpty) return x;
      return bookingPin['${p['id']}'] ?? '';
    }

    // last activity per technician and customer (within 30 days?)
    final techBusy30 = <String>{};
    final custBusy30 = <String>{};
    for (final b in s.bookings) {
      final a = _activity(b);
      if (a != null && a.isAfter(cut30)) {
        if (b['technician_id'] != null) techBusy30.add('${b['technician_id']}');
        custBusy30.add('${b['customer_id']}');
      }
    }

    final areas = <String, _Area>{};
    _Area area(String k) => areas.putIfAbsent(k, () => _Area(k));

    for (final p in s.profiles) {
      final role = '${p['role']}';
      if (role != 'technician' && role != 'customer') continue;
      final a = area(_areaKey(pinOf(p)));
      (role == 'technician' ? a.techs : a.custs).add(p);
    }
    for (final b in s.bookings) {
      if (!_inPeriod(b['created_at'], now)) continue;
      final cust = s.P['${b['customer_id']}'];
      final pin = '${b['pincode'] ?? ''}'.trim().isNotEmpty ? '${b['pincode']}'.trim() : (cust == null ? '' : pinOf(cust));
      area(_areaKey(pin)).bookings++;
    }
    for (final d in s.departed) {
      if (!_inPeriod(d['created_at'], now)) continue;
      final pin = '${d['pincode'] ?? ''}'.trim();
      final a = area(_areaKey(pin));
      if (d['role'] == 'technician') {
        a.departedTechs++;
      } else {
        a.departedCusts++;
      }
    }

    // per-area numbers
    bool isNew(Rec p) => _inPeriod(p['created_at'], now);
    bool approved(Rec p) => p['approved'] == true;
    bool paused(Rec p) => s.TP['${p['id']}']?['paused'] == true;
    bool freeNow(Rec p) => approved(p) && techFreeNow('${p['id']}');
    bool techInactive(Rec p) {
      if (!approved(p)) return false;
      final joined = parseTime(p['created_at'])?.toLocal();
      if (joined != null && joined.isAfter(cut30)) return false;
      return !techBusy30.contains('${p['id']}');
    }

    bool custDormant(Rec p) {
      final joined = parseTime(p['created_at'])?.toLocal();
      if (joined != null && joined.isAfter(cut30)) return false;
      return !custBusy30.contains('${p['id']}');
    }

    final all = areas.values.toList();
    final q = _q.text.trim().toLowerCase();
    var list = all.where((a) => q.isEmpty || a.name.toLowerCase().contains(q)).toList();
    int people(_Area a) => a.techs.length + a.custs.length;
    switch (_sort) {
      case 'techs':
        list.sort((a, b) => b.techs.length.compareTo(a.techs.length));
        break;
      case 'custs':
        list.sort((a, b) => b.custs.length.compareTo(a.custs.length));
        break;
      case 'bookings':
        list.sort((a, b) => b.bookings.compareTo(a.bookings));
        break;
      case 'name':
        list.sort((a, b) => a.name.compareTo(b.name));
        break;
      default:
        list.sort((a, b) => people(b).compareTo(people(a)));
    }

    // totals for the tiles
    final techs = s.profiles.where((p) => p['role'] == 'technician').toList();
    final instOwners = {for (final i in s.institutions) '${i['owner_id']}'};
    final custs = s.profiles.where((p) => p['role'] == 'customer' && !instOwners.contains('${p['id']}')).toList();
    final newTechs = techs.where(isNew).length;
    final newCusts = custs.where(isNew).length;
    final leftTechs = s.departed.where((d) => d['role'] == 'technician' && _inPeriod(d['created_at'], now)).length;
    final leftCusts = s.departed.where((d) => d['role'] == 'customer' && _inPeriod(d['created_at'], now)).length;
    final availNow = techs.where(freeNow).length;
    final inactiveTechs = techs.where(techInactive).length;
    final activeCusts = custs.where((c) => custBusy30.contains('${c['id']}')).length;
    final dormantCusts = custs.where(custDormant).length;
    final periodName = _days == 0 ? 'all time' : 'last $_days days';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['departed_users'] != null)
          NoticeBanner('"Deleted accounts" are not tracked yet. Run sql/v2_part19_departed.sql in Supabase. (${s.errors['departed_users']})',
              color: kWarn),
        Wrap(spacing: 12, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'pin', label: Text('By pincode')),
              ButtonSegment(value: 'city', label: Text('By city')),
            ],
            selected: {_by},
            onSelectionChanged: (v) {
              setState(() => _by = v.first);
              if (_by == 'city') _loadCities();
            },
          ),
          DropdownButton<int>(
            value: _days,
            items: const [
              DropdownMenuItem(value: 7, child: Text('New / left: last 7 days')),
              DropdownMenuItem(value: 30, child: Text('New / left: last 30 days')),
              DropdownMenuItem(value: 90, child: Text('New / left: last 90 days')),
              DropdownMenuItem(value: 365, child: Text('New / left: last year')),
              DropdownMenuItem(value: 0, child: Text('New / left: all time')),
            ],
            onChanged: (v) => setState(() => _days = v ?? 30),
          ),
        ]),
        const SizedBox(height: 12),
        TileGrid([
          StatTile('Technicians available now', '$availNow', sub: 'of ${techs.where(approved).length} approved'),
          StatTile('Technicians total', '${techs.length}',
              sub: '${techs.where((p) => !approved(p)).length} waiting for approval'),
          StatTile('New technicians', '$newTechs', sub: periodName),
          StatTile('Technicians left', '${leftTechs + inactiveTechs}',
              sub: '$leftTechs deleted ($periodName) + $inactiveTechs inactive 30 days', alert: inactiveTechs > 0),
          StatTile('Customers total', '${custs.length}', sub: '$activeCusts booked in last 30 days'),
          StatTile('New customers', '$newCusts', sub: periodName),
          StatTile('Customers left', '${leftCusts + dormantCusts}',
              sub: '$leftCusts deleted ($periodName) + $dormantCusts quiet 30 days'),
        ]),
        const SizedBox(height: 6),
        const Muted('Available now = approved, not paused, inside shift hours, not on leave and not on another job. '
            'Inactive / quiet = joined more than 30 days ago and no job or booking in the last 30 days. '
            'Deleted = the account was removed (tracked from now on).'),
        const SectionTitle('By area'),
        Wrap(spacing: 12, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SizedBox(
            width: 220,
            child: TextField(
              controller: _q,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(isDense: true, prefixIcon: Icon(Icons.search), hintText: 'Find a pincode or city'),
            ),
          ),
          DropdownButton<String>(
            value: _sort,
            items: const [
              DropdownMenuItem(value: 'total', child: Text('Sort: most people')),
              DropdownMenuItem(value: 'techs', child: Text('Sort: most technicians')),
              DropdownMenuItem(value: 'custs', child: Text('Sort: most customers')),
              DropdownMenuItem(value: 'bookings', child: Text('Sort: most bookings')),
              DropdownMenuItem(value: 'name', child: Text('Sort: name')),
            ],
            onChanged: (v) => setState(() => _sort = v ?? 'total'),
          ),
          CsvButton(
            name: 'areas',
            headers: () => [
              _by == 'pin' ? 'Pincode' : 'City', 'Technicians', 'Available now', 'Paused', 'Waiting approval',
              'New technicians', 'Inactive technicians', 'Deleted technicians', 'Customers', 'Active customers',
              'New customers', 'Quiet customers', 'Deleted customers', 'Bookings'
            ],
            rows: () => [
              for (final a in list)
                [
                  a.name, a.techs.length, a.techs.where(freeNow).length, a.techs.where(paused).length,
                  a.techs.where((p) => !approved(p)).length, a.techs.where(isNew).length,
                  a.techs.where(techInactive).length, a.departedTechs, a.custs.length,
                  a.custs.where((c) => custBusy30.contains('${c['id']}')).length, a.custs.where(isNew).length,
                  a.custs.where(custDormant).length, a.departedCusts, a.bookings
                ],
            ],
          ),
        ]),
        const SizedBox(height: 8),
        AdminTable(
          columns: [
            _by == 'pin' ? 'Pincode' : 'City', 'Techs', 'Free now', 'Paused', 'To approve', 'New techs', 'Inactive techs',
            'Deleted techs', 'Customers', 'Active cust.', 'New cust.', 'Quiet cust.', 'Deleted cust.', 'Bookings', ''
          ],
          numeric: const {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13},
          empty: 'No people yet.',
          rows: [
            for (final a in list)
              <Widget>[
                Text(a.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                Text('${a.techs.length}'),
                Text('${a.techs.where(freeNow).length}'),
                Text('${a.techs.where(paused).length}'),
                Text('${a.techs.where((p) => !approved(p)).length}'),
                Text('${a.techs.where(isNew).length}'),
                Text('${a.techs.where(techInactive).length}'),
                Text('${a.departedTechs}'),
                Text('${a.custs.length}'),
                Text('${a.custs.where((c) => custBusy30.contains('${c['id']}')).length}'),
                Text('${a.custs.where(isNew).length}'),
                Text('${a.custs.where(custDormant).length}'),
                Text('${a.departedCusts}'),
                Text('${a.bookings}'),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(minimumSize: const Size(0, 36)),
                  onPressed: () => showDialog<void>(
                    context: context,
                    builder: (_) => _PeopleDialog(
                      title: a.name,
                      techs: a.techs,
                      custs: a.custs,
                      free: freeNow,
                      paused: paused,
                      approved: approved,
                      inactive: techInactive,
                      isNew: isNew,
                      busy: (c) => custBusy30.contains('${c['id']}'),
                    ),
                  ),
                  child: const Text('People'),
                ),
              ],
          ],
        ),
      ],
    );
  }
}

class _PeopleDialog extends StatelessWidget {
  final String title;
  final List<Rec> techs;
  final List<Rec> custs;
  final bool Function(Rec) free;
  final bool Function(Rec) paused;
  final bool Function(Rec) approved;
  final bool Function(Rec) inactive;
  final bool Function(Rec) isNew;
  final bool Function(Rec) busy;
  const _PeopleDialog({
    required this.title,
    required this.techs,
    required this.custs,
    required this.free,
    required this.paused,
    required this.approved,
    required this.inactive,
    required this.isNew,
    required this.busy,
  });

  Widget _techPill(Rec p) {
    if (!approved(p)) return const Pill('Waiting approval', kWarn);
    if (paused(p)) return const Pill('Paused', kWarn);
    if (inactive(p)) return const Pill('Inactive', kBad);
    return free(p) ? const Pill('Free now', kOk) : const Pill('Busy / off shift', Colors.grey);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Technicians (${techs.length})', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            if (techs.isEmpty) const Muted('None'),
            for (final p in techs)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(children: [
                  Expanded(child: TwoLine('${p['name'] ?? '-'}', '${p['phone'] ?? ''} · joined ${fday(p['created_at'])}')),
                  if (isNew(p)) const Padding(padding: EdgeInsets.only(right: 6), child: Pill('New', kInfo)),
                  _techPill(p),
                ]),
              ),
            const SizedBox(height: 12),
            Text('Customers (${custs.length})', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            if (custs.isEmpty) const Muted('None'),
            for (final p in custs)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(children: [
                  Expanded(child: TwoLine('${p['name'] ?? '-'}', '${p['phone'] ?? ''} · joined ${fday(p['created_at'])}')),
                  if (isNew(p)) const Padding(padding: EdgeInsets.only(right: 6), child: Pill('New', kInfo)),
                  busy(p) ? const Pill('Active', kOk) : const Pill('Quiet', Colors.grey),
                ]),
              ),
          ]),
        ),
      ),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    );
  }
}
