import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// One database row.
typedef Rec = Map<String, dynamic>;

num numOf(dynamic v) {
  if (v is num) return v;
  return num.tryParse('${v ?? ''}') ?? 0;
}

String dkey(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

DateTime? parseTime(dynamic v) {
  if (v == null) return null;
  return DateTime.tryParse(v.toString());
}

String fdt(dynamic v) {
  final d = parseTime(v);
  if (d == null) return v == null ? '' : v.toString();
  return DateFormat('d MMM y, h:mm a').format(d.toLocal());
}

String fday(dynamic v) {
  final d = parseTime(v);
  if (d == null) return v == null ? '' : v.toString();
  return DateFormat('d MMM y').format(d.toLocal());
}

String ftime(dynamic v) {
  final d = parseTime(v);
  if (d == null) return '-';
  return DateFormat('h:mm a').format(d.toLocal());
}

String ago(dynamic v) {
  final d = parseTime(v);
  if (d == null) return '';
  final s = DateTime.now().difference(d).inSeconds;
  if (s < 60) return 'just now';
  if (s < 3600) return '${s ~/ 60} min ago';
  if (s < 86400) return '${s ~/ 3600} h ago';
  return '${s ~/ 86400} d ago';
}

/// 4h 05m style.
String hm(num sec) {
  final s = sec.round();
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  return h > 0 ? '${h}h ${m.toString().padLeft(2, '0')}m' : '${m}m';
}

double hrs(num sec) => (sec / 360).round() / 10;

String normName(dynamic s) =>
    (s ?? '').toString().trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

String initials(dynamic n) {
  final parts = (n ?? '').toString().trim().split(RegExp(r'\s+'));
  final out = parts.where((p) => p.isNotEmpty).take(2).map((p) => p[0]).join();
  return out.isEmpty ? '?' : out.toUpperCase();
}

String statusLabel(String s) {
  switch (s) {
    case 'pending':
      return 'Waiting';
    case 'accepted':
      return 'Assigned';
    case 'in_progress':
      return 'In progress';
    case 'completed':
      return 'Completed';
    case 'cancelled':
      return 'Cancelled';
    default:
      return s;
  }
}

Color statusColor(String s) {
  switch (s) {
    case 'pending':
      return Colors.orange.shade800;
    case 'accepted':
      return Colors.blue.shade700;
    case 'in_progress':
      return Colors.purple.shade700;
    case 'completed':
      return Colors.green.shade700;
    default:
      return Colors.grey.shade700;
  }
}

Color payColor(String s) {
  switch (s) {
    case 'paid':
      return Colors.green.shade700;
    case 'processing':
      return Colors.blue.shade700;
    case 'failed':
      return Colors.red.shade700;
    default:
      return Colors.orange.shade800;
  }
}

/// Date filter used by Bookings, Payments, SOS and Team.
class DateRangeFilter {
  String preset;
  DateTime? from;
  DateTime? to;

  DateRangeFilter(String p) : preset = p {
    apply(p);
  }

  void apply(String p) {
    preset = p;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    if (p == 'all') {
      from = null;
      to = null;
    } else if (p == 'today') {
      from = today;
      to = today;
    } else {
      final n = int.tryParse(p) ?? 7;
      from = today.subtract(Duration(days: n - 1));
      to = today;
    }
  }

  bool contains(dynamic v) {
    final f = from;
    final t = to;
    if (f == null && t == null) return true;
    final d = parseTime(v);
    if (d == null) return false;
    final l = d.toLocal();
    final day = DateTime(l.year, l.month, l.day);
    if (f != null && day.isBefore(f)) return false;
    if (t != null && day.isAfter(t)) return false;
    return true;
  }
}
