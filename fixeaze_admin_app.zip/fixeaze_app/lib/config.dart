import 'package:supabase_flutter/supabase_flutter.dart';

/// All project settings live here.
/// The publishable (anon) key is safe to ship in the app: your data is protected
/// by the Row Level Security rules in the database, not by hiding this key.
/// NEVER put the service_role / secret key in this app.
class AppConfig {
  static const supabaseUrl = 'https://yujmqhihsfpnyiiluxcy.supabase.co';
  static const supabaseAnonKey = 'sb_publishable_C0tFbtGoPxswgAT3vR4-Wg_1DyDnLRy';

  static const cloudinaryCloudName = 'do5wb8uyk';
  static const cloudinaryUploadPreset = 'ml_default';
}

SupabaseClient get supabase => Supabase.instance.client;
