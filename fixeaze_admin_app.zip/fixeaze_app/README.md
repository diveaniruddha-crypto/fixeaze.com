# Fixeaze - Customer & Technician app (Flutter Web)

One app, two roles. Backend: Supabase (login, database, private files). Photos: Cloudinary.

## What is in version 2
- **Skip for now**: visitors browse services and tips without an account. They must log in or sign up when they confirm a booking.
- **Customer signup**: pincode is mandatory. It is saved in the account and auto-filled when booking.
- **Booking**: choose **Book hourly** (hours x technician rates) or **Estimate & inspection** (fixed visit fee, repair quoted after). Describe the problem, add photos.
- **10 km availability**: when the customer types a pincode, the app shows how many approved technicians within 10 km offer that service. Technicians only see jobs within 10 km that match their services.
- **Technician application**: details, Aadhaar number and photo, services (multiple), experience, own hourly rate, shift timing + confirmation, pincode. Then a review screen, then an email OTP creates the account. Admin approves after checking the Aadhaar.
- **Tips tab**: daily and monthly maintenance tips (tip of the day / month on top).
- **Chat**: customer and technician chat live on each accepted booking.

## 1. Update the database (do this first)
Open Supabase > SQL Editor. Run these files **one at a time, in order**, each in a new query.
Delete any stray `)` the editor adds on the last line after pasting.

1. `v2_part1_tables.sql`
2. `v2_part2_functions.sql`
3. `v2_part3_triggers.sql`
4. `v2_part4_policies.sql`
5. `v2_part5_storage_realtime.sql`
6. `v2_part6_tips.sql` (run once only)
7. `v2_part7_technician_selfie_bank.sql` (selfie + bank details)
8. `v2_part8_technician_tools.sql` (pause, calendar/leave, SOS, payments)

Each should say "Success".

## 2. Supabase settings for the email OTP (important)
1. **Authentication > Email Templates**: edit both **Confirm signup** and **Magic Link**. Put the code in the body, for example:
   `Your Fixeaze code is {{ .Token }}`
   (If the template only has a link, technicians never receive a code.)
2. **Authentication > SMTP Settings**: Supabase's built-in email sender allows only a few emails per hour,
   which is not enough for real signups. Add a free SMTP service (Brevo, Resend, or Gmail app password) and enable custom SMTP.
3. **Authentication > Sign In / Providers > Email**: leave Confirm email ON (the OTP does the confirming).
   For testing customer signup without email, you may turn it OFF.

### Make the email say Fixeaze (not Supabase)
1. **Authentication > Email Templates > Confirm signup**: set Subject to `Your Fixeaze verification code` and paste `email_templates/confirm_signup.html` as the body.
2. Do the same for **Magic Link** with `email_templates/magic_link.html`.
3. **Authentication > SMTP Settings**: enable custom SMTP and set **Sender name = Fixeaze** and your own sender email.
   Supabase's built-in sender always shows "Supabase Auth", so custom SMTP is the only way to change the sender name.
Customers and technicians both get a 6-digit code in the app now.
If the code length differs, set it in **Authentication > Sign In / Providers > Email > OTP length**.

## 3. Approve a technician (until the Admin site exists)
1. **Storage > kyc**: open the technician's folder and view the Aadhaar photo and selfie. Bank details are in **technician_kyc**.
2. **Table Editor > technician_kyc**: check `aadhaar_name` and the last 4 digits.
3. Compare with the name on the card. If it matches, **Table Editor > profiles**: set `approved` = true.
4. Change the per-service inspection price any time in **services > inspection_fee**.

Make yourself admin (after signing up as a customer once):
```sql
update public.profiles set role = 'admin', approved = true
where email = 'your-admin-email@example.com';
```

## 4. Run / host
```
flutter create fixeaze_app --platforms=web
```
Copy `lib/`, `assets/`, `pubspec.yaml` into it, delete `test/widget_test.dart`, then
```
flutter pub get
flutter run -d chrome
```
Phone-only? Use the GitHub Pages build described in the chat.

## 5. Test checklist
1. Open the app > **Skip for now** > browse > try booking > it asks you to log in.
2. Join as technician (second browser): fill the form, review, get the email code, create account.
3. Approve that technician (step 3 above). Check their pincode, services, rate.
4. Customer: sign up with a pincode near the technician (same city), book an hourly job. The booking screen shows "1 technician available within 10 km".
5. Technician: Open jobs > Accept. Both sides: tap **Chat**.
6. Technician: Start job > Mark completed. Customer: Rate technician.

## 6. Known limits
- **Aadhaar is checked by a person, not automatically.** The app checks the number format and that the name typed matches the account name, then your team compares with the photo.
  The full number is never stored, only the last 4 digits. The photo sits in a private bucket.
  Aadhaar rules for private businesses are strict, so consider asking a lawyer before launch.
- **Pincode to location** uses free OpenStreetMap. Some pincodes may not be found; the user is asked to re-check. A paid or offline pincode list is more reliable at scale.
- Distance is measured between pincode centres, not exact addresses.
- Shift timing is stored and shown but does not yet block jobs outside the shift.
- Payments, push notifications and the Admin website are not included yet.


## Technician tools (v3)
- **Home strip**: Active/Paused switch (paused technicians get no new jobs and are not counted for customers) and a red **SOS** button.
- **SOS** sends the technician's current location (browser asks permission; the site must be HTTPS) to table `sos_alerts`.
  Admin: open **Table Editor > admin_sos_alerts** (a view with the technician's name, phone and a Google Maps link).
  Set `status` to `acknowledged` / `resolved` in `sos_alerts` when handled. Emails/SMS to admin need a Supabase Database Webhook or Edge Function (not included).
- **Chats**: only for bookings the technician accepted. Active jobs can send; completed jobs are read-only.
- **Calendar**: booked / free / leave / custom-shift days, leave for one day or a date range, per-day shift, and regular shift. Leave is blocked on days with bookings.
- **Payments**: a row is created automatically when a job is completed (amount = booking `price`).
  To pay: **Table Editor > technician_payments**, set `status` to `processing` / `paid` / `failed` (add `reference`). The technician gets an update automatically under **Updates from Fixeaze**.
