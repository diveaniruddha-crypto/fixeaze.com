// Edge Function "send-backup": emails the monthly data ZIP to the Fixeaze team.
// Secrets needed: SMTP_USER, SMTP_PASS  (Gmail address + app password)
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const TO = [
  "diveaniruddha@fixeaze.com",
  "support@fixeaze.com",
  "tejasvi.mhatre@fixeaze.com",
  "parag.pendhari@fixeaze.com",
];
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const asUser = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: isAdmin } = await asUser.rpc("is_admin");
    if (isAdmin !== true) return json({ error: "Admins only" }, 403);

    const { path, subject } = await req.json();
    if (!/^backup_[\w\-]+\.zip$/.test(path ?? "")) return json({ error: "Bad file name" }, 400);

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: file, error } = await admin.storage.from("backups").download(path);
    if (error || !file) return json({ error: error?.message ?? "File not found" }, 404);
    const bytes = new Uint8Array(await file.arrayBuffer());

    const user = Deno.env.get("SMTP_USER")!;
    const smtp = new SMTPClient({
      connection: {
        hostname: "smtp.gmail.com",
        port: 465,
        tls: true,
        auth: { username: user, password: Deno.env.get("SMTP_PASS")! },
      },
    });
    await smtp.send({
      from: `Fixeaze <${user}>`,
      to: TO,
      subject: String(subject ?? "Data backup").slice(0, 120),
      content: "Monthly Fixeaze data backup is attached (CSV files in a ZIP).\nKeep it private.",
      attachments: [{ filename: path, content: bytes, contentType: "application/zip", encoding: "binary" }],
    });
    await smtp.close();
    await admin.storage.from("backups").remove([path]);
    return json({ ok: true });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
