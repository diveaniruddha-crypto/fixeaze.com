// Supabase Edge Function "push": sends a push notification to the admins' phones.
// Secrets needed (Edge Functions > Secrets): VAPID_PUBLIC, VAPID_PRIVATE, PUSH_SECRET
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.headers.get("x-push-secret") !== Deno.env.get("PUSH_SECRET")) {
    return new Response("forbidden", { status: 403 });
  }
  let msg: any = {};
  try { msg = await req.json(); } catch (_) {}

  webpush.setVapidDetails(
    "mailto:diveaniruddha@fixeaze.com",
    Deno.env.get("VAPID_PUBLIC")!,
    Deno.env.get("VAPID_PRIVATE")!,
  );
  const sb = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  let q = sb.from("admin_push_subscriptions").select("*");
  if (msg.only) q = q.eq("admin_id", msg.only);
  const { data, error } = await q;
  if (error) return new Response(error.message, { status: 500 });

  const subs = (data ?? []).filter((s: any) => !msg.skip || s.admin_id !== msg.skip);
  const payload = JSON.stringify({ kind: msg.kind, title: msg.title, body: msg.body });
  let sent = 0;
  await Promise.all(subs.map(async (s: any) => {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        payload,
        { TTL: 3600, urgency: "high" },
      );
      sent++;
    } catch (e: any) {
      if (e?.statusCode === 404 || e?.statusCode === 410) {
        await sb.from("admin_push_subscriptions").delete().eq("id", s.id);
      }
    }
  }));
  return new Response(JSON.stringify({ sent, total: subs.length }), {
    headers: { "Content-Type": "application/json" },
  });
});
