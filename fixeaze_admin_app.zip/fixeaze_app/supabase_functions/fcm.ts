// Supabase Edge Function "fcm": sends a phone notification to one user (or all customers) through Firebase (free).
// Secrets needed (Edge Functions > Secrets): FCM_SERVICE_ACCOUNT (the whole JSON file), PUSH_SECRET
import { createClient } from "npm:@supabase/supabase-js@2";

function b64url(data: ArrayBuffer | string): string {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data);
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function accessToken(sa: any): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  }));
  const pem = String(sa.private_key).replace(/-----[A-Z ]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${header}.${claim}`));
  const jwt = `${header}.${claim}.${b64url(sig)}`;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });
  const j = await res.json();
  if (!j.access_token) throw new Error("Google sign-in failed: " + JSON.stringify(j));
  return j.access_token;
}

Deno.serve(async (req) => {
  if (req.headers.get("x-push-secret") !== Deno.env.get("PUSH_SECRET")) {
    return new Response("forbidden", { status: 403 });
  }
  let msg: any = {};
  try { msg = await req.json(); } catch (_) {}
  if (!msg.user_id && !msg.role) return new Response("no target", { status: 400 });

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  let tokens: string[] = [];
  if (msg.user_id) {
    const { data, error } = await sb.from("device_tokens").select("token").eq("user_id", msg.user_id);
    if (error) return new Response(error.message, { status: 500 });
    tokens = (data ?? []).map((r: any) => r.token as string);
  } else {
    // everyone of one kind (for example every customer), up to 500 phones per message
    const { data, error } = await sb.from("device_tokens")
      .select("token, profiles!inner(role)").eq("profiles.role", msg.role).limit(500);
    if (error) return new Response(error.message, { status: 500 });
    tokens = (data ?? []).map((r: any) => r.token as string);
  }
  if (tokens.length === 0) return new Response(JSON.stringify({ sent: 0 }));

  const sa = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT")!);
  const at = await accessToken(sa);
  let sent = 0;
  await Promise.all(tokens.map(async (token) => {
    const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${at}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        message: {
          token,
          notification: { title: msg.title ?? "Fixeaze", body: msg.body ?? "" },
          android: { priority: "HIGH", notification: { sound: "default" } },
          apns: { headers: { "apns-priority": "10" }, payload: { aps: { sound: "default" } } },
        },
      }),
    });
    if (res.ok) {
      sent++;
    } else {
      const t = await res.text();
      if (res.status === 404 || t.includes("UNREGISTERED") || t.includes("INVALID_ARGUMENT")) {
        await sb.from("device_tokens").delete().eq("token", token);
      }
    }
  }));
  return new Response(JSON.stringify({ sent, total: tokens.length }), {
    headers: { "Content-Type": "application/json" },
  });
});
