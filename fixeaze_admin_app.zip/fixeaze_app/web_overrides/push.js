// Small bridge used by the admin app: turn notifications on and play sounds.
(function () {
  function b64(s) {
    var p = '='.repeat((4 - (s.length % 4)) % 4);
    var raw = atob((s + p).replace(/-/g, '+').replace(/_/g, '/'));
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  function supported() {
    return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  }
  function activated(reg) {
    return new Promise(function (resolve) {
      var sw = reg.installing || reg.waiting || reg.active;
      if (!sw) return resolve();
      if (sw.state === 'activated') return resolve();
      sw.addEventListener('statechange', function () {
        if (sw.state === 'activated') resolve();
      });
    });
  }
  var sounds = {};
  function play(kind) {
    try {
      var file = kind === 'chat' ? 'sounds/chat.wav' : 'sounds/alert.wav';
      var a = sounds[file] || (sounds[file] = new Audio(file));
      a.currentTime = 0;
      var p = a.play();
      if (p && p.catch) p.catch(function () {});
    } catch (_) {}
  }
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', function (ev) {
      if (ev.data && ev.data.type === 'fx-push') play(ev.data.kind);
    });
    if (navigator.serviceWorker.startMessages) navigator.serviceWorker.startMessages();
  }
  window.fixeazePush = {
    supported: function () { return supported(); },
    permission: function () { return supported() ? Notification.permission : 'unsupported'; },
    play: function (kind) { play(kind); },
    // Asks permission (if needed), subscribes, returns the subscription as JSON text.
    enable: async function (vapid, ask) {
      if (!supported()) throw new Error('This browser cannot show notifications. On iPhone, add the app to the Home Screen first.');
      if (Notification.permission === 'denied') throw new Error('Notifications are blocked for this site. Allow them in the browser or app settings.');
      if (Notification.permission !== 'granted') {
        if (!ask) return '';
        var res = await Notification.requestPermission();
        if (res !== 'granted') throw new Error('Notifications were not allowed.');
      }
      var scope = new URL('push-scope/', document.baseURI).pathname;
      var reg = await navigator.serviceWorker.register('push-sw.js', { scope: scope });
      await activated(reg);
      var sub = await reg.pushManager.getSubscription();
      if (!sub) {
        sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(vapid) });
      }
      return JSON.stringify(sub.toJSON());
    }
  };
})();
