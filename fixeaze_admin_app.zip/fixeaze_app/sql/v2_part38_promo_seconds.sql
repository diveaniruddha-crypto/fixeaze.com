-- Fixeaze part 38: how many seconds each banner / advertisement is shown.
-- Run once in Supabase > SQL Editor. Safe to run twice.

alter table public.promos
  add column if not exists seconds int not null default 5;

alter table public.promos drop constraint if exists promos_seconds_check;
alter table public.promos
  add constraint promos_seconds_check check (seconds between 0 and 120);

-- Ads made before this part stay until the customer closes them (0 = no auto close).
update public.promos set seconds = 0 where kind = 'ad' and seconds = 5;

drop function if exists public.get_promos(text, text, text, text);
create function public.get_promos(
  p_kind text, p_audience text,
  p_pincode text default null, p_place text default null)
returns table (id uuid, kind text, title text, media_url text, media_type text,
               link_type text, link_value text, seconds int)
language sql stable security definer set search_path = public as $$
  select p.id, p.kind, p.title, p.media_url, p.media_type, p.link_type, p.link_value, p.seconds
  from public.promos p
  where p.active
    and p.kind = p_kind
    and (now() at time zone 'Asia/Kolkata')::date between p.date_from and p.date_to
    and p.audience in (p_audience, 'both')
    and (coalesce(trim(p.pincode), '') = ''
         or (p_pincode is not null and p_pincode = any (string_to_array(replace(p.pincode, ' ', ''), ','))))
    and (coalesce(trim(p.city), '') = ''
         or (p_place is not null and p_place ilike '%' || trim(p.city) || '%'))
  order by p.created_at desc
  limit 10;
$$;
grant execute on function public.get_promos(text, text, text, text) to anon, authenticated;
