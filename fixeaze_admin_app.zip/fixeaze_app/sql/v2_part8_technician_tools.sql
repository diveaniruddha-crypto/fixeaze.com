-- Technician tools: pause listing, calendar (leave + custom shifts), SOS, payments.
-- Run this AFTER v2_part1 ... v2_part7. Safe to run twice.

-- ---------- 1. Pause listing ----------
alter table public.technician_profiles add column if not exists paused boolean not null default false;
alter table public.technician_profiles add column if not exists paused_at timestamptz;

-- ---------- 2. Calendar: leave days and custom shifts ----------
create table if not exists public.technician_schedule (
  id uuid primary key default gen_random_uuid(),
  technician_id uuid not null references public.profiles(id) on delete cascade,
  day date not null,
  kind text not null check (kind in ('leave', 'shift')),
  shift_start time,
  shift_end time,
  reason text,
  created_at timestamptz not null default now(),
  unique (technician_id, day),
  check (kind <> 'shift' or (shift_start is not null and shift_end is not null and shift_end > shift_start))
);
alter table public.technician_schedule enable row level security;

drop policy if exists "schedule own or admin" on public.technician_schedule;
create policy "schedule own or admin" on public.technician_schedule for all to authenticated
  using ((technician_id = auth.uid() and public.is_technician_role()) or public.is_admin())
  with check ((technician_id = auth.uid() and public.is_technician_role()) or public.is_admin());
grant select, insert, update, delete on public.technician_schedule to authenticated;

-- ---------- 3. SOS alerts ----------
create table if not exists public.sos_alerts (
  id uuid primary key default gen_random_uuid(),
  technician_id uuid not null references public.profiles(id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  lat double precision,
  lng double precision,
  accuracy_m double precision,
  note text,
  status text not null default 'open' check (status in ('open', 'acknowledged', 'resolved')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);
alter table public.sos_alerts enable row level security;

drop policy if exists "sos read" on public.sos_alerts;
create policy "sos read" on public.sos_alerts for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());

drop policy if exists "sos insert" on public.sos_alerts;
create policy "sos insert" on public.sos_alerts for insert to authenticated
  with check (technician_id = auth.uid() and public.is_technician_role() and status = 'open');

drop policy if exists "sos admin update" on public.sos_alerts;
create policy "sos admin update" on public.sos_alerts for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update on public.sos_alerts to authenticated;

-- Easy view for the admin: who, phone, and a Google Maps link.
create or replace view public.admin_sos_alerts with (security_invoker = true) as
select a.id, a.created_at, a.status, p.name as technician, p.phone,
       a.lat, a.lng,
       case when a.lat is not null
            then 'https://www.google.com/maps?q=' || a.lat || ',' || a.lng end as map_link,
       a.booking_id, a.note, a.resolved_at
from public.sos_alerts a
join public.profiles p on p.id = a.technician_id
order by a.created_at desc;
grant select on public.admin_sos_alerts to authenticated;

do $$ begin
  alter publication supabase_realtime add table public.sos_alerts;
exception when duplicate_object then null;
end $$;

-- ---------- 4. Payments and updates from Fixeaze ----------
create table if not exists public.technician_payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid unique references public.bookings(id) on delete set null,
  technician_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(10,2) not null default 0,
  status text not null default 'pending' check (status in ('pending', 'processing', 'paid', 'failed')),
  reference text,
  note text,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.technician_payments enable row level security;

drop policy if exists "payments read" on public.technician_payments;
create policy "payments read" on public.technician_payments for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());

drop policy if exists "payments admin write" on public.technician_payments;
create policy "payments admin write" on public.technician_payments for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.technician_payments to authenticated;

create table if not exists public.technician_notifications (
  id uuid primary key default gen_random_uuid(),
  technician_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null default 'general',
  title text not null,
  body text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.technician_notifications enable row level security;

drop policy if exists "notif read" on public.technician_notifications;
create policy "notif read" on public.technician_notifications for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());

drop policy if exists "notif mark read" on public.technician_notifications;
create policy "notif mark read" on public.technician_notifications for update to authenticated
  using (technician_id = auth.uid()) with check (technician_id = auth.uid());

drop policy if exists "notif admin insert" on public.technician_notifications;
create policy "notif admin insert" on public.technician_notifications for insert to authenticated
  with check (public.is_admin());

grant select, insert on public.technician_notifications to authenticated;
-- A technician can only change the "read" column.
grant update (read) on public.technician_notifications to authenticated;

-- When a job is completed: create the payment row (amount = booking price) and tell the technician.
create or replace function public.on_booking_completed_payment()
returns trigger language plpgsql security definer set search_path = public as $$
declare amt numeric(10,2);
begin
  amt := coalesce(nullif(to_jsonb(new)->>'price', '')::numeric, 0);

  if new.status = 'completed' and old.status is distinct from 'completed'
     and new.technician_id is not null then
    insert into public.technician_payments (booking_id, technician_id, amount)
    values (new.id, new.technician_id, amt)
    on conflict (booking_id) do nothing;

    insert into public.technician_notifications (technician_id, kind, title, body)
    values (new.technician_id, 'payment', 'Job completed',
            'Your payment for this job is now pending with Fixeaze. We will update you here.');
  elsif new.technician_id is not null
        and (to_jsonb(new)->>'price') is distinct from (to_jsonb(old)->>'price') then
    update public.technician_payments set amount = amt, updated_at = now()
    where booking_id = new.id and status = 'pending';
  end if;
  return new;
end $$;

drop trigger if exists trg_booking_completed_payment on public.bookings;
create trigger trg_booking_completed_payment after update on public.bookings
  for each row execute function public.on_booking_completed_payment();

-- When the admin changes a payment: stamp paid_at and notify the technician.
create or replace function public.on_payment_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  if tg_op = 'UPDATE' and new.status is distinct from old.status then
    if new.status = 'paid' then
      new.paid_at := coalesce(new.paid_at, now());
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Payment received',
              'Fixeaze has paid Rs ' || new.amount || ' for your job.'
              || coalesce(' Reference: ' || new.reference || '.', ''));
    elsif new.status = 'processing' then
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Payment is being processed',
              'Your payment of Rs ' || new.amount || ' is being processed.');
    elsif new.status = 'failed' then
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Payment failed',
              'Your payment of Rs ' || new.amount || ' could not be completed.'
              || coalesce(' ' || new.note, ''));
    end if;
  elsif tg_op = 'UPDATE' and new.amount is distinct from old.amount then
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (new.technician_id, 'payment', 'Payment amount updated',
            'Your payment amount is now Rs ' || new.amount || '.');
  end if;
  return new;
end $$;

drop trigger if exists trg_payment_change on public.technician_payments;
create trigger trg_payment_change before insert or update on public.technician_payments
  for each row execute function public.on_payment_change();

-- ---------- 5. Paused / on leave technicians get no new jobs ----------
create or replace function public.can_take_job(p_service uuid, p_lat double precision, p_lng double precision)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'technician' and p.approved = true
      and p.lat is not null and p.lng is not null
      and p_lat is not null and p_lng is not null
      and public.km_between(p.lat, p.lng, p_lat, p_lng) <= 10
      and exists (select 1 from public.technician_services ts
                  where ts.technician_id = p.id and ts.service_id = p_service)
      and not exists (select 1 from public.technician_profiles tp
                      where tp.id = p.id and tp.paused)
      and not exists (select 1 from public.technician_schedule s
                      where s.technician_id = p.id and s.kind = 'leave'
                        and s.day = (now() at time zone 'Asia/Kolkata')::date)
  );
$$;

create or replace function public.technicians_nearby(p_lat double precision, p_lng double precision, p_service uuid default null, p_km double precision default 10)
returns table (cnt int, min_rate numeric, max_rate numeric)
language sql stable security definer set search_path = public as $$
  select count(*)::int, min(tp.hourly_rate), max(tp.hourly_rate)
  from public.profiles p
  join public.technician_profiles tp on tp.id = p.id
  where p.role = 'technician' and p.approved = true
    and tp.paused = false
    and p.lat is not null and p.lng is not null
    and public.km_between(p.lat, p.lng, p_lat, p_lng) <= p_km
    and not exists (select 1 from public.technician_schedule s
                    where s.technician_id = p.id and s.kind = 'leave'
                      and s.day = (now() at time zone 'Asia/Kolkata')::date)
    and (p_service is null or exists (
      select 1 from public.technician_services ts
      where ts.technician_id = p.id and ts.service_id = p_service));
$$;

-- A technician cannot accept a job that falls on one of their leave days.
create or replace function public.block_job_on_leave()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.technician_id is not null
     and new.technician_id is distinct from old.technician_id
     and not public.is_admin()
     and exists (select 1 from public.technician_schedule s
                 where s.technician_id = new.technician_id and s.kind = 'leave'
                   and s.day = (new.scheduled_at at time zone 'Asia/Kolkata')::date) then
    raise exception 'You are on leave on the day of this job';
  end if;
  return new;
end $$;

drop trigger if exists trg_block_job_on_leave on public.bookings;
create trigger trg_block_job_on_leave before update on public.bookings
  for each row execute function public.block_job_on_leave();
