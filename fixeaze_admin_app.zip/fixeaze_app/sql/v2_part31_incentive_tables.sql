-- Part 31: incentive settings, technician login days, incentive awards
create table if not exists public.incentive_settings (
  id int primary key default 1 check (id = 1),
  enabled boolean not null default false,
  min_login_days int not null default 20 check (min_login_days between 1 and 31),
  pct numeric(5,2) not null default 2 check (pct >= 0 and pct <= 100),
  base text not null default 'gross' check (base in ('gross', 'earnings')),
  credit_day int not null default 7 check (credit_day between 1 and 28),
  updated_at timestamptz not null default now());
insert into public.incentive_settings (id) values (1) on conflict (id) do nothing;
alter table public.incentive_settings enable row level security;
drop policy if exists "inc settings admin" on public.incentive_settings;
create policy "inc settings admin" on public.incentive_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update on public.incentive_settings to authenticated;

create table if not exists public.technician_login_days (
  technician_id uuid not null references public.profiles(id) on delete cascade,
  day date not null,
  primary key (technician_id, day));
alter table public.technician_login_days enable row level security;
drop policy if exists "login days read" on public.technician_login_days;
create policy "login days read" on public.technician_login_days for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());
grant select on public.technician_login_days to authenticated;

create or replace function public.touch_login_day()
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not exists (select 1 from public.profiles where id = auth.uid() and role = 'technician') then
    return;
  end if;
  insert into public.technician_login_days (technician_id, day)
  values (auth.uid(), (now() at time zone 'Asia/Kolkata')::date)
  on conflict do nothing;
end $$;
grant execute on function public.touch_login_day() to authenticated;

create table if not exists public.incentive_awards (
  id uuid primary key default gen_random_uuid(),
  month date not null,
  technician_id uuid not null references public.profiles(id) on delete cascade,
  login_days int not null default 0,
  jobs int not null default 0,
  base_amount numeric(12,2) not null default 0,
  pct numeric(5,2) not null default 0,
  amount numeric(12,2) not null default 0,
  cancels int not null default 0,
  status text not null default 'eligible' check (status in ('eligible', 'not_eligible', 'held', 'credited')),
  reason text,
  credit_on date,
  credited_at timestamptz,
  created_at timestamptz not null default now(),
  unique (month, technician_id));
alter table public.incentive_awards enable row level security;
drop policy if exists "awards read" on public.incentive_awards;
create policy "awards read" on public.incentive_awards for select to authenticated
  using (public.is_admin() or (technician_id = auth.uid() and status in ('eligible', 'credited')));
grant select on public.incentive_awards to authenticated;
