insert into storage.buckets (id, name, public)
values ('backups', 'backups', false)
on conflict (id) do nothing;

drop policy if exists "backups admin write" on storage.objects;
create policy "backups admin write" on storage.objects for insert to authenticated
  with check (bucket_id = 'backups' and public.is_admin());
