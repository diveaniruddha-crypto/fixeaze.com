-- Fixeaze part 40: Care tips by product (Fan, AC, Geyser ...) with daily and monthly tips.
-- Run once in Supabase > SQL Editor. Safe to run twice.

create table if not exists public.tip_products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  image_url text,
  sort int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.tip_products enable row level security;

drop policy if exists "tip products read" on public.tip_products;
create policy "tip products read" on public.tip_products for select to anon, authenticated
  using (active = true or public.is_admin());
drop policy if exists "tip products admin" on public.tip_products;
create policy "tip products admin" on public.tip_products for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select on public.tip_products to anon;
grant select, insert, update, delete on public.tip_products to authenticated;

alter table public.maintenance_tips
  add column if not exists tip_product_id uuid references public.tip_products(id) on delete cascade;
create index if not exists maintenance_tips_product_idx on public.maintenance_tips (tip_product_id);

-- Turn the tips you already have into products.
insert into public.tip_products (name, sort)
select min(t.product), (row_number() over (order by min(t.sort), min(t.product)))::int
from public.maintenance_tips t
where t.tip_product_id is null
  and not exists (select 1 from public.tip_products p where lower(p.name) = lower(t.product))
group by lower(t.product);

update public.maintenance_tips t
   set tip_product_id = p.id
  from public.tip_products p
 where t.tip_product_id is null and lower(p.name) = lower(t.product);
