-- PIECE 1: phone helpers, login by phone, duplicate check
create or replace function public.norm_phone(p text)
returns text language sql immutable as $$
  select case when length(regexp_replace(coalesce(p, ''), '\D', '', 'g')) >= 10
    then right(regexp_replace(p, '\D', '', 'g'), 10) else null end
$$;

create or replace function public.email_for_login(p_id text)
returns text language plpgsql stable security definer set search_path = public as $$
declare v text;
begin
  if position('@' in coalesce(p_id, '')) > 0 then return lower(trim(p_id)); end if;
  if public.norm_phone(p_id) is null then return null; end if;
  select email into v from public.profiles
   where public.norm_phone(phone) = public.norm_phone(p_id) and role in ('customer', 'technician')
   limit 1;
  return v;
end $$;
grant execute on function public.email_for_login(text) to anon, authenticated;

create or replace function public.account_exists(p_email text, p_phone text)
returns text language plpgsql stable security definer set search_path = public as $$
begin
  if coalesce(trim(p_email), '') <> ''
     and exists (select 1 from auth.users where lower(email) = lower(trim(p_email))) then
    return 'email';
  end if;
  if public.norm_phone(p_phone) is not null
     and exists (select 1 from public.profiles where public.norm_phone(phone) = public.norm_phone(p_phone)) then
    return 'phone';
  end if;
  return null;
end $$;
grant execute on function public.account_exists(text, text) to anon, authenticated;

-- PIECE 2: block duplicate phone numbers at account creation
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare r text; m jsonb;
begin
  m := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  r := coalesce(m->>'role', 'customer');
  if r not in ('customer','technician') then r := 'customer'; end if;
  if public.norm_phone(m->>'phone') is not null
     and exists (select 1 from public.profiles where public.norm_phone(phone) = public.norm_phone(m->>'phone')) then
    raise exception 'This mobile number is already registered';
  end if;
  insert into public.profiles (id, name, email, phone, role, approved, pincode, lat, lng)
  values (new.id, coalesce(m->>'name', m->>'full_name'), new.email, m->>'phone', r, r = 'customer',
          m->>'pincode',
          nullif(m->>'lat', '')::double precision,
          nullif(m->>'lng', '')::double precision);
  return new;
end $$;

do $$ begin
  create unique index if not exists profiles_phone_key
    on public.profiles (public.norm_phone(phone)) where public.norm_phone(phone) is not null;
exception when unique_violation then
  raise notice 'Duplicate phone numbers already exist, unique index skipped';
end $$;

-- PIECE 3: finish profile after Google sign-in
create or replace function public.complete_profile(p_name text, p_phone text, p_pincode text, p_lat double precision, p_lng double precision)
returns void language plpgsql security definer set search_path = public as $$
begin
  if public.norm_phone(p_phone) is null then raise exception 'Enter a valid mobile number'; end if;
  if exists (select 1 from public.profiles
              where public.norm_phone(phone) = public.norm_phone(p_phone) and id <> auth.uid()) then
    raise exception 'This mobile number is already registered';
  end if;
  perform set_config('fixeaze.rpc', '1', true);
  update public.profiles
     set name = coalesce(nullif(trim(p_name), ''), name), phone = trim(p_phone),
         pincode = p_pincode, lat = p_lat, lng = p_lng
   where id = auth.uid();
end $$;
grant execute on function public.complete_profile(text, text, text, double precision, double precision) to authenticated;
