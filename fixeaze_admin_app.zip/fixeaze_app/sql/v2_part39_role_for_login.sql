-- Fixeaze part 39: lets the login screen know if an account is a customer or a technician
-- BEFORE signing in, so each account only works on its own tab.
-- Run once in Supabase > SQL Editor. Safe to run twice.

create or replace function public.role_for_login(p_id text)
returns text language plpgsql stable security definer set search_path = public as $$
declare v text;
begin
  if position('@' in coalesce(p_id, '')) > 0 then
    select role into v from public.profiles
     where lower(email) = lower(trim(p_id)) limit 1;
  elsif public.norm_phone(p_id) is not null then
    select role into v from public.profiles
     where public.norm_phone(phone) = public.norm_phone(p_id)
       and role in ('customer', 'technician')
     limit 1;
  end if;
  return v;
end $$;
grant execute on function public.role_for_login(text) to anon, authenticated;
