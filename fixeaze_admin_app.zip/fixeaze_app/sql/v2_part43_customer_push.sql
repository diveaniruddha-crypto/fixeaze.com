-- Fixeaze part 43: phone notifications for customers and chat for both sides.
-- Needs part 42. Run once in Supabase > SQL Editor. Safe to run twice.
-- Also paste the updated Edge Function "fcm" (supabase_functions/fcm.ts) again and deploy it.

-- Send one notification to every phone of one kind of user (customer / technician)
create or replace function public.push_role(p_role text, p_title text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
declare u text; sec text;
begin
  select value into u from public.push_config where key = 'fcm_url';
  select value into sec from public.push_config where key = 'secret';
  if u is null or sec is null then return; end if;
  perform net.http_post(
    url := u,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', sec),
    body := jsonb_build_object('role', p_role, 'title', p_title, 'body', left(coalesce(p_body, ''), 200)));
exception when others then
  null;
end $$;
revoke execute on function public.push_role(text, text, text) from public, anon, authenticated;

-- 1. Chat: a message on a booking goes to the other person
create or replace function public.trg_push_chat() returns trigger
language plpgsql security definer set search_path = public as $$
declare b record; who uuid; n text;
begin
  select customer_id, technician_id into b from public.bookings where id = new.booking_id;
  if not found then return new; end if;
  if new.sender_id = b.customer_id then who := b.technician_id;
  elsif new.sender_id = b.technician_id then who := b.customer_id;
  else return new; end if;
  if who is null then return new; end if;
  select name into n from public.profiles where id = new.sender_id;
  perform public.push_user(who, coalesce(n, 'New message'), new.body);
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists zz_push_chat on public.messages;
create trigger zz_push_chat after insert on public.messages
  for each row execute function public.trg_push_chat();

-- 2. Booking events
create or replace function public.trg_push_booking_events() returns trigger
language plpgsql security definer set search_path = public as $$
declare tn text; no text;
begin
  no := coalesce(new.booking_no, 'your booking');
  -- technician accepted
  if old.technician_id is null and new.technician_id is not null and new.status = 'accepted' then
    select name into tn from public.profiles where id = new.technician_id;
    perform public.push_user(new.customer_id, 'Technician assigned',
      coalesce(tn, 'A technician') || ' accepted ' || no || '. You can chat with them now.');
  -- technician cancelled: the job goes back to the pool
  elsif old.technician_id is not null and new.technician_id is null and new.status = 'pending' then
    perform public.push_user(new.customer_id, 'Finding another technician',
      'Your technician could not make it for ' || no || '. We are finding someone else.');
  -- customer cancelled
  elsif new.status = 'cancelled' and old.status is distinct from 'cancelled' and new.technician_id is not null then
    perform public.push_user(new.technician_id, 'Booking cancelled', no || ' was cancelled by the customer.');
  -- job steps
  elsif new.job_stage is distinct from old.job_stage then
    if new.job_stage = 'arrived' then
      perform public.push_user(new.customer_id, 'Technician arrived', 'Your technician has reached you for ' || no || '.');
    elsif new.job_stage = 'working' and old.job_stage = 'arrived' then
      perform public.push_user(new.customer_id, 'Work started', 'Your technician has started the job ' || no || '.');
    elsif new.job_stage = 'parts_review' then
      perform public.push_user(new.customer_id, 'Parts need your approval', 'Please check the parts and charges for ' || no || '.');
    elsif new.job_stage = 'payment_due' then
      perform public.push_user(new.customer_id, 'Work finished', 'Please choose how you would like to pay for ' || no || '.');
    elsif new.job_stage = 'payment_check' then
      perform public.push_user(new.technician_id, 'Customer chose how to pay', 'Please confirm the payment for ' || no || '.');
    elsif new.job_stage = 'end_otp' then
      perform public.push_user(new.customer_id, 'Share the finish code', 'Give your technician the finish code for ' || no || '.');
    end if;
  end if;
  -- completed
  if new.status = 'completed' and old.status is distinct from 'completed' then
    perform public.push_user(new.customer_id, 'Job completed', 'Thank you! Please rate your technician for ' || no || '.');
  end if;
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists zz_push_booking_events on public.bookings;
create trigger zz_push_booking_events after update on public.bookings
  for each row execute function public.trg_push_booking_events();

-- 3. New offer goes to every customer
create or replace function public.trg_push_offer() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.active and current_date between new.date_from and new.date_to then
    perform public.push_role('customer', 'New offer: ' || new.title,
      'Use code ' || upper(new.code) || ' at checkout.');
  end if;
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists zz_push_offer on public.offers;
create trigger zz_push_offer after insert on public.offers
  for each row execute function public.trg_push_offer();

-- 4. Support replied to a ticket
create or replace function public.trg_push_support_reply() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid; tno bigint;
begin
  if new.sender_role = 'user' then return new; end if;
  select created_by, ticket_no into owner, tno from public.support_tickets where id = new.ticket_id;
  if owner is not null then
    perform public.push_user(owner, 'Fixeaze Support replied', 'Ticket #' || tno || ': ' || new.body);
  end if;
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists zz_push_support_reply on public.support_messages;
create trigger zz_push_support_reply after insert on public.support_messages
  for each row execute function public.trg_push_support_reply();
