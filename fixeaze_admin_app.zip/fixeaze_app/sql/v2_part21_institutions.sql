-- Part 21: Institution (company) accounts. An owner adds employee technicians;
-- jobs of employees are paid to the institution. Safe to run more than once.
-- Needs parts 11 and 20.

create table if not exists public.institutions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id) on delete cascade,
  name text not null,
  address text,
  pincode text,
  gst text,
  bank_holder_name text,
  bank_name text,
  bank_account_no text,
  bank_ifsc text,
  upi_id text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.institutions enable row level security;
grant select on public.institutions to authenticated;

alter table public.technician_profiles add column if not exists institution_id uuid references public.institutions(id) on delete set null;
create index if not exists technician_profiles_institution on public.technician_profiles(institution_id);

-- ---------- helpers (security definer so policies never loop) ----------
create or replace function public.inst_owner_of(p_tech uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.technician_profiles tp
      join public.institutions i on i.id = tp.institution_id
     where tp.id = p_tech and i.owner_id = auth.uid());
$$;

create or replace function public.my_institution_id()
returns uuid language sql stable security definer set search_path = public as $$
  select institution_id from public.technician_profiles where id = auth.uid();
$$;

-- who gets the money for a technician's job: the institution owner, or the technician
create or replace function public.payee_of(p_tech uuid)
returns uuid language sql stable security definer set search_path = public as $$
  select coalesce(
    (select i.owner_id from public.technician_profiles tp
       join public.institutions i on i.id = tp.institution_id where tp.id = p_tech),
    p_tech);
$$;

-- ---------- who can read what ----------
drop policy if exists "inst read" on public.institutions;
create policy "inst read" on public.institutions for select to authenticated
  using (owner_id = auth.uid() or public.is_admin() or id = public.my_institution_id());

drop policy if exists "inst owner reads employee profiles" on public.profiles;
create policy "inst owner reads employee profiles" on public.profiles for select to authenticated
  using (public.inst_owner_of(id));

drop policy if exists "inst owner reads employee tech profiles" on public.technician_profiles;
create policy "inst owner reads employee tech profiles" on public.technician_profiles for select to authenticated
  using (public.inst_owner_of(id));

drop policy if exists "inst owner reads employee services" on public.technician_services;
create policy "inst owner reads employee services" on public.technician_services for select to authenticated
  using (public.inst_owner_of(technician_id));

drop policy if exists "inst owner reads employee bookings" on public.bookings;
create policy "inst owner reads employee bookings" on public.bookings for select to authenticated
  using (public.inst_owner_of(technician_id));

drop policy if exists "inst owner reads employee payments" on public.technician_payments;
create policy "inst owner reads employee payments" on public.technician_payments for select to authenticated
  using (public.inst_owner_of(technician_id));

drop policy if exists "inst owner reads employee dues" on public.cash_dues;
create policy "inst owner reads employee dues" on public.cash_dues for select to authenticated
  using (public.inst_owner_of(technician_id));

-- ---------- owner registers the institution (after creating the account) ----------
create or replace function public.institution_register(
  p_name text, p_address text, p_pincode text, p_gst text,
  p_holder text, p_bank text, p_account text, p_ifsc text, p_upi text)
returns uuid language plpgsql security definer set search_path = public as $$
declare iid uuid;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;
  if coalesce(trim(p_name), '') = '' then raise exception 'Enter the institution name'; end if;
  if exists (select 1 from public.institutions where owner_id = auth.uid()) then
    raise exception 'This account already has an institution';
  end if;
  insert into public.institutions (owner_id, name, address, pincode, gst, bank_holder_name, bank_name,
                                   bank_account_no, bank_ifsc, upi_id)
  values (auth.uid(), trim(p_name), nullif(trim(coalesce(p_address, '')), ''), nullif(trim(coalesce(p_pincode, '')), ''),
          nullif(trim(coalesce(p_gst, '')), ''), trim(coalesce(p_holder, '')), trim(coalesce(p_bank, '')),
          trim(coalesce(p_account, '')), upper(trim(coalesce(p_ifsc, ''))), nullif(trim(coalesce(p_upi, '')), ''))
  returning id into iid;
  begin
    perform public.push_admins('approval', 'Institution waiting for approval', trim(p_name));
  exception when others then null;
  end;
  return iid;
end $$;
grant execute on function public.institution_register(text, text, text, text, text, text, text, text, text) to authenticated;

-- owner edits name / address / bank details
create or replace function public.institution_update(
  p_name text, p_address text, p_holder text, p_bank text, p_account text, p_ifsc text, p_upi text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if coalesce(trim(p_name), '') = '' then raise exception 'Enter the institution name'; end if;
  update public.institutions
     set name = trim(p_name), address = nullif(trim(coalesce(p_address, '')), ''),
         bank_holder_name = trim(coalesce(p_holder, '')), bank_name = trim(coalesce(p_bank, '')),
         bank_account_no = trim(coalesce(p_account, '')), bank_ifsc = upper(trim(coalesce(p_ifsc, ''))),
         upi_id = nullif(trim(coalesce(p_upi, '')), ''), updated_at = now()
   where owner_id = auth.uid();
  if not found then raise exception 'No institution on this account'; end if;
end $$;
grant execute on function public.institution_update(text, text, text, text, text, text, text) to authenticated;

-- ---------- owner creates an employee login ----------
create or replace function public.institution_add_employee(
  p_name text, p_email text, p_phone text, p_password text, p_pincode text,
  p_lat double precision, p_lng double precision, p_rate numeric, p_experience int, p_services uuid[])
returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare inst public.institutions; uid uuid := gen_random_uuid(); e text := lower(trim(coalesce(p_email, '')));
begin
  select * into inst from public.institutions where owner_id = auth.uid();
  if not found then raise exception 'You do not have an institution account'; end if;
  if inst.status = 'suspended' then raise exception 'This institution is suspended'; end if;
  if coalesce(trim(p_name), '') = '' or length(trim(p_name)) < 3 then raise exception 'Enter the employee full name'; end if;
  if e !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Enter a valid email'; end if;
  if length(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')) < 10 then raise exception 'Enter a valid contact number'; end if;
  if length(coalesce(p_password, '')) < 6 then raise exception 'Password must be at least 6 characters'; end if;
  if p_services is null or array_length(p_services, 1) is null then raise exception 'Select at least one service'; end if;
  if exists (select 1 from auth.users where lower(email) = e) then raise exception 'This email is already registered'; end if;

  insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
                          raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
                          confirmation_token, recovery_token, email_change_token_new, email_change,
                          email_change_token_current, phone_change, phone_change_token, reauthentication_token)
  values ('00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated', e,
          extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
          '{"provider":"email","providers":["email"]}'::jsonb,
          jsonb_build_object('role', 'technician', 'name', trim(p_name), 'phone', trim(p_phone),
                             'pincode', p_pincode, 'lat', p_lat, 'lng', p_lng),
          now(), now(), '', '', '', '', '', '', '', '');

  insert into auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
  values (uid::text, uid, jsonb_build_object('sub', uid::text, 'email', e, 'email_verified', true, 'phone_verified', false),
          'email', now(), now(), now());

  -- the sign-up trigger made the profile; employees of an approved institution are approved
  alter table public.profiles disable trigger user;
  update public.profiles set approved = (inst.status = 'approved') where id = uid;
  alter table public.profiles enable trigger user;

  insert into public.technician_profiles (id, name, hourly_rate, experience_years, shift_start, shift_end, institution_id)
  values (uid, trim(p_name), coalesce(p_rate, 300), coalesce(p_experience, 0), '09:00', '18:00', inst.id)
  on conflict (id) do update set institution_id = excluded.institution_id;

  insert into public.technician_services (technician_id, service_id)
  select uid, s from unnest(p_services) as s on conflict do nothing;
  return uid;
end $$;
grant execute on function public.institution_add_employee(text, text, text, text, text, double precision, double precision, numeric, int, uuid[]) to authenticated;

create or replace function public.institution_employee_pause(p_employee uuid, p_paused boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.inst_owner_of(p_employee) then raise exception 'Not your employee'; end if;
  update public.technician_profiles set paused = p_paused, paused_at = case when p_paused then now() else null end
   where id = p_employee;
end $$;
grant execute on function public.institution_employee_pause(uuid, boolean) to authenticated;

create or replace function public.institution_employee_password(p_employee uuid, p_password text)
returns void language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.inst_owner_of(p_employee) then raise exception 'Not your employee'; end if;
  if length(coalesce(p_password, '')) < 6 then raise exception 'Password must be at least 6 characters'; end if;
  update auth.users set encrypted_password = extensions.crypt(p_password, extensions.gen_salt('bf')), updated_at = now()
   where id = p_employee;
end $$;
grant execute on function public.institution_employee_password(uuid, text) to authenticated;

-- ---------- admin approves / suspends an institution ----------
create or replace function public.admin_set_institution_status(p_institution uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
declare owner uuid;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if p_status not in ('pending', 'approved', 'suspended') then raise exception 'Bad status'; end if;
  update public.institutions set status = p_status, updated_at = now() where id = p_institution
  returning owner_id into owner;
  if owner is null then raise exception 'Institution not found'; end if;
  update public.profiles set approved = (p_status = 'approved')
   where id in (select id from public.technician_profiles where institution_id = p_institution);
  insert into public.technician_notifications (technician_id, kind, title, body)
  values (owner, 'general',
          case when p_status = 'approved' then 'Institution approved' else 'Institution ' || p_status end,
          case when p_status = 'approved' then 'Your institution is approved. Your employees can now take jobs.'
               else 'Your institution status is now ' || p_status || '.' end);
end $$;
grant execute on function public.admin_set_institution_status(uuid, text) to authenticated;

-- ---------- payouts go to the institution (replaces the part 20 versions) ----------
create or replace function public.admin_schedule_payout(p_technician uuid, p_from timestamptz, p_to timestamptz, p_pay_on date)
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if p_pay_on is null then raise exception 'Choose a payment date'; end if;
  perform set_config('fixeaze.bulk', '1', true);
  for r in
    select public.payee_of(technician_id) as payee, count(*) as jobs, sum(amount) as total
      from public.technician_payments
     where status in ('pending', 'processing') and amount > 0
       and created_at >= p_from and created_at < p_to
       and (p_technician is null or public.payee_of(technician_id) = p_technician)
     group by 1
  loop
    update public.technician_payments set pay_on = p_pay_on
     where public.payee_of(technician_id) = r.payee and status in ('pending', 'processing') and amount > 0
       and created_at >= p_from and created_at < p_to;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (r.payee, 'payment', 'Payout date set',
            'Your payout of Rs ' || r.total || ' for ' || r.jobs || ' job(s) will be paid on '
            || to_char(p_pay_on, 'DD Mon YYYY') || '.');
    n := n + 1;
  end loop;
  return n;
end $$;
grant execute on function public.admin_schedule_payout(uuid, timestamptz, timestamptz, date) to authenticated;

create or replace function public.admin_pay_period(p_technician uuid, p_from timestamptz, p_to timestamptz,
                                                   p_reference text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare jobs int; total numeric;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select count(*), coalesce(sum(amount), 0) into jobs, total
    from public.technician_payments
   where public.payee_of(technician_id) = p_technician and status in ('pending', 'processing')
     and created_at >= p_from and created_at < p_to;
  if jobs = 0 then raise exception 'Nothing is waiting to be paid in this period'; end if;

  perform set_config('fixeaze.bulk', '1', true);
  update public.technician_payments
     set status = 'paid', paid_at = now(),
         reference = nullif(trim(coalesce(p_reference, '')), ''),
         note = coalesce(nullif(trim(coalesce(p_note, '')), ''), note)
   where public.payee_of(technician_id) = p_technician and status in ('pending', 'processing')
     and created_at >= p_from and created_at < p_to;

  insert into public.technician_payouts (technician_id, period_from, period_to, jobs, amount, reference, note, paid_by)
  values (p_technician, p_from, p_to, jobs, total, nullif(trim(coalesce(p_reference, '')), ''),
          nullif(trim(coalesce(p_note, '')), ''), auth.uid());

  insert into public.technician_notifications (technician_id, kind, title, body)
  values (p_technician, 'payment', 'Payment received',
          'Fixeaze has paid Rs ' || total || ' for ' || jobs || ' job(s).'
          || coalesce(' Reference: ' || nullif(trim(coalesce(p_reference, '')), '') || '.', ''));
end $$;
grant execute on function public.admin_pay_period(uuid, timestamptz, timestamptz, text, text) to authenticated;
