-- Fixeaze part 36: bookings by service > product > issue type, matching, 30-minute hold
alter table public.bookings add column if not exists product_id uuid references public.catalog_products(id) on delete set null;
alter table public.bookings add column if not exists item_id uuid references public.product_services(id) on delete set null;
create index if not exists bookings_item_idx on public.bookings(item_id) where status = 'pending';

-- Can this technician take work for this item at this place?
create or replace function public.item_eligible(p_tech uuid, p_item uuid, p_lat double precision, p_lng double precision)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    join public.technician_profiles tp on tp.id = p.id
    join public.technician_prices pr on pr.technician_id = p.id and pr.item_id = p_item and pr.enabled
    where p.id = p_tech and p.role = 'technician' and p.approved = true
      and tp.paused = false
      and (p.blocked_until is null or p.blocked_until < now())
      and p.lat is not null and p.lng is not null and p_lat is not null and p_lng is not null
      and public.km_between(p.lat, p.lng, p_lat, p_lng) <= 10
      and not exists (select 1 from public.technician_schedule s
                      where s.technician_id = p.id and s.kind = 'leave'
                        and s.day = (now() at time zone 'Asia/Kolkata')::date)
  );
$$;

-- Technicians the customer can pick for one item near a pincode
create or replace function public.technicians_for_item(p_item uuid, p_lat double precision, p_lng double precision, p_km double precision default 10)
returns table (id uuid, name text, price numeric, rating numeric, jobs_done int, experience int, avatar_url text, lat double precision, lng double precision, km double precision)
language sql stable security definer set search_path = public as $$
  select p.id, coalesce(nullif(tp.name,''), p.name)::text, pr.price, tp.rating::numeric, tp.jobs_done::int,
         coalesce(tp.experience_years,0)::int, p.avatar_url, p.lat, p.lng,
         public.km_between(p.lat, p.lng, p_lat, p_lng)
  from public.profiles p
  join public.technician_profiles tp on tp.id = p.id
  join public.technician_prices pr on pr.technician_id = p.id and pr.item_id = p_item and pr.enabled
  where public.item_eligible(p.id, p_item, p_lat, p_lng)
    and public.km_between(p.lat, p.lng, p_lat, p_lng) <= least(p_km, 10)
  order by public.km_between(p.lat, p.lng, p_lat, p_lng)
  limit 40;
$$;
grant execute on function public.technicians_for_item(uuid, double precision, double precision, double precision) to anon, authenticated;
grant execute on function public.item_eligible(uuid, uuid, double precision, double precision) to authenticated;

-- Is this open booking meant for me? (me = caller)
create or replace function public.job_visible(p_item uuid, p_pref uuid, p_created timestamptz, p_lat double precision, p_lng double precision)
returns boolean language sql stable security definer set search_path = public as $$
  select case
    when p_item is null then true
    when not public.item_eligible(auth.uid(), p_item, p_lat, p_lng) then false
    when p_pref is null then true
    when p_pref = auth.uid() then true
    else now() >= p_created + interval '30 minutes'
  end;
$$;
grant execute on function public.job_visible(uuid, uuid, timestamptz, double precision, double precision) to authenticated;

drop policy if exists "bookings item visibility" on public.bookings;
create policy "bookings item visibility" on public.bookings as restrictive for select to authenticated
  using (
    customer_id = auth.uid() or technician_id is not null or status <> 'pending'
    or item_id is null or public.is_admin()
    or public.job_visible(item_id, preferred_technician_id, created_at, lat, lng)
  );

-- On insert: fill service/product from the item, fix the price shown, check the chosen technician
create or replace function public.item_booking_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare pr numeric; lo numeric; hi numeric; pid uuid; sid uuid;
begin
  if new.item_id is null then return new; end if;
  select ps.product_id, cp.service_id into pid, sid
  from public.product_services ps join public.catalog_products cp on cp.id = ps.product_id
  where ps.id = new.item_id and ps.active and cp.active;
  if pid is null then raise exception 'This service is not available right now'; end if;
  new.product_id := pid; new.service_id := sid;
  new.booking_type := 'hourly'; new.hours := null;
  if new.preferred_technician_id is not null then
    if not public.item_eligible(new.preferred_technician_id, new.item_id, new.lat, new.lng) then
      raise exception 'This technician is not available for this service. Please choose again.';
    end if;
    select price into pr from public.technician_prices where technician_id = new.preferred_technician_id and item_id = new.item_id;
    new.estimated_min := pr; new.estimated_max := pr;
  else
    select min(x.price), max(x.price) into lo, hi
    from public.technician_prices x
    where x.item_id = new.item_id and x.enabled and public.item_eligible(x.technician_id, new.item_id, new.lat, new.lng);
    if lo is null then raise exception 'No technician is available for this service in your area yet'; end if;
    new.estimated_min := lo; new.estimated_max := hi;
  end if;
  return new;
end $$;
drop trigger if exists aa_item_booking_insert on public.bookings;
create trigger aa_item_booking_insert before insert on public.bookings
  for each row execute function public.item_booking_insert();

-- Tell the right technicians about a new booking
create or replace function public.item_booking_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare t uuid; n text;
begin
  if new.item_id is null then return new; end if;
  select name into n from public.product_services where id = new.item_id;
  if new.preferred_technician_id is not null then
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (new.preferred_technician_id, 'booking', 'New booking for you',
            coalesce(n,'Job') || ' - please accept within 30 minutes.');
  else
    for t in select x.technician_id from public.technician_prices x
             where x.item_id = new.item_id and x.enabled
               and public.item_eligible(x.technician_id, new.item_id, new.lat, new.lng) limit 60 loop
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (t, 'booking', 'New job near you', coalesce(n,'Job') || ' - ' || coalesce(new.address,''));
    end loop;
  end if;
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_item_booking_notify on public.bookings;
create trigger trg_item_booking_notify after insert on public.bookings
  for each row execute function public.item_booking_notify();

-- On accept: technician must match, and the job takes that technician's charge
create or replace function public.item_booking_accept() returns trigger
language plpgsql security definer set search_path = public as $$
declare pr numeric;
begin
  if new.item_id is null then return new; end if;
  if not (old.status = 'pending' and old.technician_id is null and new.status = 'accepted' and new.technician_id is not null) then
    return new;
  end if;
  if not public.is_admin() and new.technician_id = auth.uid()
     and coalesce(current_setting('fixeaze.rpc', true), '') <> '1' then
    if not public.job_visible(old.item_id, old.preferred_technician_id, old.created_at, old.lat, old.lng) then
      raise exception 'This job is reserved for another technician or is not in your services';
    end if;
  end if;
  select price into pr from public.technician_prices
   where technician_id = new.technician_id and item_id = new.item_id and enabled;
  new.price := coalesce(pr, old.estimated_min);
  return new;
end $$;
drop trigger if exists zz_item_booking_accept on public.bookings;
create trigger zz_item_booking_accept before update on public.bookings
  for each row execute function public.item_booking_accept();
