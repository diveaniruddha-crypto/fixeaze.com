-- PIECE 1: status text, media columns
alter table public.profiles add column if not exists status_text text;
alter table public.admin_chat add column if not exists media_url text;
alter table public.admin_chat add column if not exists media_type text;
alter table public.admin_chat add column if not exists media_name text;
alter table public.tech_chat add column if not exists media_url text;
alter table public.tech_chat add column if not exists media_type text;
alter table public.tech_chat add column if not exists media_name text;

create or replace function public.set_my_status(p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform set_config('fixeaze.rpc', '1', true);
  update public.profiles set status_text = nullif(left(trim(coalesce(p_status, '')), 80), '') where id = auth.uid();
end $$;
grant execute on function public.set_my_status(text) to authenticated;

-- PIECE 2: delivered / seen
alter table public.chat_reads add column if not exists delivered_at timestamptz;
alter table public.chat_reads alter column read_at drop not null;
alter table public.chat_reads alter column read_at drop default;

drop policy if exists "reads admin all" on public.chat_reads;
create policy "reads admin all" on public.chat_reads for select to authenticated
  using (public.is_admin());
drop policy if exists "reads tech thread" on public.chat_reads;
create policy "reads tech thread" on public.chat_reads for select to authenticated
  using (thread = 't:' || auth.uid()::text);
