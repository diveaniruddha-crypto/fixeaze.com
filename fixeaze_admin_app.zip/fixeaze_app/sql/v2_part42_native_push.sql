-- Fixeaze part 42: phone notifications for technicians (Firebase Cloud Messaging, free).
-- Run once in Supabase > SQL Editor. Safe to run twice.
-- Also deploy the Edge Function "fcm" (supabase_functions/fcm.ts).

create table if not exists public.device_tokens (
  token text primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  platform text,
  updated_at timestamptz not null default now()
);
create index if not exists device_tokens_user_idx on public.device_tokens (user_id);
alter table public.device_tokens enable row level security;
revoke all on public.device_tokens from anon, authenticated;

-- The app saves its phone token here after login
create or replace function public.register_device_token(p_token text, p_platform text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or coalesce(trim(p_token), '') = '' then return; end if;
  insert into public.device_tokens (token, user_id, platform)
  values (trim(p_token), auth.uid(), p_platform)
  on conflict (token) do update set user_id = auth.uid(), platform = excluded.platform, updated_at = now();
end $$;
grant execute on function public.register_device_token(text, text) to authenticated;

-- Logout: stop sending to this phone
create or replace function public.unregister_device_token(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from public.device_tokens where token = trim(p_token) and user_id = auth.uid();
end $$;
grant execute on function public.unregister_device_token(text) to authenticated;

-- Firebase app settings (not secret). Fill these four in with the SQL from the guide.
insert into public.push_config (key, value) values
  ('fcm_url', 'https://yujmqhihsfpnyiiluxcy.supabase.co/functions/v1/fcm')
on conflict (key) do nothing;

create or replace function public.fcm_client_config()
returns jsonb language sql stable security definer set search_path = public as $$
  select case when count(*) filter (where key in ('fcm_api_key','fcm_app_id','fcm_sender_id','fcm_project_id')) = 4
    then jsonb_build_object(
      'apiKey',    max(value) filter (where key = 'fcm_api_key'),
      'appId',     max(value) filter (where key = 'fcm_app_id'),
      'senderId',  max(value) filter (where key = 'fcm_sender_id'),
      'projectId', max(value) filter (where key = 'fcm_project_id'))
    else null end
  from public.push_config;
$$;
grant execute on function public.fcm_client_config() to anon, authenticated;

-- Send one notification to one user's phones (never blocks the thing that triggered it)
create or replace function public.push_user(p_user uuid, p_title text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
declare u text; sec text;
begin
  select value into u from public.push_config where key = 'fcm_url';
  select value into sec from public.push_config where key = 'secret';
  if u is null or sec is null then return; end if;
  if not exists (select 1 from public.device_tokens where user_id = p_user) then return; end if;
  perform net.http_post(
    url := u,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', sec),
    body := jsonb_build_object('user_id', p_user, 'title', p_title, 'body', left(coalesce(p_body, ''), 200)));
exception when others then
  null;
end $$;
revoke execute on function public.push_user(uuid, text, text) from public, anon, authenticated;

-- Every technician notification (new job, payment, ...) also goes to their phone
create or replace function public.trg_push_tech_notification()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.push_user(new.technician_id, new.title, new.body);
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists zz_push_tech_notification on public.technician_notifications;
create trigger zz_push_tech_notification after insert on public.technician_notifications
  for each row execute function public.trg_push_tech_notification();
