-- Part 19: remember people whose account was deleted (for the Areas page "left us").
-- Safe to run more than once.

create table if not exists public.departed_users (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  role text,
  name text,
  phone text,
  pincode text,
  joined_at timestamptz,
  created_at timestamptz not null default now()   -- the day they left
);
alter table public.departed_users enable row level security;
drop policy if exists "departed admin" on public.departed_users;
create policy "departed admin" on public.departed_users for select to authenticated using (public.is_admin());
grant select on public.departed_users to authenticated;

create or replace function public.trg_departed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.role in ('customer', 'technician') then
    insert into public.departed_users (user_id, role, name, phone, pincode, joined_at)
    values (old.id, old.role, old.name, old.phone, old.pincode, old.created_at);
  end if;
  return old;
exception when others then
  return old;
end $$;
drop trigger if exists trg_departed on public.profiles;
create trigger trg_departed before delete on public.profiles
  for each row execute function public.trg_departed();
