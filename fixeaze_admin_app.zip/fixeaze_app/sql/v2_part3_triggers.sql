create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare r text; m jsonb;
begin
  m := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  r := coalesce(m->>'role', 'customer');
  if r not in ('customer','technician') then r := 'customer'; end if;
  insert into public.profiles (id, name, email, phone, role, approved, pincode, lat, lng)
  values (new.id, m->>'name', new.email, m->>'phone', r, r = 'customer',
          m->>'pincode',
          nullif(m->>'lat', '')::double precision,
          nullif(m->>'lng', '')::double precision);
  return new;
end $$;

create or replace function public.bookings_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare skip text[] := array['status','technician_id','completion_photos','updated_at'];
begin
  if public.is_admin() then return new; end if;

  if (to_jsonb(new) - skip) <> (to_jsonb(old) - skip) then
    raise exception 'Not allowed to change these booking fields';
  end if;

  if auth.uid() = old.customer_id then
    if old.status in ('pending','accepted') and new.status = 'cancelled'
       and new.technician_id is not distinct from old.technician_id
       and new.completion_photos is not distinct from old.completion_photos then
      return new;
    end if;
    raise exception 'Customers can only cancel a booking';
  end if;

  if old.status = 'pending' and old.technician_id is null
     and new.status = 'accepted' and new.technician_id = auth.uid()
     and public.can_take_job(old.service_id, old.lat, old.lng) then
    return new;
  end if;

  if auth.uid() = old.technician_id and new.technician_id = old.technician_id
     and ((old.status = 'accepted' and new.status = 'in_progress')
       or (old.status = 'in_progress' and new.status = 'completed')) then
    return new;
  end if;

  raise exception 'Not allowed';
end $$;

create or replace function public.tech_profiles_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or pg_trigger_depth() > 1 then return new; end if;
  if tg_op = 'INSERT' then
    new.rating := 0;
    new.jobs_done := 0;
  else
    new.rating := old.rating;
    new.jobs_done := old.jobs_done;
  end if;
  return new;
end $$;

drop trigger if exists trg_tech_profiles_guard on public.technician_profiles;
create trigger trg_tech_profiles_guard before insert or update on public.technician_profiles
  for each row execute function public.tech_profiles_guard();
