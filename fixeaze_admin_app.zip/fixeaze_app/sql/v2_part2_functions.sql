create or replace function public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
returns double precision language sql immutable as $$
  select 6371 * acos(least(1, greatest(-1,
    cos(radians(lat1)) * cos(radians(lat2)) * cos(radians(lng2) - radians(lng1))
    + sin(radians(lat1)) * sin(radians(lat2)))));
$$;

create or replace function public.is_technician_role()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'technician');
$$;

create or replace function public.is_approved_profile(p_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = p_id and role = 'technician' and approved = true);
$$;

create or replace function public.can_take_job(p_service uuid, p_lat double precision, p_lng double precision)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'technician' and p.approved = true
      and p.lat is not null and p.lng is not null
      and p_lat is not null and p_lng is not null
      and public.km_between(p.lat, p.lng, p_lat, p_lng) <= 10
      and exists (select 1 from public.technician_services ts
                  where ts.technician_id = p.id and ts.service_id = p_service)
  );
$$;

create or replace function public.can_chat(p_booking uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.bookings b
    where b.id = p_booking and b.technician_id is not null
      and b.status in ('accepted','in_progress')
      and (b.customer_id = auth.uid() or b.technician_id = auth.uid())
  );
$$;

create or replace function public.is_booking_party(p_booking uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.bookings b
    where b.id = p_booking and (b.customer_id = auth.uid() or b.technician_id = auth.uid())
  );
$$;

create or replace function public.technicians_nearby(p_lat double precision, p_lng double precision, p_service uuid default null, p_km double precision default 10)
returns table (cnt int, min_rate numeric, max_rate numeric)
language sql stable security definer set search_path = public as $$
  select count(*)::int, min(tp.hourly_rate), max(tp.hourly_rate)
  from public.profiles p
  join public.technician_profiles tp on tp.id = p.id
  where p.role = 'technician' and p.approved = true
    and p.lat is not null and p.lng is not null
    and public.km_between(p.lat, p.lng, p_lat, p_lng) <= p_km
    and (p_service is null or exists (
      select 1 from public.technician_services ts
      where ts.technician_id = p.id and ts.service_id = p_service));
$$;
