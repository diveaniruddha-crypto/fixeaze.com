-- Fixeaze part 44: admin can send a phone notification to all customers, all technicians or everyone.
-- Needs parts 42 and 43. Run once in Supabase > SQL Editor. Safe to run twice.
create or replace function public.admin_broadcast(p_target text, p_title text, p_body text)
returns int language plpgsql security definer set search_path = public as $$
declare n int := 0;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if p_target not in ('customer', 'technician', 'all') then raise exception 'Choose who to send to'; end if;
  if coalesce(trim(p_title), '') = '' or coalesce(trim(p_body), '') = '' then
    raise exception 'Write a title and a message';
  end if;
  if p_target in ('customer', 'all') then
    perform public.push_role('customer', left(trim(p_title), 60), left(trim(p_body), 200));
    n := n + (select count(*) from public.device_tokens d join public.profiles p on p.id = d.user_id where p.role = 'customer');
  end if;
  if p_target in ('technician', 'all') then
    perform public.push_role('technician', left(trim(p_title), 60), left(trim(p_body), 200));
    n := n + (select count(*) from public.device_tokens d join public.profiles p on p.id = d.user_id where p.role = 'technician');
  end if;
  return n;
end $$;
revoke execute on function public.admin_broadcast(text, text, text) from public, anon;
grant execute on function public.admin_broadcast(text, text, text) to authenticated;
