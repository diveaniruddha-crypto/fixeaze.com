alter table public.profiles add column if not exists pincode text;
alter table public.profiles add column if not exists lat double precision;
alter table public.profiles add column if not exists lng double precision;

alter table public.services add column if not exists inspection_fee numeric(10,2) not null default 199;

alter table public.technician_profiles add column if not exists hourly_rate numeric(10,2);
alter table public.technician_profiles add column if not exists shift_start time;
alter table public.technician_profiles add column if not exists shift_end time;

alter table public.bookings add column if not exists booking_type text not null default 'hourly' check (booking_type in ('hourly','inspection'));
alter table public.bookings add column if not exists hours int;
alter table public.bookings add column if not exists pincode text;
alter table public.bookings add column if not exists lat double precision;
alter table public.bookings add column if not exists lng double precision;
alter table public.bookings add column if not exists estimated_min numeric(10,2);
alter table public.bookings add column if not exists estimated_max numeric(10,2);

create table if not exists public.technician_services (
  technician_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete cascade,
  primary key (technician_id, service_id)
);

create table if not exists public.technician_kyc (
  id uuid primary key references public.profiles(id) on delete cascade,
  aadhaar_last4 text not null,
  aadhaar_name text not null,
  aadhaar_image_path text not null,
  shift_confirmed boolean not null default false,
  consent boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index if not exists messages_booking_idx on public.messages (booking_id, created_at);

create table if not exists public.maintenance_tips (
  id uuid primary key default gen_random_uuid(),
  frequency text not null check (frequency in ('daily','monthly')),
  product text not null,
  title text not null,
  body text not null,
  sort int not null default 0,
  active boolean not null default true
);
