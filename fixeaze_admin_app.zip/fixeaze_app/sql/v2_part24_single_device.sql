-- Part 24: customers and technicians can be logged in on only ONE device at a time.
-- Admins can use many devices. Safe to run more than once.

create table if not exists public.active_sessions (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  session_id text not null,
  updated_at timestamptz not null default now()
);
alter table public.active_sessions enable row level security;
revoke all on public.active_sessions from anon, authenticated;

-- called right after a login: this device becomes the active one
create or replace function public.claim_session()
returns void language plpgsql security definer set search_path = public as $$
declare sid text := auth.jwt() ->> 'session_id';
begin
  if auth.uid() is null or sid is null or public.is_admin() then return; end if;
  insert into public.active_sessions (user_id, session_id) values (auth.uid(), sid)
  on conflict (user_id) do update set session_id = excluded.session_id, updated_at = now();
end $$;
grant execute on function public.claim_session() to authenticated;

-- true while this device is still the active one
create or replace function public.session_ok()
returns boolean language plpgsql stable security definer set search_path = public as $$
declare sid text := auth.jwt() ->> 'session_id'; cur text;
begin
  if auth.uid() is null then return false; end if;
  if sid is null or public.is_admin() then return true; end if;
  select session_id into cur from public.active_sessions where user_id = auth.uid();
  if cur is null then return true; end if;
  return cur = sid;
end $$;
grant execute on function public.session_ok() to authenticated;
