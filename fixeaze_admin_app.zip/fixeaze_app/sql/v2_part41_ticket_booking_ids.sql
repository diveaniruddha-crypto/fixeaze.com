-- Fixeaze part 41: same booking number (FX00...) everywhere, and tickets for cancelled jobs.
-- Run once in Supabase > SQL Editor. Safe to run twice.

-- Jobs this technician cancelled (the booking goes back to the pool, so they cannot read it any more)
create or replace function public.my_cancelled_jobs()
returns table (booking_id uuid, booking_no text, service_name text, scheduled_at timestamptz,
               address text, reason text, cancelled_at timestamptz)
language sql stable security definer set search_path = public as $$
  select c.booking_id, b.booking_no, s.name::text, b.scheduled_at, b.address, c.reason, c.created_at
  from public.cancellations c
  join public.bookings b on b.id = c.booking_id
  left join public.services s on s.id = b.service_id
  where c.by_user = auth.uid() and c.by_role = 'technician'
  order by c.created_at desc
  limit 50;
$$;
grant execute on function public.my_cancelled_jobs() to authenticated;

-- Booking numbers for tickets (only for bookings the caller is part of)
create or replace function public.booking_numbers(p_ids uuid[])
returns table (id uuid, booking_no text)
language sql stable security definer set search_path = public as $$
  select b.id, b.booking_no
  from public.bookings b
  where b.id = any (p_ids)
    and (b.customer_id = auth.uid() or b.technician_id = auth.uid() or public.is_admin()
         or exists (select 1 from public.cancellations c where c.booking_id = b.id and c.by_user = auth.uid())
         or exists (select 1 from public.support_tickets t where t.booking_id = b.id and t.created_by = auth.uid()));
$$;
grant execute on function public.booking_numbers(uuid[]) to authenticated;

-- A technician may raise a ticket about a job they cancelled
create or replace function public.support_create(p_booking uuid, p_subject text, p_body text)
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); r text; tid uuid;
begin
  if uid is null then raise exception 'Please log in first'; end if;
  if coalesce(trim(p_subject), '') = '' or coalesce(trim(p_body), '') = '' then
    raise exception 'Write a subject and describe your problem';
  end if;
  select role into r from public.profiles where id = uid;
  if p_booking is not null and not exists (
      select 1 from public.bookings b where b.id = p_booking
        and (b.customer_id = uid or b.technician_id = uid
             or exists (select 1 from public.cancellations c where c.booking_id = b.id and c.by_user = uid))) then
    raise exception 'That booking is not yours';
  end if;
  insert into public.support_tickets (created_by, role, booking_id, subject)
  values (uid, coalesce(r, 'customer'), p_booking, trim(p_subject)) returning id into tid;
  insert into public.support_messages (ticket_id, sender_id, sender_role, body)
  values (tid, uid, 'user', trim(p_body));
  return tid;
end $$;
grant execute on function public.support_create(uuid, text, text) to authenticated;
