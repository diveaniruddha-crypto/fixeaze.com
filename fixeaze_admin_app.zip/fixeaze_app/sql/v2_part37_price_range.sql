-- Fixeaze part 37: price range per service (Repairing, Servicing...)
alter table public.product_services add column if not exists price_min numeric(10,2);
alter table public.product_services add column if not exists price_max numeric(10,2);
alter table public.product_services drop constraint if exists product_services_range_chk;
alter table public.product_services add constraint product_services_range_chk
  check (price_min is null or price_max is null or price_min <= price_max);

-- Technician charge must stay inside the range the admin set
create or replace function public.check_price_range() returns trigger
language plpgsql security definer set search_path = public as $$
declare lo numeric; hi numeric;
begin
  if new.enabled is not true then return new; end if;
  select price_min, price_max into lo, hi from public.product_services where id = new.item_id;
  if lo is not null and new.price < lo then
    raise exception 'Charge must be at least Rs % for this service', lo;
  end if;
  if hi is not null and new.price > hi then
    raise exception 'Charge can be at most Rs % for this service', hi;
  end if;
  return new;
end $$;
drop trigger if exists trg_check_price_range on public.technician_prices;
create trigger trg_check_price_range before insert or update on public.technician_prices
  for each row execute function public.check_price_range();
