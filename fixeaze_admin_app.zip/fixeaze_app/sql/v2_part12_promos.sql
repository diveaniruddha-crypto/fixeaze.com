-- Fixeaze part 12: home-page banners and full-screen advertisements
-- Run once in Supabase > SQL Editor > New query. Safe to run twice.
-- If the editor warns about "destructive operations", press Run query.

create table if not exists public.promos (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('banner', 'ad')),
  title text not null,
  media_url text not null,
  media_type text not null default 'image' check (media_type in ('image', 'video')),
  link_type text not null default 'none' check (link_type in ('none', 'service', 'tab', 'url')),
  link_value text,
  audience text not null default 'both' check (audience in ('customer', 'technician', 'both')),
  date_from date not null,
  date_to date not null,
  city text,
  pincode text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  created_by uuid default auth.uid()
);
alter table public.promos enable row level security;

drop policy if exists "promos admin" on public.promos;
create policy "promos admin" on public.promos for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.promos to authenticated;

-- What the apps call: only live items for this kind of user, this date, this place.
create or replace function public.get_promos(
  p_kind text, p_audience text,
  p_pincode text default null, p_place text default null)
returns table (id uuid, kind text, title text, media_url text, media_type text,
               link_type text, link_value text)
language sql stable security definer set search_path = public as $$
  select p.id, p.kind, p.title, p.media_url, p.media_type, p.link_type, p.link_value
  from public.promos p
  where p.active
    and p.kind = p_kind
    and (now() at time zone 'Asia/Kolkata')::date between p.date_from and p.date_to
    and p.audience in (p_audience, 'both')
    and (coalesce(trim(p.pincode), '') = ''
         or (p_pincode is not null and p_pincode = any (string_to_array(replace(p.pincode, ' ', ''), ','))))
    and (coalesce(trim(p.city), '') = ''
         or (p_place is not null and p_place ilike '%' || trim(p.city) || '%'))
  order by p.created_at desc
  limit 10;
$$;
grant execute on function public.get_promos(text, text, text, text) to anon, authenticated;
