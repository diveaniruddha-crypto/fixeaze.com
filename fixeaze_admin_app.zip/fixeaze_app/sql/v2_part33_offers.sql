-- Part 33: offers (percent off / rupees off) and coupon use at checkout
create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  code text not null,
  title text not null,
  discount_type text not null check (discount_type in ('percent', 'flat')),
  value numeric(10,2) not null check (value > 0),
  max_discount numeric(10,2),
  min_order numeric(10,2) not null default 0,
  date_from date not null,
  date_to date not null,
  total_limit int,
  per_customer int not null default 1,
  first_booking_only boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now());
create unique index if not exists offers_code_key on public.offers (upper(code));
alter table public.offers enable row level security;
drop policy if exists "offers admin" on public.offers;
create policy "offers admin" on public.offers for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.offers to authenticated;

create table if not exists public.offer_redemptions (
  id uuid primary key default gen_random_uuid(),
  offer_id uuid not null references public.offers(id) on delete cascade,
  customer_id uuid not null references public.profiles(id) on delete cascade,
  booking_id uuid unique references public.bookings(id) on delete cascade,
  discount numeric(10,2) not null default 0,
  created_at timestamptz not null default now());
alter table public.offer_redemptions enable row level security;
drop policy if exists "redeem read" on public.offer_redemptions;
create policy "redeem read" on public.offer_redemptions for select to authenticated
  using (customer_id = auth.uid() or public.is_admin());
grant select on public.offer_redemptions to authenticated;

alter table public.bookings add column if not exists offer_code text;
alter table public.bookings add column if not exists discount_amount numeric(10,2) not null default 0;
