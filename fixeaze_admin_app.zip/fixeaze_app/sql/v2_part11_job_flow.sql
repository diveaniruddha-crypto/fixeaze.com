-- Fixeaze part 11: safe job flow (selfie, start OTP, photos, parts, payment, end OTP, commission)
-- Run once in Supabase > SQL Editor > New query. Safe to run twice.
-- If the editor warns about "destructive operations", press Run query.

-- ---------- 1. New columns on bookings ----------
alter table public.bookings add column if not exists price numeric(10,2);
alter table public.bookings add column if not exists job_stage text;
alter table public.bookings add column if not exists arrival_selfie text;
alter table public.bookings add column if not exists arrived_at timestamptz;
alter table public.bookings add column if not exists started_at timestamptz;
alter table public.bookings add column if not exists finished_at timestamptz;
alter table public.bookings add column if not exists before_photos text[] not null default '{}';
alter table public.bookings add column if not exists after_photos text[] not null default '{}';
alter table public.bookings add column if not exists parts_total numeric(10,2) not null default 0;
alter table public.bookings add column if not exists parts_rejected_at timestamptz;
alter table public.bookings add column if not exists gross_total numeric(10,2);
alter table public.bookings add column if not exists commission_pct numeric(5,2);
alter table public.bookings add column if not exists commission_amount numeric(10,2);
alter table public.bookings add column if not exists tech_amount numeric(10,2);
alter table public.bookings add column if not exists payment_method text;

-- ---------- 2. Fixeaze settings (bank details for the QR + commission) ----------
create table if not exists public.platform_settings (
  id int primary key default 1 check (id = 1),
  payee_name text,
  upi_id text,
  bank_name text,
  account_no text,
  ifsc text,
  commission_pct numeric(5,2) not null default 20 check (commission_pct >= 0 and commission_pct <= 100),
  updated_at timestamptz not null default now()
);
insert into public.platform_settings (id) values (1) on conflict (id) do nothing;
alter table public.platform_settings enable row level security;

drop policy if exists "settings admin" on public.platform_settings;
create policy "settings admin" on public.platform_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update on public.platform_settings to authenticated;

-- ---------- 3. Parts, OTPs, cash dues ----------
create table if not exists public.job_parts (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  qty int not null default 1 check (qty between 1 and 999),
  price numeric(10,2) not null check (price >= 0 and price <= 500000),
  created_at timestamptz not null default now()
);
create index if not exists job_parts_booking_idx on public.job_parts (booking_id);
alter table public.job_parts enable row level security;
drop policy if exists "parts read" on public.job_parts;
create policy "parts read" on public.job_parts for select to authenticated
  using (public.is_booking_party(booking_id) or public.is_admin());
grant select on public.job_parts to authenticated;

create table if not exists public.job_otps (
  booking_id uuid not null references public.bookings(id) on delete cascade,
  kind text not null check (kind in ('start', 'end')),
  code text not null,
  attempts int not null default 0,
  created_at timestamptz not null default now(),
  primary key (booking_id, kind)
);
alter table public.job_otps enable row level security;
-- START code: only the CUSTOMER can read it (technician types it).
-- END code: only the TECHNICIAN can read it (customer types it).
drop policy if exists "otp customer read" on public.job_otps;
drop policy if exists "otp read" on public.job_otps;
create policy "otp read" on public.job_otps for select to authenticated
  using (exists (select 1 from public.bookings b
                 where b.id = job_otps.booking_id
                   and ((job_otps.kind = 'start' and b.customer_id = auth.uid())
                     or (job_otps.kind = 'end' and b.technician_id = auth.uid()))));
grant select on public.job_otps to authenticated;

create table if not exists public.cash_dues (
  id uuid primary key default gen_random_uuid(),
  technician_id uuid not null references public.profiles(id) on delete cascade,
  booking_id uuid unique references public.bookings(id) on delete set null,
  amount numeric(10,2) not null check (amount >= 0),
  settled numeric(10,2) not null default 0,
  status text not null default 'open' check (status in ('open', 'settled')),
  note text,
  created_at timestamptz not null default now(),
  settled_at timestamptz
);
alter table public.cash_dues enable row level security;
drop policy if exists "dues read" on public.cash_dues;
create policy "dues read" on public.cash_dues for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());
drop policy if exists "dues admin write" on public.cash_dues;
create policy "dues admin write" on public.cash_dues for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.cash_dues to authenticated;

-- Extra detail on the technician payment rows
alter table public.technician_payments add column if not exists gross numeric(10,2);
alter table public.technician_payments add column if not exists commission numeric(10,2);
alter table public.technician_payments add column if not exists deducted numeric(10,2) not null default 0;
alter table public.technician_payments add column if not exists method text;

-- ---------- 4. Booking guard: technicians can no longer jump stages by hand ----------
create or replace function public.bookings_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare skip text[] := array['status','technician_id','completion_photos','updated_at'];
begin
  if public.is_admin() then return new; end if;
  -- the job-flow functions below switch this on for their own transaction only
  if coalesce(current_setting('fixeaze.rpc', true), '') = '1' then return new; end if;

  if (to_jsonb(new) - skip) <> (to_jsonb(old) - skip) then
    raise exception 'Not allowed to change these booking fields';
  end if;

  if auth.uid() = old.customer_id then
    if old.status in ('pending','accepted') and old.job_stage is null and new.status = 'cancelled'
       and new.technician_id is not distinct from old.technician_id
       and new.completion_photos is not distinct from old.completion_photos then
      return new;
    end if;
    raise exception 'Customers can only cancel a booking before the technician arrives';
  end if;

  if old.status = 'pending' and old.technician_id is null
     and new.status = 'accepted' and new.technician_id = auth.uid()
     and public.can_take_job(old.service_id, old.lat, old.lng) then
    return new;
  end if;

  raise exception 'Not allowed';
end $$;

-- Payment row for a completed job: the job-flow function creates it itself.
-- This only covers jobs the admin completes by hand (old behaviour).
create or replace function public.on_booking_completed_payment()
returns trigger language plpgsql security definer set search_path = public as $$
declare amt numeric(10,2);
begin
  amt := coalesce(nullif(to_jsonb(new)->>'price', '')::numeric, 0);

  if new.status = 'completed' and old.status is distinct from 'completed'
     and new.technician_id is not null then
    if not exists (select 1 from public.technician_payments where booking_id = new.id) then
      insert into public.technician_payments (booking_id, technician_id, amount)
      values (new.id, new.technician_id, amt);
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Job completed',
              'Your payment for this job is now pending with Fixeaze. We will update you here.');
    end if;
  elsif new.technician_id is not null
        and (to_jsonb(new)->>'price') is distinct from (to_jsonb(old)->>'price') then
    update public.technician_payments set amount = amt, updated_at = now()
    where booking_id = new.id and status = 'pending' and method is null;
  end if;
  return new;
end $$;

-- ---------- 5. Job-flow functions (the only way to move a job forward) ----------
create or replace function public.job_new_otp(p_booking uuid, p_kind text)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.job_otps (booking_id, kind, code, attempts, created_at)
  values (p_booking, p_kind, lpad((floor(random() * 1000000))::int::text, 6, '0'), 0, now())
  on conflict (booking_id, kind)
  do update set code = excluded.code, attempts = 0, created_at = now();
end $$;
revoke execute on function public.job_new_otp(uuid, text) from public, anon, authenticated;

-- 5.1 Technician reaches the customer: takes a selfie, customer gets the start OTP in the app
create or replace function public.job_arrive(p_booking uuid, p_selfie text)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() then raise exception 'Not your job'; end if;
  if b.status <> 'accepted' or coalesce(b.job_stage, 'assigned') not in ('assigned', 'arrived') then
    raise exception 'This job is not waiting for arrival';
  end if;
  if p_selfie is null or p_selfie not like 'https://%' then raise exception 'Please take a selfie first'; end if;

  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings set arrival_selfie = p_selfie, arrived_at = now(), job_stage = 'arrived'
  where id = p_booking;
  perform public.job_new_otp(p_booking, 'start');
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 5.2 Technician types the OTP the customer sees
create or replace function public.job_verify_start(p_booking uuid, p_code text)
returns boolean language plpgsql security definer set search_path = public as $$
declare b public.bookings; o public.job_otps; labour numeric(10,2);
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() then raise exception 'Not your job'; end if;
  if b.job_stage is distinct from 'arrived' then raise exception 'Take the arrival selfie first'; end if;
  select * into o from public.job_otps where booking_id = p_booking and kind = 'start';
  if not found then raise exception 'No OTP. Tap "New OTP".'; end if;
  if o.attempts >= 5 then raise exception 'Too many wrong tries. Tap "New OTP".'; end if;

  if trim(coalesce(p_code, '')) <> o.code then
    update public.job_otps set attempts = attempts + 1 where booking_id = p_booking and kind = 'start';
    return false;
  end if;

  labour := b.price;
  if labour is null then
    select case when b.booking_type = 'inspection' then coalesce(s.inspection_fee, 0)
                else coalesce(tp.hourly_rate, s.base_price, 0) * coalesce(b.hours, 1) end
      into labour
    from public.services s
    left join public.technician_profiles tp on tp.id = b.technician_id
    where s.id = b.service_id;
  end if;

  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings
     set status = 'in_progress', job_stage = 'working', started_at = now(), price = coalesce(labour, 0)
   where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
  delete from public.job_otps where booking_id = p_booking and kind = 'start';
  return true;
end $$;

create or replace function public.job_resend_start_otp(p_booking uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.technician_id is distinct from auth.uid() or b.job_stage is distinct from 'arrived' then
    raise exception 'Not allowed';
  end if;
  perform public.job_new_otp(p_booking, 'start');
end $$;

-- 5.3 Before / after photos
create or replace function public.job_add_photo(p_booking uuid, p_kind text, p_url text)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() then raise exception 'Not your job'; end if;
  if b.job_stage is distinct from 'working' then raise exception 'Photos can only be added while working'; end if;
  if p_url is null or p_url not like 'https://%' then raise exception 'Bad photo'; end if;
  perform set_config('fixeaze.rpc', '1', true);
  if p_kind = 'before' and coalesce(array_length(b.before_photos, 1), 0) < 6 then
    update public.bookings set before_photos = before_photos || p_url where id = p_booking;
  elsif p_kind = 'after' and coalesce(array_length(b.after_photos, 1), 0) < 6 then
    update public.bookings set after_photos = after_photos || p_url where id = p_booking;
  else
    perform set_config('fixeaze.rpc', '', true);
    raise exception 'Maximum 6 photos';
  end if;
  perform set_config('fixeaze.rpc', '', true);
end $$;

create or replace function public.job_remove_photo(p_booking uuid, p_kind text, p_url text)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() or b.job_stage is distinct from 'working' then
    raise exception 'Not allowed';
  end if;
  perform set_config('fixeaze.rpc', '1', true);
  if p_kind = 'before' then
    update public.bookings set before_photos = array_remove(before_photos, p_url) where id = p_booking;
  else
    update public.bookings set after_photos = array_remove(after_photos, p_url) where id = p_booking;
  end if;
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 5.4 Parts used
create or replace function public.job_add_part(p_booking uuid, p_name text, p_qty int, p_price numeric)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.technician_id is distinct from auth.uid() or b.job_stage is distinct from 'working' then
    raise exception 'Parts can only be added while working';
  end if;
  insert into public.job_parts (booking_id, name, qty, price)
  values (p_booking, trim(p_name), greatest(coalesce(p_qty, 1), 1), p_price);
end $$;

create or replace function public.job_remove_part(p_part uuid)
returns void language plpgsql security definer set search_path = public as $$
declare bid uuid;
begin
  select p.booking_id into bid from public.job_parts p
  join public.bookings b on b.id = p.booking_id
  where p.id = p_part and b.technician_id = auth.uid() and b.job_stage = 'working';
  if bid is null then raise exception 'Not allowed'; end if;
  delete from public.job_parts where id = p_part;
end $$;

-- 5.5 Technician sends the parts list to the customer
create or replace function public.job_submit_parts(p_booking uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings; total numeric(10,2);
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() or b.job_stage is distinct from 'working' then
    raise exception 'Not allowed';
  end if;
  if coalesce(array_length(b.before_photos, 1), 0) = 0 then raise exception 'Add at least one BEFORE photo'; end if;
  if coalesce(array_length(b.after_photos, 1), 0) = 0 then raise exception 'Add at least one AFTER photo'; end if;
  select coalesce(sum(qty * price), 0) into total from public.job_parts where booking_id = p_booking;
  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings set parts_total = total, job_stage = 'parts_review', parts_rejected_at = null
  where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 5.6 Customer says yes / no to the parts list
create or replace function public.job_parts_response(p_booking uuid, p_ok boolean)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'parts_review' then
    raise exception 'Not allowed';
  end if;
  perform set_config('fixeaze.rpc', '1', true);
  if p_ok then
    update public.bookings
       set job_stage = 'payment_due', gross_total = coalesce(price, 0) + parts_total
     where id = p_booking;
  else
    update public.bookings set job_stage = 'working', parts_rejected_at = now() where id = p_booking;
  end if;
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 5.7 Customer picks QR or cash
create or replace function public.job_choose_payment(p_booking uuid, p_method text)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'payment_due' then
    raise exception 'Not allowed';
  end if;
  if p_method not in ('qr', 'cash') then raise exception 'Bad payment method'; end if;
  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings set payment_method = p_method, job_stage = 'payment_check' where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 5.8 Technician confirms (or denies) that the money arrived; customer then gets the end OTP
create or replace function public.job_confirm_payment(p_booking uuid, p_received boolean)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() or b.job_stage is distinct from 'payment_check' then
    raise exception 'Not allowed';
  end if;
  perform set_config('fixeaze.rpc', '1', true);
  if p_received then
    update public.bookings set job_stage = 'end_otp' where id = p_booking;
    perform public.job_new_otp(p_booking, 'end');
  else
    update public.bookings set job_stage = 'payment_due', payment_method = null where id = p_booking;
  end if;
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 5.9 Customer types the end OTP: job is finished, commission is worked out
create or replace function public.job_finish(p_booking uuid, p_code text)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  b public.bookings; o public.job_otps; pct numeric(5,2);
  gross numeric(10,2); comm numeric(10,2); net numeric(10,2); ded numeric(10,2) := 0;
  d record; take numeric(10,2); note_txt text;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'end_otp' then
    raise exception 'Not allowed';
  end if;
  select * into o from public.job_otps where booking_id = p_booking and kind = 'end';
  if not found then raise exception 'No OTP'; end if;
  if o.attempts >= 5 then raise exception 'Too many wrong tries. Ask the technician to confirm payment again.'; end if;
  if trim(coalesce(p_code, '')) <> o.code then
    update public.job_otps set attempts = attempts + 1 where booking_id = p_booking and kind = 'end';
    return false;
  end if;

  select commission_pct into pct from public.platform_settings where id = 1;
  pct := coalesce(pct, 20);
  gross := coalesce(b.gross_total, coalesce(b.price, 0) + b.parts_total);
  comm := round(gross * pct / 100, 2);
  net := gross - comm;

  if b.payment_method = 'qr' then
    -- Fixeaze received the money: pay the technician their share, minus any cash commission still owed
    for d in select * from public.cash_dues
             where technician_id = b.technician_id and status = 'open'
             order by created_at for update loop
      exit when net <= 0;
      take := least(d.amount - d.settled, net);
      update public.cash_dues
         set settled = settled + take,
             status = case when settled + take >= amount then 'settled' else 'open' end,
             settled_at = case when settled + take >= amount then now() else null end
       where id = d.id;
      net := net - take;
      ded := ded + take;
    end loop;
    note_txt := 'Job total Rs ' || gross || ', Fixeaze commission Rs ' || comm
                || case when ded > 0 then ', earlier cash commission deducted Rs ' || ded else '' end || '.';
    insert into public.technician_payments
      (booking_id, technician_id, amount, status, gross, commission, deducted, method, note, paid_at)
    values (b.id, b.technician_id, net, case when net <= 0 then 'paid' else 'pending' end,
            gross, comm, ded, 'qr', note_txt, case when net <= 0 then now() else null end)
    on conflict (booking_id) do nothing;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (b.technician_id, 'payment', 'Job completed (paid by QR)',
            'Rs ' || net || ' will be paid to you by Fixeaze. ' || note_txt);
  else
    -- Technician holds the cash: they owe Fixeaze the commission, taken from their next payment
    insert into public.cash_dues (technician_id, booking_id, amount, note)
    values (b.technician_id, b.id, comm, 'Cash job, total Rs ' || gross)
    on conflict (booking_id) do nothing;
    note_txt := 'Customer paid Rs ' || gross || ' in cash. Fixeaze commission Rs ' || comm
                || ' will be deducted from your next payment.';
    insert into public.technician_payments
      (booking_id, technician_id, amount, status, gross, commission, deducted, method, note, paid_at)
    values (b.id, b.technician_id, 0, 'paid', gross, comm, 0, 'cash', note_txt, now())
    on conflict (booking_id) do nothing;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (b.technician_id, 'payment', 'Job completed (cash)', note_txt);
  end if;

  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings
     set status = 'completed', job_stage = 'done', finished_at = now(),
         gross_total = gross, commission_pct = pct, commission_amount = comm,
         tech_amount = gross - comm, completion_photos = after_photos
   where id = p_booking;
  perform set_config('fixeaze.rpc', '', true);
  delete from public.job_otps where booking_id = p_booking;
  return true;
end $$;

-- Customer or technician of a job can ask for the Fixeaze UPI details to draw the QR
create or replace function public.get_pay_info(p_booking uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare b public.bookings; s public.platform_settings;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or (b.customer_id is distinct from auth.uid() and b.technician_id is distinct from auth.uid()) then
    raise exception 'Not allowed';
  end if;
  select * into s from public.platform_settings where id = 1;
  return jsonb_build_object(
    'upi_id', nullif(trim(coalesce(s.upi_id, '')), ''),
    'payee_name', coalesce(nullif(trim(coalesce(s.payee_name, '')), ''), 'Fixeaze'),
    'amount', coalesce(b.gross_total, 0),
    'ref', left(b.id::text, 8));
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'job_arrive(uuid,text)', 'job_verify_start(uuid,text)', 'job_resend_start_otp(uuid)',
    'job_add_photo(uuid,text,text)', 'job_remove_photo(uuid,text,text)',
    'job_add_part(uuid,text,int,numeric)', 'job_remove_part(uuid)', 'job_submit_parts(uuid)',
    'job_parts_response(uuid,boolean)', 'job_choose_payment(uuid,text)',
    'job_confirm_payment(uuid,boolean)', 'job_finish(uuid,text)', 'get_pay_info(uuid)']
  loop
    execute 'revoke execute on function public.' || f || ' from public, anon';
    execute 'grant execute on function public.' || f || ' to authenticated';
  end loop;
end $$;
