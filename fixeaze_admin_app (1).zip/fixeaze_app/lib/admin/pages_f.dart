import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../widgets/chat_bubble.dart';
import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

String _short(dynamic id) {
  final x = '$id';
  return x.length >= 8 ? x.substring(0, 8) : x;
}

// ============================================================== SUPPORT TICKETS

class SupportPage extends StatefulWidget {
  const SupportPage({super.key});
  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage> {
  String _filter = 'open';
  final _q = TextEditingController();
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
    _t = Timer.periodic(const Duration(seconds: 30), (_) => _s.loadAll(silent: true));
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _t?.cancel();
    _s.removeListener(_changed);
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final q = _q.text.trim().toLowerCase();
    final rows = s.tickets.where((t) {
      final st = '${t['status']}';
      if (_filter != 'all' && st != _filter) return false;
      if (q.isEmpty) return true;
      final hay = '${t['ticket_no']} ${t['subject']} ${t['booking_id'] ?? ''} ${s.nameOf(t['created_by'])} ${s.P['${t['created_by']}']?['phone'] ?? ''}'
          .toLowerCase();
      return hay.contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['support_tickets'] != null)
          NoticeBanner('Support tables are missing. Run sql/v2_part15_support.sql in Supabase. (${s.errors['support_tickets']})',
              color: kBad),
        TileGrid([
          StatTile('Waiting for your reply', '${s.openTickets}', alert: s.openTickets > 0),
          StatTile('Replied', '${s.tickets.where((t) => t['status'] == 'answered').length}'),
          StatTile('Closed', '${s.tickets.where((t) => t['status'] == 'closed').length}'),
        ]),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
          for (final f in const ['open', 'answered', 'closed', 'all'])
            ChoiceChip(
              label: Text(f == 'open' ? 'Needs reply' : f == 'answered' ? 'Replied' : f == 'closed' ? 'Closed' : 'All'),
              selected: _filter == f,
              onSelected: (_) => setState(() => _filter = f),
            ),
          SizedBox(
            width: 260,
            child: TextField(
              controller: _q,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                  isDense: true, prefixIcon: Icon(Icons.search), hintText: 'Ticket no, booking id, name, phone'),
            ),
          ),
        ]),
        const SizedBox(height: 10),
        AdminTable(
          columns: const ['Ticket', 'From', 'Booking', 'Subject', 'Updated', 'Status', ''],
          empty: 'No tickets here.',
          rows: [
            for (final t in rows)
              <Widget>[
                Text('#${t['ticket_no']}'),
                TwoLine(s.nameOf(t['created_by']), '${t['role']} · ${s.P['${t['created_by']}']?['phone'] ?? ''}'),
                Text(t['booking_id'] == null ? '-' : _short(t['booking_id'])),
                SizedBox(width: 220, child: Text('${t['subject']}', maxLines: 2, overflow: TextOverflow.ellipsis)),
                Text(ago(t['updated_at'])),
                t['status'] == 'closed'
                    ? const Pill('Closed', Colors.grey)
                    : t['status'] == 'answered'
                        ? const Pill('Replied', kOk)
                        : const Pill('Needs reply', kWarn),
                FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size(0, 38)),
                  onPressed: () => showDialog<void>(context: context, builder: (_) => _TicketDialog(ticket: t)),
                  child: const Text('Open'),
                ),
              ],
          ],
        ),
      ],
    );
  }
}

class _TicketDialog extends StatefulWidget {
  final Rec ticket;
  const _TicketDialog({required this.ticket});
  @override
  State<_TicketDialog> createState() => _TicketDialogState();
}

class _TicketDialogState extends State<_TicketDialog> {
  List<Rec> _msgs = [];
  String _status = '';
  Timer? _t;
  final _text = TextEditingController();
  final _scroll = ScrollController();
  bool _busy = false;
  int _last = 0;

  @override
  void initState() {
    super.initState();
    _status = '${widget.ticket['status']}';
    _load();
    _t = Timer.periodic(const Duration(seconds: 5), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final id = widget.ticket['id'];
      final m = await supabase.from('support_messages').select().eq('ticket_id', id).order('created_at');
      final t = await supabase.from('support_tickets').select('status').eq('id', id).single();
      if (!mounted) return;
      setState(() {
        _msgs = (m as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
        _status = '${t['status']}';
      });
      if (_msgs.length != _last) {
        _last = _msgs.length;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
        });
      }
    } on PostgrestException catch (_) {
    } catch (_) {}
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty) return;
    setState(() => _busy = true);
    final err = await _s.ticketReply('${widget.ticket['id']}', body);
    if (!mounted) return;
    setState(() => _busy = false);
    if (err == null) {
      _text.clear();
      _load();
    } else {
      toast(context, err, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.ticket;
    final bid = t['booking_id'];
    Rec? b;
    if (bid != null) {
      for (final x in _s.bookings) {
        if ('${x['id']}' == '$bid') b = x;
      }
    }
    final closed = _status == 'closed';
    return AlertDialog(
      title: Text('#${t['ticket_no']}  ${t['subject']}'),
      content: SizedBox(
        width: 560,
        height: 480,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${_s.nameOf(t['created_by'])} (${t['role']}) · ${_s.P['${t['created_by']}']?['phone'] ?? ''}',
              style: const TextStyle(fontWeight: FontWeight.w600)),
          if (bid != null)
            Row(children: [
              Expanded(
                child: Muted('Booking $bid'
                    '${b == null ? '' : '\n${_s.svcName(b['service_id'])} · ${statusLabel('${b['status']}')} · customer ${_s.nameOf(b['customer_id'])} · technician ${_s.nameOf(b['technician_id'])}'}'),
              ),
              IconButton(
                tooltip: 'Copy booking id',
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: '$bid'));
                  toast(context, 'Booking id copied');
                },
              ),
            ])
          else
            const Muted('Not linked to a booking'),
          const Divider(),
          Expanded(
            child: ListView(controller: _scroll, children: [
              for (final m in _msgs)
                ChatBubble(
                  text: '${m['body']}',
                  who: m['sender_role'] == 'admin' ? _s.nameOf(m['sender_id'], 'Fixeaze support') : _s.nameOf(t['created_by']),
                  time: parseTime(m['created_at']),
                  mine: m['sender_role'] == 'admin',
                ),
            ]),
          ),
          if (!closed)
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _text,
                  minLines: 1,
                  maxLines: 4,
                  decoration: const InputDecoration(hintText: 'Write your reply', border: OutlineInputBorder()),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send)),
            ]),
        ]),
      ),
      actions: [
        TextButton(
          onPressed: () async {
            final err = await _s.ticketStatus('${t['id']}', closed ? 'open' : 'closed');
            if (!mounted) return;
            report(context, err, closed ? 'Ticket reopened' : 'Ticket closed');
            if (err == null) Navigator.pop(context);
          },
          child: Text(closed ? 'Reopen ticket' : 'Close ticket'),
        ),
        FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
      ],
    );
  }
}

// ============================================================== ADMIN CHAT (group + personal)

class AdminChatPage extends StatefulWidget {
  const AdminChatPage({super.key});
  @override
  State<AdminChatPage> createState() => _AdminChatPageState();
}

class _AdminChatPageState extends State<AdminChatPage> {
  List<Rec> _all = [];
  String? _error;
  Timer? _t;
  final _text = TextEditingController();
  final _scroll = ScrollController();
  bool _busy = false;
  String _sel = 'group'; // 'group' or another admin's id
  int _lastCount = -1;
  String _lastKey = '';
  final Map<String, DateTime> _seen = {};
  final DateTime _opened = DateTime.now();

  String get _me => supabase.auth.currentUser?.id ?? '';

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  /// Which conversation a message belongs to.
  String _key(Rec m) {
    if (m['to_user'] == null) return 'group';
    return '${m['sender_id']}' == _me ? '${m['to_user']}' : '${m['sender_id']}';
  }

  Future<void> _load() async {
    try {
      final m = await supabase.from('admin_chat').select().order('created_at', ascending: false).limit(600);
      if (!mounted) return;
      setState(() {
        _error = null;
        _all = (m as List).map((e) => Map<String, dynamic>.from(e as Map)).toList().reversed.toList();
        _seen[_sel] = DateTime.now();
      });
      final msgs = _all.where((x) => _key(x) == _sel).toList();
      if (msgs.length != _lastCount || _sel != _lastKey) {
        _lastCount = msgs.length;
        _lastKey = _sel;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e is PostgrestException ? e.message : '$e');
    }
  }

  int _unread(String key) {
    final since = _seen[key] ?? _opened;
    return _all
        .where((x) =>
            _key(x) == key &&
            '${x['sender_id']}' != _me &&
            (parseTime(x['created_at'])?.isAfter(since) ?? false))
        .length;
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty) return;
    setState(() => _busy = true);
    try {
      await supabase.from('admin_chat').insert({
        'sender_id': _me,
        'body': body,
        'to_user': _sel == 'group' ? null : _sel,
      });
      _text.clear();
      await _load();
    } catch (e) {
      if (mounted) toast(context, e is PostgrestException ? e.message : '$e', error: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  Widget _chip(String key, String label, {bool online = false}) {
    final n = key == _sel ? 0 : _unread(key);
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        selected: key == _sel,
        onSelected: (_) {
          setState(() {
            _sel = key;
            _seen[key] = DateTime.now();
            _lastKey = '';
          });
          _load();
        },
        label: Row(mainAxisSize: MainAxisSize.min, children: [
          if (key != 'group')
            Container(
              width: 8,
              height: 8,
              margin: const EdgeInsets.only(right: 6),
              decoration: BoxDecoration(shape: BoxShape.circle, color: online ? kOk : Colors.black26),
            ),
          Text(label),
          if (n > 0)
            Container(
              margin: const EdgeInsets.only(left: 6),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(color: kBad, borderRadius: BorderRadius.circular(10)),
              child: Text('$n', style: const TextStyle(color: Colors.white, fontSize: 11)),
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final partners = _s.admins.where((a) => '${a['id']}' != _me).toList()
      ..sort((a, b) => '${a['name']}'.compareTo('${b['name']}'));
    final msgs = _all.where((x) => _key(x) == _sel).toList();
    final title = _sel == 'group' ? 'Everyone (group)' : _s.nameOf(_sel, 'Partner');

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        if (_error != null)
          NoticeBanner('Chat is not ready. Run sql/v2_part15_support.sql and sql/v2_part17_admin_dm.sql in Supabase. ($_error)',
              color: kBad),
        SizedBox(
          height: 44,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            _chip('group', 'Everyone'),
            for (final a in partners) _chip('${a['id']}', _s.nameOf(a['id']), online: _s.isOnline('${a['id']}')),
          ]),
        ),
        const SizedBox(height: 6),
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
              _sel == 'group' ? 'Group chat: every admin can read this' : 'Private chat with $title: only you two can read this',
              style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ),
        const SizedBox(height: 6),
        Expanded(
          child: Card(
            margin: EdgeInsets.zero,
            child: msgs.isEmpty
                ? Center(child: Muted(_sel == 'group' ? 'No messages yet. Say hello to your team.' : 'No messages yet with $title.'))
                : ListView(controller: _scroll, padding: const EdgeInsets.all(12), children: [
                    for (final m in msgs)
                      ChatBubble(
                        text: '${m['body']}',
                        who: _s.nameOf(m['sender_id'], 'Admin'),
                        time: parseTime(m['created_at']),
                        mine: '${m['sender_id']}' == _me,
                      ),
                  ]),
          ),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _text,
              minLines: 1,
              maxLines: 4,
              onSubmitted: (_) => _send(),
              decoration: InputDecoration(
                  hintText: _sel == 'group' ? 'Message all admins' : 'Message $title',
                  border: const OutlineInputBorder()),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send)),
        ]),
      ]),
    );
  }
}
