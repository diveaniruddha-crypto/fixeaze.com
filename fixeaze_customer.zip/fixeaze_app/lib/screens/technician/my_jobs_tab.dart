import 'package:flutter/material.dart';
import 'job_buttons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../../widgets/booking_row.dart';
import '../../widgets/job_location.dart';
import '../../widgets/cancel_dialog.dart';
import '../../widgets/rating_dialog.dart';
import '../../widgets/fun_loader.dart';
import '../chat_screen.dart';
import 'job_flow_screen.dart';
import '../help_screen.dart';

class _JobsData {
  final List<Map<String, dynamic>> jobs;
  final Map<String, Map<String, dynamic>> customers; // by customer id
  final Set<String> rated;
  final List<Map<String, dynamic>> selfCancelled; // jobs this technician cancelled
  _JobsData(this.jobs, this.customers, [this.rated = const {}, this.selfCancelled = const []]);
}

class MyJobsTab extends StatefulWidget {
  const MyJobsTab({super.key});

  @override
  State<MyJobsTab> createState() => _MyJobsTabState();
}

class _MyJobsTabState extends State<MyJobsTab> {
  late Future<_JobsData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_JobsData> _load() async {
    final uid = supabase.auth.currentUser!.id;
    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price)')
        .eq('technician_id', uid)
        .order('created_at', ascending: false);
    final jobs = List<Map<String, dynamic>>.from(rows);

    final ids = jobs.map((j) => j['customer_id']).whereType<String>().toSet().toList();
    final customers = <String, Map<String, dynamic>>{};
    if (ids.isNotEmpty) {
      final crows =
          await supabase.from('profiles').select('id, name, phone').inFilter('id', ids);
      for (final r in crows) {
        customers[r['id'] as String] = Map<String, dynamic>.from(r);
      }
    }
    final rated = <String>{};
    try {
      final rr = await supabase.from('customer_reviews').select('booking_id').eq('technician_id', uid);
      for (final r in rr) {
        rated.add('${r['booking_id']}');
      }
    } catch (_) {}
    var mine = <Map<String, dynamic>>[];
    try {
      final c = await supabase.rpc('my_cancelled_jobs');
      mine = List<Map<String, dynamic>>.from(c as List);
    } catch (_) {}
    return _JobsData(jobs, customers, rated, mine);
  }

  Future<void> _cancelJob(Map<String, dynamic> job) async {
    final r = await showCancelDialog(context, technician: true);
    if (r == null) return;
    try {
      await supabase.rpc('cancel_booking',
          params: {'p_booking': job['id'], 'p_reason': r.reason, 'p_note': r.note});
      if (mounted) snack(context, 'Job cancelled. It is back with other technicians.');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  Future<void> _rateCustomer(Map<String, dynamic> job, String name) async {
    final r = await showRatingPopup(context,
        title: 'How was the customer?',
        who: name,
        tags: const ['Polite', 'Paid on time', 'Clear instructions', 'Rude', 'Unreachable']);
    if (r == null) return;
    try {
      await supabase.from('customer_reviews').insert({
        'booking_id': job['id'],
        'technician_id': supabase.auth.currentUser!.id,
        'customer_id': job['customer_id'],
        'rating': r.rating,
        'comment': r.comment.isEmpty ? null : r.comment,
      });
      if (mounted) snack(context, 'Thanks! Your rating was sent.');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  Future<void> _open(Uri uri) async {
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
      snack(context, 'Could not open that link', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_JobsData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const FunLoader();
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final data = snap.data!;
        if (data.jobs.isEmpty && data.selfCancelled.isEmpty) {
          return const EmptyState(
            icon: Icons.assignment,
            text: 'You have no jobs yet.\nAccept one from the Open jobs tab.',
          );
        }
        // newest first: jobs by the time they were booked, cancelled-by-me by the time I cancelled
        final entries = <Map<String, dynamic>>[
          for (final j in data.jobs) {'t': '${j['created_at'] ?? ''}', 'job': j},
          for (final c in data.selfCancelled) {'t': '${c['cancelled_at'] ?? ''}', 'c': c},
        ]..sort((a, b) => '${b['t']}'.compareTo('${a['t']}'));
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: entries.length + 1,
            itemBuilder: (context, i) {
              if (i == 0) return const BookingTableHeader();
              final en = entries[i - 1];
              if (en['c'] != null) {
                final c = en['c'] as Map<String, dynamic>;
                return BookingRow(
                  title: '${c['service_name'] ?? 'Job'}',
                  bookingNo: '${c['booking_no'] ?? ''}',
                  status: 'cancelled',
                  when: c['scheduled_at'],
                  details: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Cancelled by you', style: TextStyle(color: Colors.black54)),
                      if ('${c['reason'] ?? ''}'.isNotEmpty)
                        Text('Reason: ${c['reason']}', style: const TextStyle(color: Colors.black54)),
                      Align(
                        alignment: Alignment.centerRight,
                        child: SoftButton(
                          compact: true,
                          color: kChatBlue,
                          icon: Icons.headset_mic_outlined,
                          label: 'Raise a ticket',
                          onPressed: () => raiseTicketFor(context, c['booking_id']),
                        ),
                      ),
                    ]),
                  ),
                );
              }
              final job = en['job'] as Map<String, dynamic>;
              final status = (job['status'] ?? '').toString();
              final service = job['services'] as Map<String, dynamic>?;
              final customer = data.customers[job['customer_id']];
              final phone = (customer?['phone'] ?? '').toString();
              final address = (job['address'] ?? '').toString();
              final photos = List<String>.from(job['photos'] ?? const []);

              return BookingRow(
                title: (service?['name'] ?? 'Service').toString(),
                bookingNo: (job['booking_no'] ?? '').toString(),
                status: status,
                when: job['scheduled_at'],
                initiallyOpen: status == 'accepted' || status == 'in_progress',
                details: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      OrderProgress(job),
                      const SizedBox(height: 8),
                      if ((job['booking_no'] ?? '').toString().isNotEmpty)
                        Text('Booking ${job['booking_no']}',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      Text(bookingTypeLabel(job),
                          style: TextStyle(
                              color: Colors.teal.shade700,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(job['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.person, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((customer?['name'] ?? 'Customer').toString())),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(address)),
                      ]),
                      if (status != 'completed' && status != 'cancelled') JobLocation(booking: job),
                      if ((job['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${job['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      if (status == 'accepted' || status == 'in_progress') ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            if (phone.isNotEmpty)
                              SoftButton(
                                color: kCallGreen,
                                icon: Icons.call,
                                label: 'Call',
                                onPressed: () => _open(Uri.parse('tel:$phone')),
                              ),
                            SoftButton(
                              color: kChatBlue,
                              icon: Icons.chat_bubble_outline,
                              label: 'Chat',
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    bookingId: job['id'] as String,
                                    title:
                                        'Chat with ${(customer?['name'] ?? 'customer').toString()}',
                                  ),
                                ),
                              ),
                            ),
                            SoftButton(
                              color: kMapOrange,
                              icon: Icons.map_outlined,
                              label: 'Map',
                              onPressed: () => _open(Uri.parse(
                                  'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(address)}')),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: GoButton(
                            onPressed: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TechJobScreen(bookingId: job['id'] as String),
                                ),
                              );
                              if (mounted) _refresh();
                            },
                            icon: Icons.play_arrow_rounded,
                            label: status == 'accepted' && (job['job_stage'] ?? '').toString().isEmpty
                                ? 'Start job steps'
                                : 'Open job',
                          ),
                        ),
                        if (status == 'accepted' &&
                            ((job['job_stage'] ?? '').toString().isEmpty || job['job_stage'] == 'assigned' || job['job_stage'] == 'arrived'))
                          Align(
                            alignment: Alignment.centerRight,
                            child: SoftButton(
                              compact: true,
                              color: kStopRed,
                              icon: Icons.close,
                              label: 'Cancel job',
                              onPressed: () => _cancelJob(job),
                            ),
                          ),
                      ],
                      if (status == 'cancelled')
                        Align(
                          alignment: Alignment.centerRight,
                          child: SoftButton(
                            compact: true,
                            color: kChatBlue,
                            icon: Icons.headset_mic_outlined,
                            label: 'Raise a ticket',
                            onPressed: () => raiseTicketFor(context, job['id']),
                          ),
                        ),
                      if (status == 'completed' && !data.rated.contains('${job['id']}')) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: SoftButton(
                            compact: true,
                            color: kStarBrown,
                            icon: Icons.star_rate_rounded,
                            label: 'Rate customer',
                            onPressed: () => _rateCustomer(job, (customer?['name'] ?? 'Customer').toString()),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
