import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../dark_mode.dart';

import '../../config.dart';
import '../../services/cloudinary_service.dart';
import '../../widgets/common.dart';

const kOffReasons = [
  'Skill set issue',
  'Tools unavailable',
  'Spare parts not available',
  'Not interested in this work',
  'Other',
];

class _Entry {
  bool enabled = true;
  final TextEditingController price = TextEditingController();
  String? reason;
  final TextEditingController note = TextEditingController();
  bool existed = false; // already saved in the database
  void dispose() {
    price.dispose();
    note.dispose();
  }
}

/// Technician picks a service, then sets a charge for every product and service type
/// (or switches it off with a reason).
class MyPricesScreen extends StatefulWidget {
  const MyPricesScreen({super.key});
  @override
  State<MyPricesScreen> createState() => _MyPricesScreenState();
}

class _MyPricesScreenState extends State<MyPricesScreen> {
  bool _loading = true;
  bool _saving = false;
  String? _error;
  List<Map<String, dynamic>> _services = [];
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _types = [];
  Set<String> _mine = {}; // my service ids
  String? _current; // service being edited
  final Map<String, _Entry> _entries = {};

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final e in _entries.values) {
      e.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      _services = List<Map<String, dynamic>>.from(
          await supabase.from('services').select().eq('active', true).order('name'));
      _products = List<Map<String, dynamic>>.from(
          await supabase.from('catalog_products').select().eq('active', true).order('sort').order('name'));
      _types = List<Map<String, dynamic>>.from(
          await supabase.from('product_services').select().eq('active', true).order('sort').order('name'));
      final ts = await supabase.from('technician_services').select('service_id').eq('technician_id', _uid);
      _mine = {for (final r in ts) '${r['service_id']}'};
      final pr = await supabase.from('technician_prices').select().eq('technician_id', _uid);
      for (final e in _entries.values) {
        e.dispose();
      }
      _entries.clear();
      for (final r in pr) {
        final e = _Entry()
          ..existed = true
          ..enabled = r['enabled'] == true
          ..reason = r['off_reason'] as String?;
        if (r['price'] != null) {
          final p = num.tryParse('${r['price']}') ?? 0;
          e.price.text = p == p.roundToDouble() ? p.toStringAsFixed(0) : '$p';
        }
        e.note.text = '${r['off_note'] ?? ''}';
        _entries['${r['item_id']}'] = e;
      }
      if (_current == null || !_mine.contains(_current)) {
        _current = _mine.isEmpty ? null : _mine.first;
      }
      _error = null;
    } catch (e) {
      _error = e is PostgrestException ? e.message : '$e';
    }
    if (mounted) setState(() => _loading = false);
  }

  _Entry _entry(String itemId) => _entries.putIfAbsent(itemId, () => _Entry());

  Future<void> _chooseService() async {
    final picked = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Which service do you do?'),
        children: [
          for (final s in _services)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, '${s['id']}'),
              child: Row(children: [
                const Icon(Icons.handyman_outlined, size: 20),
                const SizedBox(width: 10),
                Expanded(child: Text('${s['name']}', style: const TextStyle(fontSize: 16))),
                if (_mine.contains('${s['id']}')) const Icon(Icons.check, color: Colors.teal),
              ]),
            ),
        ],
      ),
    );
    if (picked == null || !mounted) return;
    if (_mine.length == 1 && _mine.first == picked) return;
    if (_mine.isNotEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Change your service?'),
          content: const Text('You will receive bookings only for this service. Your saved charges for other services stay saved.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Change')),
          ],
        ),
      );
      if (ok != true) return;
    }
    try {
      await supabase.from('technician_services').delete().eq('technician_id', _uid);
      await supabase.from('technician_services').insert({'technician_id': _uid, 'service_id': picked});
      _mine = {picked};
      _current = picked;
      if (mounted) setState(() {});
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
  }

  Future<void> _save() async {
    final items = <String>[
      for (final p in _products.where((p) => p['service_id'] == _current))
        for (final t in _types.where((t) => t['product_id'] == p['id'])) '${t['id']}'
    ];
    final upserts = <Map<String, dynamic>>[];
    final deletes = <String>[];
    var notSet = 0;
    for (final id in items) {
      final e = _entries[id];
      if (e == null) {
        notSet++;
        continue;
      }
      if (e.enabled) {
        final txt = e.price.text.trim();
        if (txt.isEmpty) {
          if (e.existed) deletes.add(id);
          notSet++;
          continue;
        }
        final v = num.tryParse(txt);
        if (v == null || v <= 0) {
          snack(context, 'Enter a charge above zero for every item that is on', error: true);
          return;
        }
        upserts.add({
          'technician_id': _uid,
          'item_id': id,
          'price': v,
          'enabled': true,
          'off_reason': null,
          'off_note': null,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        });
      } else {
        if (e.reason == null) {
          snack(context, 'Choose a reason for every item you switch off', error: true);
          return;
        }
        upserts.add({
          'technician_id': _uid,
          'item_id': id,
          'price': null,
          'enabled': false,
          'off_reason': e.reason,
          'off_note': e.note.text.trim().isEmpty ? null : e.note.text.trim(),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        });
      }
    }
    setState(() => _saving = true);
    try {
      if (upserts.isNotEmpty) {
        await supabase.from('technician_prices').upsert(upserts, onConflict: 'technician_id,item_id');
      }
      for (final id in deletes) {
        await supabase.from('technician_prices').delete().eq('technician_id', _uid).eq('item_id', id);
      }
      if (mounted) {
        snack(context, notSet > 0
            ? 'Saved. $notSet item(s) have no charge yet, so customers cannot book you for them.'
            : 'Charges saved');
      }
      await _load();
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not save: $e', error: true);
    }
    if (mounted) setState(() => _saving = false);
  }

  Widget _thumb(String? url) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Container(
          width: 44,
          height: 44,
          color: Colors.grey.shade200,
          child: url == null || url.isEmpty
              ? const Icon(Icons.image_outlined, color: Colors.grey)
              : DarkSafe(child: Image.network(CloudinaryService.optimized(url, width: 150), fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined))),
        ),
      );

  Widget _itemRow(Map<String, dynamic> t) {
    final id = '${t['id']}';
    final e = _entry(id);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: e.enabled ? Colors.teal.shade100 : Colors.red.shade100),
        borderRadius: BorderRadius.circular(12),
        color: e.enabled ? Colors.white : Colors.red.shade50,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _thumb(t['image_url'] as String?),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${t['name']}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
              if ('${t['description'] ?? ''}'.isNotEmpty)
                Text('${t['description']}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
            ]),
          ),
          Switch(
            value: e.enabled,
            onChanged: (v) => setState(() => e.enabled = v),
          ),
        ]),
        if (e.enabled)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: TextField(
              controller: e.price,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                  labelText: 'My charge (₹)',
                  prefixText: '₹ ',
                  isDense: true,
                  border: const OutlineInputBorder(),
                  helperText: (t['price_min'] == null && t['price_max'] == null)
                      ? null
                      : 'Allowed: ₹${t['price_min'] ?? 0} to ₹${t['price_max'] ?? 'any'}'),
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Column(children: [
              DropdownButtonFormField<String>(
                value: e.reason,
                isExpanded: true,
                decoration: const InputDecoration(
                    labelText: 'Why is this off? (required)', isDense: true, border: OutlineInputBorder()),
                items: [for (final r in kOffReasons) DropdownMenuItem(value: r, child: Text(r))],
                onChanged: (v) => setState(() => e.reason = v),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: e.note,
                decoration: const InputDecoration(
                    labelText: 'More detail (optional)', isDense: true, border: OutlineInputBorder()),
              ),
            ]),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final svc = _services.where((s) => '${s['id']}' == _current).toList();
    final products = _products.where((p) => p['service_id'] == _current).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('My services & charges')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Could not load. $_error', textAlign: TextAlign.center),
                  ))
              : ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 100), children: [
                  Card(
                    margin: EdgeInsets.zero,
                    child: ListTile(
                      leading: const Icon(Icons.handyman, color: Colors.teal),
                      title: Text(svc.isEmpty ? 'Choose your service' : '${svc.first['name']}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      subtitle: const Text('You receive bookings only for your service'),
                      trailing: OutlinedButton(
                          onPressed: _chooseService, child: Text(svc.isEmpty ? 'Choose' : 'Change')),
                    ),
                  ),
                  if (_mine.length > 1)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Wrap(spacing: 8, children: [
                        for (final s in _services.where((s) => _mine.contains('${s['id']}')))
                          ChoiceChip(
                            label: Text('${s['name']}'),
                            selected: '${s['id']}' == _current,
                            onSelected: (_) => setState(() => _current = '${s['id']}'),
                          ),
                      ]),
                    ),
                  const SizedBox(height: 12),
                  if (svc.isEmpty)
                    const Text('Choose your service to see the products and set your charges.')
                  else if (products.isEmpty)
                    const Text('Fixeaze has not added products for this service yet. Please check again soon.')
                  else ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.teal.shade50, borderRadius: BorderRadius.circular(12)),
                      child: const Text(
                          'Enter your charge for every item you do. Customers can book you only for items that are '
                          'switched on and have a charge. If you do not do something, switch it off and give the reason.'),
                    ),
                    const SizedBox(height: 12),
                    for (final p in products)
                      Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              _thumb(p['image_url'] as String?),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text('${p['name']}',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                                  if ('${p['description'] ?? ''}'.isNotEmpty)
                                    Text('${p['description']}',
                                        style: const TextStyle(fontSize: 12, color: Colors.black54)),
                                ]),
                              ),
                            ]),
                            const SizedBox(height: 10),
                            for (final t in _types.where((t) => t['product_id'] == p['id'])) _itemRow(t),
                            if (_types.where((t) => t['product_id'] == p['id']).isEmpty)
                              const Text('No service types yet.', style: TextStyle(color: Colors.grey)),
                          ]),
                        ),
                      ),
                  ],
                ]),
      bottomNavigationBar: _loading || _current == null
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Save my charges'),
                ),
              ),
            ),
    );
  }
}
