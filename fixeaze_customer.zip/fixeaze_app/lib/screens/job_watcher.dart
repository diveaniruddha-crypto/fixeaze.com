import 'dart:async';

import 'package:flutter/material.dart';
import '../dark_mode.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/job_service.dart';
import '../widgets/common.dart';
import 'technician/job_flow_screen.dart';

/// Wrap the home screen with this. It checks the user's active jobs every few seconds and
/// pops up the right screen when the other person has done their step:
///  - customer: OTP / confirm parts / choose payment / enter end OTP
///  - technician: "payment received?" and the end OTP
class JobWatcher extends StatefulWidget {
  final bool isTechnician;
  final Widget child;
  const JobWatcher({super.key, required this.isTechnician, required this.child});

  @override
  State<JobWatcher> createState() => _JobWatcherState();
}

class _JobWatcherState extends State<JobWatcher> {
  Timer? _timer;
  bool _checking = false;
  bool _open = false;
  final Set<String> _seen = {};

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _check());
    WidgetsBinding.instance.addPostFrameCallback((_) => _check());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _check() async {
    if (_checking || _open || !mounted) return;
    final user = supabase.auth.currentUser;
    if (user == null) return;
    _checking = true;
    try {
      final col = widget.isTechnician ? 'technician_id' : 'customer_id';
      final rows = await supabase
          .from('bookings')
          .select('id, job_stage')
          .eq(col, user.id)
          .inFilter('status', ['accepted', 'in_progress']);
      final wanted = widget.isTechnician ? JobApi.technicianStages : JobApi.customerStages;
      for (final r in rows) {
        final stage = (r['job_stage'] ?? '').toString();
        final id = r['id'].toString();
        if (!wanted.contains(stage)) continue;
        final key = '$id:$stage';
        if (_seen.contains(key)) continue;
        _seen.add(key);
        if (!mounted) return;
        if (widget.isTechnician) {
          if (TechJobScreen.openId == id) return;
          _open = true;
          await Navigator.push(
              context, MaterialPageRoute(builder: (_) => TechJobScreen(bookingId: id)));
        } else {
          _open = true;
          await showCustomerJob(context, id);
        }
        _open = false;
        return;
      }
    } catch (_) {
      // Network hiccup or SQL not run yet: try again next time.
    } finally {
      _checking = false;
      _open = false;
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

Future<void> showCustomerJob(BuildContext context, String bookingId) {
  return showDialog<void>(
    context: context,
    builder: (_) => CustomerJobDialog(bookingId: bookingId),
  );
}

/// The popup the customer sees during a job.
class CustomerJobDialog extends StatefulWidget {
  final String bookingId;
  const CustomerJobDialog({super.key, required this.bookingId});

  @override
  State<CustomerJobDialog> createState() => _CustomerJobDialogState();
}

class _CustomerJobDialogState extends State<CustomerJobDialog> {
  Map<String, dynamic>? _b;
  List<Map<String, dynamic>> _parts = [];
  Map<String, dynamic>? _pay;
  String? _startOtp;
  List<Map<String, dynamic>> _offers = [];
  bool _offersLoaded = false;
  bool _busy = false;
  bool _loading = false;
  Timer? _timer;
  final _code = TextEditingController();
  final _offerCode = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _code.dispose();
    _offerCode.dispose();
    super.dispose();
  }

  String get _id => widget.bookingId;
  String get _stage => (_b?['job_stage'] ?? 'assigned').toString();

  Future<void> _load() async {
    if (_loading || !mounted) return;
    _loading = true;
    try {
      final b = await JobApi.booking(_id);
      final stage = (b['job_stage'] ?? 'assigned').toString();
      final parts = await JobApi.parts(_id);
      Map<String, dynamic>? pay = _pay;
      if (stage == 'payment_due' || stage == 'payment_check') pay = await JobApi.payInfo(_id);
      String? so;
      if (stage == 'arrived') so = await JobApi.otp(_id, 'start');
      var offers = _offers;
      if (stage == 'payment_due') {
        if (!_offersLoaded) {
          try {
            offers = await JobApi.myOffers(_id);
          } catch (_) {
            offers = [];
          }
          _offersLoaded = true;
        }
      } else {
        _offersLoaded = false;
      }
      if (!mounted) return;
      setState(() {
        _offers = offers;
        _b = b;
        _parts = parts;
        _pay = pay;
        _startOtp = so;
      });
    } catch (_) {
      // keep showing what we have
    } finally {
      _loading = false;
    }
  }

  Future<void> _run(Future<void> Function() action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      if (mounted) snack(context, JobApi.errText(e), error: true);
    }
    if (mounted) setState(() => _busy = false);
    await _load();
  }

  Future<void> _applyOffer(String code) async {
    final c = code.trim();
    if (c.isEmpty) return;
    _offersLoaded = false;
    await _run(() async {
      final d = await JobApi.applyOffer(_id, c);
      _offerCode.clear();
      if (mounted) snack(context, 'Offer applied. You save ${money(d)}');
    });
  }

  Future<void> _removeOffer() async {
    _offersLoaded = false;
    await _run(() => JobApi.removeOffer(_id));
  }

  Widget _offerBox(Map<String, dynamic> b) {
    final disc = _n(b['discount_amount']);
    if (disc > 0) {
      return Card(
        margin: const EdgeInsets.only(bottom: 12),
        color: Colors.green.shade50,
        child: ListTile(
          leading: const Icon(Icons.local_offer, color: Colors.green),
          title: Text('${b['offer_code']} applied: you save ${money(disc)}',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('Bill was ${money(_n(b['gross_total']) + disc)}'),
          trailing: TextButton(onPressed: _busy ? null : _removeOffer, child: const Text('Remove')),
        ),
      );
    }
    final good = _offers.where((o) => o['ok'] == true).toList();
    final bad = _offers.where((o) => o['ok'] != true).toList();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.local_offer_outlined, size: 20, color: Colors.teal),
            SizedBox(width: 8),
            Text('Offers', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _offerCode,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                    hintText: 'Have an offer code?', isDense: true, border: OutlineInputBorder()),
                onSubmitted: (v) => _busy ? null : _applyOffer(v),
              ),
            ),
            const SizedBox(width: 8),
            FilledButton(
                onPressed: _busy ? null : () => _applyOffer(_offerCode.text), child: const Text('Apply')),
          ]),
          for (final o in good)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${o['code']} - ${o['title']}', style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('You save ${money(o['discount'])}'),
              trailing: OutlinedButton(
                  onPressed: _busy ? null : () => _applyOffer('${o['code']}'), child: const Text('Use')),
            ),
          for (final o in bad)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              enabled: false,
              title: Text('${o['code']} - ${o['title']}'),
              subtitle: Text('${o['why'] ?? ''}'),
            ),
        ]),
      ),
    );
  }

  num _n(dynamic v) => v is num ? v : (num.tryParse('${v ?? ''}') ?? 0);

  Widget _title(IconData icon, String text, Color color) => Row(children: [
        Icon(icon, color: color, size: 30),
        const SizedBox(width: 10),
        Expanded(
            child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
      ]);

  Widget _line(String a, String b, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          Expanded(child: Text(a)),
          Text(b, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
        ]),
      );

  List<Widget> _content() {
    final b = _b!;
    final labour = _n(b['price']);
    final partsSum = _parts.fold<num>(0, (s, p) => s + _n(p['qty']) * _n(p['price']));
    final total = labour + partsSum;

    switch (_stage) {
      case 'arrived':
        final selfie = (b['arrival_selfie'] ?? '').toString();
        return [
          _title(Icons.directions_walk, 'Your technician has arrived', Colors.teal),
          const SizedBox(height: 12),
          if (selfie.isNotEmpty)
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: DarkSafe(child: Image.network(selfie, height: 160, fit: BoxFit.cover)),
              ),
            ),
          const SizedBox(height: 10),
          const Text('Check that this is the person at your door. Then tell them this OTP so they can start:'),
          const SizedBox(height: 10),
          Center(
            child: Text(_startOtp ?? '......',
                style: const TextStyle(
                    fontSize: 40, fontWeight: FontWeight.bold, letterSpacing: 10)),
          ),
          const SizedBox(height: 6),
          const Text('Do not share this OTP with anyone who is not at your home.',
              style: TextStyle(color: Colors.black54, fontSize: 12)),
        ];
      case 'working':
      case 'assigned':
        return [
          _title(Icons.build_circle, 'Work in progress', Colors.teal),
          const SizedBox(height: 10),
          const Text('Your technician is working. You will get another popup when the work is finished.'),
        ];
      case 'parts_review':
        final before = (b['before_photos'] is List) ? List<String>.from(b['before_photos']) : <String>[];
        final after = (b['after_photos'] is List) ? List<String>.from(b['after_photos']) : <String>[];
        return [
          _title(Icons.fact_check, 'Confirm parts and bill', Colors.deepPurple),
          const SizedBox(height: 10),
          if (_parts.isEmpty) const Text('No parts were used.'),
          for (final p in _parts)
            _line('${p['name']}  (${p['qty']} x ${money(p['price'])})',
                money(_n(p['qty']) * _n(p['price']))),
          const Divider(),
          _line('Service charge', money(labour)),
          _line('Parts', money(partsSum)),
          _line('Total', money(total), bold: true),
          if (before.isNotEmpty) ...[
            const SizedBox(height: 10),
            const Text('Before', style: TextStyle(fontWeight: FontWeight.w600)),
            PhotoStrip(urls: before),
          ],
          if (after.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Text('After', style: TextStyle(fontWeight: FontWeight.w600)),
            PhotoStrip(urls: after),
          ],
          const SizedBox(height: 14),
          const Text('Were these parts really used?'),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _busy ? null : () => _run(() => JobApi.partsResponse(_id, false)),
                child: const Text('No'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton(
                onPressed: _busy ? null : () => _run(() => JobApi.partsResponse(_id, true)),
                child: const Text('Yes, confirm'),
              ),
            ),
          ]),
        ];
      case 'payment_due':
        final upi = (_pay?['upi_id'] ?? '').toString();
        return [
          _title(Icons.payments, 'Pay ${money(b['gross_total'])}', Colors.teal),
          const SizedBox(height: 10),
          _offerBox(b),
          const Text('How would you like to pay?'),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _busy || upi.isEmpty ? null : () => _run(() => JobApi.choosePayment(_id, 'qr')),
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Scan QR and pay'),
            ),
          ),
          if (upi.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text('QR payment is not available right now.',
                  style: TextStyle(color: Colors.black54, fontSize: 12)),
            ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _busy ? null : () => _run(() => JobApi.choosePayment(_id, 'cash')),
              icon: const Icon(Icons.money),
              label: const Text('Pay by cash'),
            ),
          ),
        ];
      case 'payment_check':
        final cash = (b['payment_method'] ?? '') == 'cash';
        final canUpi = !cash && (_pay?['upi_id'] ?? '').toString().isNotEmpty;
        return [
          _title(Icons.hourglass_top, 'Waiting for technician', Colors.orange),
          const SizedBox(height: 10),
          Text(cash
              ? 'Hand ${money(b['gross_total'])} in cash to your technician. They will confirm in their app.'
              : 'Scan the QR code on your technician\'s phone and pay ${money(b['gross_total'])}. They will confirm when it arrives.'),
          if (canUpi) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => launchUrl(Uri.parse(JobApi.upiLink(_pay!)),
                  mode: LaunchMode.externalApplication),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Open my UPI app instead'),
            ),
          ],
        ];
      case 'work_check':
        return [
          _title(Icons.help_outline, 'Is your work done?', Colors.teal),
          const SizedBox(height: 10),
          const Text('Your technician has received the payment. Has the technician finished the work to your satisfaction?'),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 58,
            child: FilledButton.icon(
              onPressed: _busy ? null : () => _run(() => JobApi.workResponse(_id, true)),
              icon: const Icon(Icons.check_circle_outline),
              label: const Text('Yes, work is done', style: TextStyle(fontSize: 17)),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.red.shade700, side: BorderSide(color: Colors.red.shade700, width: 2)),
              onPressed: _busy ? null : () => _run(() => JobApi.workResponse(_id, false)),
              icon: const Icon(Icons.close),
              label: const Text('No, not finished', style: TextStyle(fontSize: 16)),
            ),
          ),
          const SizedBox(height: 6),
          const Text('If you tap Yes, your technician will show you an OTP. Type it to end the booking.',
              style: TextStyle(color: Colors.black54, fontSize: 12.5)),
        ];
      case 'end_otp':
        return [
          _title(Icons.lock_open, 'Payment received', Colors.green),
          const SizedBox(height: 10),
          const Text('Your technician has an OTP on their phone. Ask for it and type it here to end the booking.'),
          const SizedBox(height: 10),
          TextField(
            controller: _code,
            keyboardType: TextInputType.number,
            maxLength: 6,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 26, letterSpacing: 8),
            decoration: const InputDecoration(counterText: '', hintText: '------'),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _busy
                  ? null
                  : () => _run(() async {
                        final code = _code.text.trim();
                        if (code.length != 6) throw 'Enter the 6-digit OTP';
                        final ok = await JobApi.finish(_id, code);
                        if (!ok) throw 'Wrong OTP. Please check with the technician.';
                        _code.clear();
                      }),
              child: const Text('End booking'),
            ),
          ),
        ];
      case 'done':
        return [
          _title(Icons.verified, 'Booking completed', Colors.green),
          const SizedBox(height: 10),
          Text('Thank you! Total paid: ${money(b['gross_total'])}. You can rate the service from the Bookings tab.'),
        ];
      default:
        return [const Text('Please wait...')];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: _b == null
              ? const SizedBox(height: 120, child: Center(child: CircularProgressIndicator()))
              : SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ..._content(),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Close'),
                        ),
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}
