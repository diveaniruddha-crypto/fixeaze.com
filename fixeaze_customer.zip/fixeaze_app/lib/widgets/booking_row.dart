import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

const _shortLabel = {
  'pending': 'Waiting',
  'accepted': 'Assigned',
  'in_progress': 'In progress',
  'completed': 'Done',
  'cancelled': 'Cancelled',
};
const _shortColor = {
  'pending': Color(0xFFEF6C00),
  'accepted': Color(0xFF1565C0),
  'in_progress': Color(0xFF6A1B9A),
  'completed': Color(0xFF2E7D32),
  'cancelled': Color(0xFF616161),
};

/// Column titles shown once above a list of BookingRow.
class BookingTableHeader extends StatelessWidget {
  const BookingTableHeader({super.key});

  @override
  Widget build(BuildContext context) {
    const s = TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.black54);
    return const Padding(
      padding: EdgeInsets.fromLTRB(14, 0, 14, 6),
      child: Row(children: [
        Expanded(flex: 5, child: Text('ORDER', style: s)),
        Expanded(flex: 3, child: Text('DATE', style: s)),
        Expanded(flex: 3, child: Text('STATUS', style: s)),
        SizedBox(width: 24),
      ]),
    );
  }
}

/// One booking as a single table row. Tap to open the full details underneath.
class BookingRow extends StatefulWidget {
  final String title;
  final String bookingNo;
  final String status;
  final dynamic when; // ISO date text
  final Widget details;
  final bool initiallyOpen;
  const BookingRow({
    super.key,
    required this.title,
    required this.bookingNo,
    required this.status,
    required this.when,
    required this.details,
    this.initiallyOpen = false,
  });

  @override
  State<BookingRow> createState() => _BookingRowState();
}

class _BookingRowState extends State<BookingRow> {
  late bool _open = widget.initiallyOpen;

  @override
  Widget build(BuildContext context) {
    final t = DateTime.tryParse('${widget.when}')?.toLocal();
    final color = _shortColor[widget.status] ?? Colors.grey;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: _open ? color.withAlpha(120) : const Color(0xFFE5DFD1)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        InkWell(
          onTap: () => setState(() => _open = !_open),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
            child: Row(children: [
              Expanded(
                flex: 5,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(widget.title,
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  if (widget.bookingNo.isNotEmpty)
                    Text(widget.bookingNo, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ]),
              ),
              Expanded(
                flex: 3,
                child: t == null
                    ? const SizedBox()
                    : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(DateFormat('d MMM').format(t), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        Text(DateFormat('h:mm a').format(t), style: const TextStyle(fontSize: 12, color: Colors.black54)),
                      ]),
              ),
              Expanded(
                flex: 3,
                child: Row(children: [
                  Container(width: 9, height: 9, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Flexible(
                    child: Text(_shortLabel[widget.status] ?? widget.status,
                        style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: color)),
                  ),
                ]),
              ),
              Icon(_open ? Icons.expand_less : Icons.expand_more, color: Colors.black45),
            ]),
          ),
        ),
        if (_open) const Divider(height: 1, color: Color(0xFFE5DFD1)),
        if (_open) widget.details,
      ]),
    );
  }
}
