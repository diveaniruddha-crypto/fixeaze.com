import 'package:flutter/material.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

// ============================================== RATINGS, CANCELLATIONS, BLOCKS

class QualityPage extends StatefulWidget {
  const QualityPage({super.key});
  @override
  State<QualityPage> createState() => _QualityPageState();
}

class _QualityPageState extends State<QualityPage> {
  String _role = 'all';
  String _q = ''; // search ratings by booking number or name

  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    super.dispose();
  }

  bool _isBlocked(String id) {
    final bu = parseTime(_s.P[id]?['blocked_until']);
    return bu != null && bu.isAfter(DateTime.now());
  }

  String _blockText(String id) {
    final bu = parseTime(_s.P[id]?['blocked_until']);
    if (bu == null || !bu.isAfter(DateTime.now())) return '';
    return bu.year > DateTime.now().year + 5 ? 'Blocked (permanent)' : 'Blocked until ${fdt(bu)}';
  }

  int _cancels(String id, {int days = 30}) {
    final from = DateTime.now().subtract(Duration(days: days));
    return _s.cancellations
        .where((c) => '${c['by_user']}' == id && (parseTime(c['created_at'])?.isAfter(from) ?? false))
        .length;
  }

  String _bno(dynamic bookingId) {
    for (final b in _s.bookings) {
      if ('${b['id']}' == '$bookingId') return '${b['booking_no'] ?? ''}';
    }
    return '';
  }

  Future<void> _blockDialog(String id) async {
    int days = 3;
    final why = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setL) => AlertDialog(
          title: Text('Block ${_s.nameOf(id)}'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<int>(
              value: days,
              decoration: const InputDecoration(labelText: 'For how long', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 1, child: Text('1 day')),
                DropdownMenuItem(value: 3, child: Text('3 days')),
                DropdownMenuItem(value: 7, child: Text('7 days')),
                DropdownMenuItem(value: 30, child: Text('30 days')),
                DropdownMenuItem(value: 36500, child: Text('Permanent')),
                DropdownMenuItem(value: 0, child: Text('Unblock now')),
              ],
              onChanged: (v) => setL(() => days = v ?? 3),
            ),
            const SizedBox(height: 10),
            TextField(controller: why, decoration: const InputDecoration(labelText: 'Reason (note for you)', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            const Muted('A blocked technician cannot accept jobs and is hidden from customers. A blocked customer cannot book.'),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(days == 0 ? 'Unblock' : 'Block')),
          ],
        ),
      ),
    );
    final reason = why.text.trim();
    why.dispose();
    if (go != true) return;
    final err = await _s.blockUser(id, days, reason);
    if (mounted) report(context, err, days == 0 ? 'Unblocked' : 'Blocked');
  }

  Future<void> _reverse(String kind, Rec r) async {
    final reversed = r['reversed'] == true;
    final note = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(reversed ? 'Restore this rating?' : 'Reverse this rating?'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(reversed
              ? 'It will count in the average again.'
              : 'It will no longer count in the average rating.'),
          const SizedBox(height: 10),
          TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (optional)', border: OutlineInputBorder())),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(reversed ? 'Restore' : 'Reverse')),
        ],
      ),
    );
    final n = note.text.trim();
    note.dispose();
    if (go != true) return;
    final err = await _s.reverseReview(kind, '${r['id']}', !reversed, n);
    if (mounted) report(context, err, reversed ? 'Rating restored' : 'Rating reversed');
  }

  Widget _stars(dynamic v) {
    final n = numOf(v).toInt();
    return Text('${'★' * n}${'☆' * (5 - n)}', style: const TextStyle(color: Colors.amber, fontSize: 16));
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final err = s.errors['cancellations'] ?? s.errors['customer_reviews'];
    final low = s.lowRated;
    final cancels = s.cancellations.where((c) => _role == 'all' || c['by_role'] == _role).toList();
    final from30 = DateTime.now().subtract(const Duration(days: 30));
    final c30 = s.cancellations.where((c) => parseTime(c['created_at'])?.isAfter(from30) ?? false).toList();
    final blocked = s.profiles.where((p) => _isBlocked('${p['id']}')).toList();
    final techRev = s.reviews.toList()
      ..sort((a, b) => '${b['created_at']}'.compareTo('${a['created_at']}'));
    final custRev0 = s.custReviews.toList()
      ..sort((a, b) => '${b['created_at']}'.compareTo('${a['created_at']}'));
    final q = _q.trim().toLowerCase();
    bool hit(Rec r) =>
        q.isEmpty ||
        _bno(r['booking_id']).toLowerCase().contains(q) ||
        s.nameOf(r['customer_id']).toLowerCase().contains(q) ||
        s.nameOf(r['technician_id']).toLowerCase().contains(q) ||
        '${r['comment'] ?? ''}'.toLowerCase().contains(q);
    final techRevF = techRev.where(hit).toList();
    final custRev = custRev0.where(hit).toList();

    return ListView(padding: const EdgeInsets.all(16), children: [
      if (err != null)
        NoticeBanner('Run sql/v2_part26_quality.sql in Supabase to turn this page on. ($err)'),
      TileGrid([
        StatTile('Technicians below 3 stars', '${low.length}', sub: 'Needs your decision', alert: low.isNotEmpty),
        StatTile('Cancellations (30 days)', '${c30.length}',
            sub: '${c30.where((c) => c['by_role'] == 'technician').length} by technicians'),
        StatTile('Blocked now', '${blocked.length}'),
        StatTile('All cancellations', '${s.cancellations.length}'),
      ]),
      const SectionTitle('Technicians rated below 3'),
      AdminTable(
        columns: const ['Technician', 'Rating', 'Jobs', 'Cancels (30d)', 'Status', ''],
        numeric: const {1, 2, 3},
        empty: 'No technician is below 3 stars.',
        rows: [
          for (final t in low)
            [
              TwoLine(s.nameOf(t['id']), '${s.P['${t['id']}']?['phone'] ?? ''}'),
              Text('${numOf(t['rating']).toStringAsFixed(1)} ★', style: const TextStyle(color: kBad, fontWeight: FontWeight.bold)),
              Text('${t['jobs_done'] ?? 0}'),
              Text('${_cancels('${t['id']}')}'),
              Text(_blockText('${t['id']}').isEmpty ? 'Active' : _blockText('${t['id']}')),
              OutlinedButton(onPressed: () => _blockDialog('${t['id']}'), child: const Text('Block / decide')),
            ],
        ],
      ),
      if (blocked.isNotEmpty) ...[
        const SectionTitle('Blocked accounts'),
        AdminTable(
          columns: const ['Name', 'Role', 'Status', 'Reason', ''],
          rows: [
            for (final p in blocked)
              [
                Text(s.nameOf(p['id'])),
                Text('${p['role']}'),
                Text(_blockText('${p['id']}')),
                Text('${p['blocked_reason'] ?? '-'}'),
                OutlinedButton(onPressed: () => _blockDialog('${p['id']}'), child: const Text('Change')),
              ],
          ],
        ),
      ],
      const SectionTitle('Cancellations'),
      Align(
        alignment: Alignment.centerLeft,
        child: SizedBox(
          width: 220,
          child: DropdownButtonFormField<String>(
            value: _role,
            isDense: true,
            items: const [
              DropdownMenuItem(value: 'all', child: Text('Customers and technicians')),
              DropdownMenuItem(value: 'technician', child: Text('Technicians only')),
              DropdownMenuItem(value: 'customer', child: Text('Customers only')),
            ],
            onChanged: (v) => setState(() => _role = v ?? 'all'),
          ),
        ),
      ),
      const SizedBox(height: 8),
      AdminTable(
        columns: const ['When', 'Booking', 'Cancelled by', 'Reason', 'Details', 'Their cancels (30d)', ''],
        numeric: const {5},
        empty: 'No cancellations yet.',
        rows: [
          for (final c in cancels.take(300))
            [
              Text(fdt(c['created_at'])),
              Text(_bno(c['booking_id']).isEmpty ? '-' : _bno(c['booking_id'])),
              TwoLine(s.nameOf(c['by_user']), '${c['by_role']}'),
              Text('${c['reason']}', style: const TextStyle(fontWeight: FontWeight.w600)),
              SizedBox(width: 220, child: Text('${c['note'] ?? '-'}')),
              Text('${_cancels('${c['by_user']}')}'),
              OutlinedButton(onPressed: () => _blockDialog('${c['by_user']}'), child: const Text('Block')),
            ],
        ],
      ),
      const SectionTitle('Customer ratings of technicians'),
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          onChanged: (v) => setState(() => _q = v),
          decoration: InputDecoration(
            isDense: true,
            prefixIcon: const Icon(Icons.search),
            hintText: 'Find a booking: type its number (FX001007) or a name',
            border: const OutlineInputBorder(),
            suffixIcon: _q.isEmpty ? null : const Icon(Icons.filter_alt_outlined),
          ),
        ),
      ),
      const Padding(
        padding: EdgeInsets.only(bottom: 8),
        child: Muted('Tap Reverse on a rating to stop it counting in the average. Tap Restore to count it again.'),
      ),
      AdminTable(
        columns: const ['When', 'Booking', 'Customer', 'Technician', 'Stars', 'Comment', ''],
        empty: 'No ratings yet.',
        rows: [
          for (final r in techRevF.take(150))
            [
              Text(fdt(r['created_at'])),
              Text(_bno(r['booking_id']).isEmpty ? '-' : _bno(r['booking_id'])),
              Text(s.nameOf(r['customer_id'])),
              Text(s.nameOf(r['technician_id'])),
              r['reversed'] == true ? const Pill('Reversed', kWarn) : _stars(r['rating']),
              SizedBox(width: 220, child: Text('${r['comment'] ?? '-'}')),
              OutlinedButton(
                  onPressed: () => _reverse('technician', r), child: Text(r['reversed'] == true ? 'Restore' : 'Reverse')),
            ],
        ],
      ),
      const SectionTitle('Technician ratings of customers'),
      AdminTable(
        columns: const ['When', 'Booking', 'Technician', 'Customer', 'Stars', 'Comment', ''],
        empty: 'No ratings yet.',
        rows: [
          for (final r in custRev.take(150))
            [
              Text(fdt(r['created_at'])),
              Text(_bno(r['booking_id']).isEmpty ? '-' : _bno(r['booking_id'])),
              Text(s.nameOf(r['technician_id'])),
              Text(s.nameOf(r['customer_id'])),
              r['reversed'] == true ? const Pill('Reversed', kWarn) : _stars(r['rating']),
              SizedBox(width: 220, child: Text('${r['comment'] ?? '-'}')),
              OutlinedButton(
                  onPressed: () => _reverse('customer', r), child: Text(r['reversed'] == true ? 'Restore' : 'Reverse')),
            ],
        ],
      ),
    ]);
  }
}
