-- Fixeaze part 45: a technician can decline a new job (with a reason). The job stays open for other technicians.
-- Run once in Supabase > SQL Editor. Safe to run twice.
create or replace function public.decline_job(p_booking uuid, p_reason text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare b record; nm text;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'Please choose a reason'; end if;
  select * into b from public.bookings where id = p_booking;
  if not found then raise exception 'Booking not found'; end if;
  if b.status <> 'pending' or b.technician_id is not null then
    raise exception 'This job is no longer open';
  end if;
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'technician') then
    raise exception 'Not allowed';
  end if;
  if exists (select 1 from public.cancellations where booking_id = b.id and by_user = auth.uid()) then
    return;
  end if;
  insert into public.cancellations (booking_id, by_user, by_role, tech_id, customer_id, reason, note)
  values (b.id, auth.uid(), 'declined', auth.uid(), b.customer_id,
          trim(p_reason), nullif(trim(coalesce(p_note, '')), ''));
end $$;
grant execute on function public.decline_job(uuid, text, text) to authenticated;
