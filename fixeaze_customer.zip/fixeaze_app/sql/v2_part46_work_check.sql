-- Fixeaze part 46: before the finish OTP, the customer is asked "Is your work done?" (Yes / No).
-- Flow: technician confirms payment -> customer popup (work_check) -> Yes: finish OTP is made and the
-- technician sees it -> customer types it. No: the job goes back to "working" and the technician and admin are told.
-- Run once in Supabase > SQL Editor. Safe to run twice.

-- 1. Technician confirms payment: now goes to the customer's question first (no OTP yet)
create or replace function public.job_confirm_payment(p_booking uuid, p_received boolean)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.technician_id is distinct from auth.uid() or b.job_stage is distinct from 'payment_check' then
    raise exception 'Not allowed';
  end if;
  perform set_config('fixeaze.rpc', '1', true);
  if p_received then
    update public.bookings set job_stage = 'work_check' where id = p_booking;
  else
    update public.bookings set job_stage = 'payment_due', payment_method = null where id = p_booking;
  end if;
  perform set_config('fixeaze.rpc', '', true);
end $$;

-- 2. Customer answers "Is your work done?"
create or replace function public.job_work_response(p_booking uuid, p_done boolean)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings; bno text;
begin
  select * into b from public.bookings where id = p_booking for update;
  if not found or b.customer_id is distinct from auth.uid() or b.job_stage is distinct from 'work_check' then
    raise exception 'Not allowed';
  end if;
  bno := coalesce(b.booking_no, 'your job');
  perform set_config('fixeaze.rpc', '1', true);
  if p_done then
    update public.bookings set job_stage = 'end_otp' where id = p_booking;
    perform public.job_new_otp(p_booking, 'end');
  else
    update public.bookings set job_stage = 'working', payment_method = null where id = p_booking;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (b.technician_id, 'job', 'Customer says the work is not finished',
            'For ' || bno || ' the customer answered No to "Is your work done?". Please finish the work, or call the customer.');
    perform public.push_admins('job', 'Customer says work not done',
      bno || ': the customer answered No after the payment was confirmed. Please check with both.');
  end if;
  perform set_config('fixeaze.rpc', '', true);
end $$;
revoke execute on function public.job_work_response(uuid, boolean) from public, anon;
grant execute on function public.job_work_response(uuid, boolean) to authenticated;

-- 3. Phone notification to the customer when the question is waiting
create or replace function public.trg_push_work_check() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.job_stage = 'work_check' and old.job_stage is distinct from 'work_check' then
    perform public.push_user(new.customer_id, 'Is your work done?',
      'Please confirm in the app for ' || coalesce(new.booking_no, 'your booking') || '.');
  end if;
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists zz_push_work_check on public.bookings;
create trigger zz_push_work_check after update on public.bookings
  for each row execute function public.trg_push_work_check();
